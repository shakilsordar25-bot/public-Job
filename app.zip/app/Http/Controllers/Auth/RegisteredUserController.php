<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\RegistrationMail;
use App\Models\Admin;
use App\Models\Package;
use App\Models\Purchase;
use App\Models\User;
use App\Models\UserLedger;
use App\Providers\RouteServiceProvider;
use Carbon\Carbon;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules;
use Illuminate\View\View;
use function GuzzleHttp\Promise\all;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(Request $request, $id=null)
    {
        if ($id){
            User::find($id)->delete();
        }
        $ref_by = $request->query('ref_by');
        return view('app.auth.registration', compact('ref_by'));
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'phone' => ['required', 'numeric', 'unique:users,phone'],
            'ref_by' => ['required', 'string'],
            'password' => ['required'],
            ],[
                'ref_by.required' => 'Refer code is required',
            ]);
        if ($validate->fails()){
            $user = User::where('phone', $request->phone)->first();
            if ($user){
                return response()->json(['status'=> false, 'message'=>'Phone number exist']);
            }
            return response()->json(['status'=> false, 'message'=>'Registration Fail']);
        }

        if ($request->password != $request->c_password){
            return response()->json(['status'=> false, 'message'=>'Password does not match']);
        }

        //filter phone number
        if ($request->phone)
        {
            $phone = $request->phone;
            if ($request->phone[0] == '0'){
                $phone = substr($request->phone, 1);
            }else{
                $phone = $request->phone;
            }
        }

        //check phone number exist
        $userPhone = User::where('phone', $phone)->first();
        if($userPhone){
            return response()->json(['status'=> false, 'message'=>'Already use this number. try another']);
        }
        
        //Ref ID Generate
        $toLetter1 = Str::random(2);
        $toLetter2 = Str::random(2);
        $toLetter3 = Str::random(2);
        $randomNumber1 = rand(00,99);
        $randomNumber2 = rand(00,99);
        $R_ID = $toLetter1.$randomNumber1.$toLetter2.$toLetter3.$randomNumber2;

        //Check refer code is next time edit
        $user = User::create([
            'name' => 'User'.rand(22,99),
            'username' => 'uname'.$phone,
            'ref_id' => $R_ID,
            'ref_by' => $request->ref_by ?? User::first()->ref_id,
            'email' => 'user'.rand(11111,99999).time().'@gmail.com',
            'password' => Hash::make($request->password),
            'type' => 'user',
            'phone' => $phone,
            'phone_code' => '+880',
            'code' => rand(111111, 999999),
            'remember_token' => Str::random(30),
        ]);

        if ($user){
            Auth::login($user);
            return response()->json(['status'=> true, 'message'=>'Registration success', 'url'=> route('dashboard')]);
        }else{
            return response()->json(['status'=> false, 'message'=>'Registration Fail']);
        }
    }
}

