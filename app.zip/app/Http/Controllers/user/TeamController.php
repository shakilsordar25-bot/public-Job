<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\Checkin;
use App\Models\Commission;
use App\Models\Deposit;
use App\Models\Improvment;
use App\Models\LuckyLedger;
use App\Models\User;
use App\Models\UserLedger;
use App\Models\Withdrawal;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TeamController extends Controller
{
    //
    public function team()
    {
        $user = Auth::user();
        //First Level
        $first_level_users = User::where('ref_by', $user->ref_id)->get();
        $first_level_users_ids = [];
        foreach ($first_level_users as $user){
            array_push($first_level_users_ids, $user->id);
        }
        $team_commission['first_team_commission'] = Commission::where('user_id', auth()->user()->id)->where('reason', 'first_refer_commission')->get()->sum('amount');

        $today_commission['first_team_today_commission'] = Commission::where('user_id', auth()->user()->id)->where('reason', 'first_refer_commission')->whereDate('created_at', Carbon::today())->get()->sum('amount');


        //Second Level
        $second_level_users_ids = [];
        foreach ($first_level_users as $element) {
            $users = User::where('ref_by', $element->ref_id)->get();
            foreach ($users as $user){
                array_push($second_level_users_ids, $user->id);
            }
        }
        $second_level_users = User::whereIn('id', $second_level_users_ids)->get();
        $team_commission['second_team_commission'] =  Commission::where('user_id', auth()->user()->id)->where('reason', 'second_refer_commission')->get()->sum('amount');
        $today_commission['second_team_today_commission'] = Commission::where('user_id', auth()->user()->id)->where('reason', 'second_refer_commission')->whereDate('created_at', Carbon::today())->get()->sum('amount');




        //Get Third Level
        $third_level_users_ids = [];
        foreach ($second_level_users as $element) {
            $users = User::where('ref_by', $element->ref_id)->get();
            foreach ($users as $user){
                array_push($third_level_users_ids, $user->id);
            }
        }
        $third_level_users = User::whereIn('id', $third_level_users_ids)->get();
        $team_commission['third_team_commission'] = Commission::where('user_id', auth()->user()->id)->where('reason', 'third_refer_commission')->get()->sum('amount');
        $today_commission['third_team_today_commission'] = Commission::where('user_id', auth()->user()->id)->where('reason', 'third_refer_commission')->whereDate('created_at', Carbon::today())->get()->sum('amount');

        // return Deposit::whereIn('user_id', User::whereIn('id', $second_level_users_ids)->get()->pluck('id'))->where('status', 'approved')->sum('amount');


        //Get Fourth Level
        $fourth_level_users_ids = [];
        foreach ($third_level_users as $element) {
            $users = User::where('ref_by', $element->ref_id)->get();
            foreach ($users as $user){
                array_push($fourth_level_users_ids, $user->id);
            }
        }
        $fourth_level_users = User::whereIn('id', $fourth_level_users_ids)->get();
        $team_commission['fourth_team_commission'] = Commission::whereIn('user_id', $fourth_level_users_ids)->get()->sum('amount');
        $today_commission['fourth_team_today_commission'] = Commission::whereIn('user_id', $fourth_level_users_ids)->whereDate('created_at', Carbon::today())->get()->sum('amount');


        //Get Fourth Level
        $five_level_users_ids = [];
        foreach ($fourth_level_users as $element) {
            $users = User::where('ref_by', $element->ref_id)->get();
            foreach ($users as $user){
                array_push($five_level_users_ids, $user->id);
            }
        }
        $five_level_users = User::whereIn('id', $five_level_users_ids)->get();
        $team_commission['five_team_commission'] = Commission::whereIn('user_id', $five_level_users_ids)->get()->sum('amount');
        $today_commission['five_team_today_commission'] = Commission::whereIn('user_id', $five_level_users_ids)->whereDate('created_at', Carbon::today())->get()->sum('amount');

        //Commission
        $commission['first_commission'] = Improvment::where('status', 'active')->get()->max('first_refer_commission');
        $commission['second_commission'] = Improvment::where('status', 'active')->get()->max('second_refer_commission');
        $commission['three_commission'] = Improvment::where('status', 'active')->get()->max('third_refer_commission');

        //Recharge Commission
        $rechargeCommission['first_recharge_commission'] = Commission::where('user_id', Auth::id())->where('reason', 'first_refer_recharge_commission')->get()->sum('amount');
        $rechargeCommission['second_recharge_commission'] = Commission::where('user_id', Auth::id())->where('reason', 'second_refer_recharge_commission')->get()->sum('amount');
        $rechargeCommission['third_recharge_commission'] = Commission::where('user_id', Auth::id())->where('reason', 'third_refer_recharge_commission')->get()->sum('amount');

        //get total income //Amount Commission, refer commission, checkin commission, spin commission
        $total_commission_income = Commission::where('user_id', Auth::id())->get()->sum('amount');
        $total_checkin_income = Checkin::where('user_id', Auth::id())->get()->sum('amount');
        $total_income = $total_commission_income + $total_checkin_income;


        return view('app.main.team.index', compact(
            'total_income',
            'first_level_users',
            'second_level_users',
            'third_level_users',
            'fourth_level_users',
            'five_level_users',
            'commission',
            'team_commission',
            'today_commission',
            'rechargeCommission',
        ));
    }

    public function team_list($usersIds)
    {
        $ids = json_decode($usersIds);
        $users = User::whereIn('id', $ids)->orderByDesc('id')->get();

        return view('app.main.team.list', compact('users'));
    }

    public function get_recharge_amount($step)
    {
        $user = Auth::user();
        if ($step == 'com1'){
            User::where('id', $user->id)
                ->update([
                    'balance'=> $user->balance + $user->recharge_1_com,
                    'commission_balance'=> $user->commission_balance + $user->recharge_1_com,
                    'received_balance1' => $user->received_balance1 + $user->recharge_1_com,
                    'recharge_1_com'=> 0,
                ]);
        }
        if ($step == 'com2'){
            User::where('id', $user->id)
                ->update([
                    'balance'=> $user->balance + $user->recharge_2_com,
                    'commission_balance'=> $user->commission_balance + $user->recharge_2_com,
                    'received_balance2' => $user->received_balance2 + $user->recharge_2_com,
                    'recharge_2_com'=> 0,
                ]);
        }
        if ($step == 'com3'){
            User::where('id', $user->id)
                ->update([
                    'balance'=> $user->balance + $user->recharge_3_com,
                    'commission_balance'=> $user->commission_balance + $user->recharge_3_com,
                    'received_balance3' => $user->received_balance3 + $user->recharge_3_com,
                    'recharge_3_com'=> 0,
                ]);
        }
        return redirect()->route('team')->with('message', 'Congratulations. Amount Received');
    }


    public function team_result($ids)
    {
        if ($ids){
            $ids = decrypt($ids);
            $users = User::whereIn('id', $ids)->get();
        }
        return  view('app.main.team.list', compact('users'));
    }


    public function income()
    {
        return  view('app.main.income');
    }


    public function rebate()
    {
        return  view('app.main.mine.rebate');
    }


    public function lvl_details($ids, $lvl)
    {
        $ids = decrypt($ids);
        $users = User::whereIn('id', $ids)->get();

        //total commission
        $sponsorCom = UserLedger::where('user_id', Auth::id())->where('reason', 'sponsor_bonus')->get()->pluck('amount')->sum();
        $referralCom = UserLedger::where('user_id', Auth::id())->where('reason', 'refer_bonus')->get()->pluck('amount')->sum();
//        $getTotalCommission = $getTotalCommission1 + $getTotalCommission2;

        //Total payment
        $total_payment_amount = Deposit::whereIn('user_id', $ids)->get()->pluck('amount')->toArray();
        $total_payment = array_sum($total_payment_amount);

        return  view('app.main.team.list', compact('users', 'lvl', 'total_payment', 'sponsorCom', 'referralCom'));
    }

}
