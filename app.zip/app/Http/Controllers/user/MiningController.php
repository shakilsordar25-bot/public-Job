<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\Mining;
use App\Models\Package;
use App\Models\Purchase;
use App\Models\User;
use App\Models\UserLedger;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MiningController extends Controller
{
    public function order()
    {
        $purchases = Purchase::with('package')
            ->where('user_id', Auth::id())
            ->where('status', 'active')
            ->get();

        /**** mining work ****/
        //get my active mining
        $myMining = Mining::with(['user', 'package'])->where('user_id', Auth::id())
            ->where('running_status','start')->get();

        if ($myMining){ //If exist
            foreach ($myMining as $mining){
                if ($mining->counter_24_hour > 0 && $mining->running_status == 'start'){

                    //User
                    $user = User::find($mining->user->id);

                    //Get Browsing gap -> if 24 hour greater then
                    $running_time = new Carbon($mining->continue_date_time);

                    //Get Total hour mining start to current
                    $diff_hours = $running_time->diffInHours(Carbon::now());

                    $hours = $diff_hours;
                    if ($hours >= 24 && $mining->counter_24_hour > 0){
                        do {
                            //Know start calculate amount and time
                            User::where('id', $user->id)
                                ->update(['balance'=> $user->balance + $mining->amount_24_hour]);

                            //update mining
                            $mining_for_update = Mining::find($mining->id);
                            $mining_for_update->continue_date_time = Carbon::now();
                            $mining_for_update->counter_24_hour = $mining->counter_24_hour - 1;
                            $mining_for_update->update();

                            //Create ledger
                            $ledger = new UserLedger();
                            $ledger->user_id = $user->id;
                            $ledger->reason = 'vip_income';
                            $ledger->perticulation = 'Your vip income added successful';
                            $ledger->amount = $mining->amount_24_hour;
                            $ledger->debit = $mining->amount_24_hour;
                            $ledger->status = 'approved';
                            $ledger->date = date('d-m-Y H:i');
                            $ledger->save();


                            /**** Start ___Refer income ****/
                            $f_user = User::where('ref_id', $user->ref_by)->first();
                            if ($f_user)
                            {
                                //Get first refer user and give commission after 24 hour
                                $total_amount = $mining->amount_24_hour;
                                $amount = ($total_amount * $mining->package->f_r_24_com) / 100;
                                User::where('id', $f_user->id)
                                    ->update(['balance' => $f_user->balance + $amount]);

                                $f_ledger = new UserLedger();
                                $f_ledger->user_id = $f_user->id;
                                $f_ledger->reason = 'refer_income';
                                $f_ledger->perticulation = 'first_refer_income';
                                $f_ledger->amount = $amount;
                                $f_ledger->debit = $amount;
                                $f_ledger->status = 'approved';
                                $f_ledger->step = 'first';
                                $f_ledger->date = date('d-m-Y H:i');
                                $f_ledger->save();

                                //Get Second refer user and give commission after 24 hour
                                $s_user = User::where('ref_id', $f_user->ref_by)->first();
                                if ($s_user){
                                    $total_amount = $mining->amount_24_hour;
                                    $amount = ($total_amount * $mining->package->s_r_24_com) / 100;
                                    User::where('id', $s_user->id)
                                        ->update(['balance' => $s_user->balance + $amount]);

                                    $s_ledger = new UserLedger();
                                    $s_ledger->user_id = $s_user->id;
                                    $s_ledger->reason = 'refer_income';
                                    $s_ledger->perticulation = 'second_refer_income';
                                    $s_ledger->amount = $amount;
                                    $s_ledger->debit = $amount;
                                    $s_ledger->status = 'approved';
                                    $s_ledger->step = 'second';
                                    $s_ledger->date = date('d-m-Y H:i');
                                    $s_ledger->save();

                                    //Get Third refer user and give commission after 24 hour
                                    $t_user = User::where('ref_id', $s_user->ref_by)->first();
                                    if ($t_user){
                                        $total_amount = $mining->amount_24_hour;
                                        $amount = ($total_amount * $mining->package->t_r_24_com) / 100;
                                        User::where('id', $t_user->id)
                                            ->update(['balance' => $t_user->balance + $amount]);

                                        $t_ledger = new UserLedger();
                                        $t_ledger->user_id = $t_user->id;
                                        $t_ledger->reason = 'refer_income';
                                        $t_ledger->perticulation = 'third_refer_income';
                                        $t_ledger->amount = $amount;
                                        $t_ledger->debit = $amount;
                                        $t_ledger->status = 'approved';
                                        $t_ledger->step = 'third';
                                        $t_ledger->date = date('d-m-Y H:i');
                                        $t_ledger->save();
                                    }
                                }
                            }
                            /**** End ___Refer income ****/

                            //Increment 24 hours
                            $hours = $hours - 24;
                        } while ($hours >= 24 && $mining->counter_24_hour > 0);
                    }

                }else{
                    //end mining
                    $mining_for_update = Mining::find($mining->id);
                    $mining_for_update->running_status = 'end';
                    $mining_for_update->update();

                    //Update purchase
                    $purchase = Purchase::find($mining->purchase_id);
                    $purchase->status = 'inactive';
                    $purchase->update();
                }
            }
        }

        /*** Start Investment Income ***/
        $vip_income = UserLedger::where('user_id', Auth::id())
            ->where('reason', 'vip_income')
            ->get()
            ->pluck('amount')
            ->toArray();
        $vip_income = array_sum($vip_income);

//        $refer_income = UserLedger::where('user_id', Auth::id())
//            ->where('reason', 'refer_income')
//            ->get()
//            ->pluck('amount')
//            ->toArray();
//        $refer_income = array_sum($refer_income);
        /*** End Investment Income ***/

        return view('app.main.order.order', compact('purchases', 'vip_income'));
    }
}
