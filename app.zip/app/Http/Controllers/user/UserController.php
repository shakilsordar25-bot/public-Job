<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\BonusLedger;
use App\Models\Checkin;
use App\Models\Commission;
use App\Models\Deposit;
use App\Models\Fund;
use App\Models\Improvment;
use App\Models\Mining;
use App\Models\Notice;
use App\Models\Package;
use App\Models\PaymentMethod;
use App\Models\Purchase;
use App\Models\User;
use App\Models\UserLedger;
use App\Models\VipSlider;
use App\Models\Withdrawal;
use App\Models\Work;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function dashboard()
    {
        $sliders = VipSlider::where('page_type', 'home_page')->where('status', 'active')->get();
        return view('app.main.index', compact('sliders'));
    }

    public function vip()
    {
        $sliders = VipSlider::where('page_type', 'vip_page')->where('status', 'active')->get();
        $vips = Package::where('status', 'active')->get();
        $vids = my_vips();
        return view('app.main.vip', compact('sliders', 'vips', 'vids'));
    }

    public function profile()
    {
        return view('app.main.profile');
    }


    public function team()
    {
        return view('app.main.team.index');
    }

    public function mine()
    {
        $improvements = Improvment::where('status', 'active')->orderBy('amount_limit')->get();

        //Get big row from improvements
        $largest_improvement_id = 0;
        foreach ($improvements as $element){ //Invest amount wise amount commission
            if (user()->invest_balance >= $element->amount_limit){
                $largest_improvement_id = $element->id;
            }
        }

        $initial_improvement = Improvment::where('status', 'active')->where('id', $largest_improvement_id)->first();
        return view('app.main.mine.mine', compact('initial_improvement'));
    }

    public function setting()
    {
        return view('app.main.mine.setting');
    }

    public function transaction_password()
    {
        return view('app.main.mine.transaction_password');
    }

    public function login_password()
    {
        return view('app.main.mine.login_password');
    }

    public function service()
    {
        return view('app.main.mine.service');
    }

    public function guide()
    {
        return view('app.main.mine.guide');
    }

    public function rechargeway()
    {
        return view('app.main.deposit.way');
    }

    public function recharge()
    {
        return view('app.main.deposit.index');
    }

    public function usdt()
    {
        return view('app.main.deposit.usdt');
    }

    public function youtube()
    {
        return view('app.main.youtube');
    }

    public function onetime()
    {
        return view('app.main.onetime');
    }

    public function work_record()
    {
        return view('app.main.work_record');
    }

    public function worksubmit(Request $request, $code){


        $check = Work::where('code', $code)->where('user_id', auth()->user()->id)->first();
        if ($check){
            return redirect()->route('onetime')->with('success', 'Already submitted');
        }
        $model = new Work();
        $model->user_id = Auth::id();
        $model->amount = 5;
        $model->code = $code;
        $model->status = 'inactive';
        $path = uploadImage(false ,$request, 'prof', 'upload/proff/', null, null ,$model->prof);
        $model->prof = $path ?? $model->prof;
        $model->save();

        return redirect()->route('onetime')->with('success', 'Success. Wait for approval.');
    }

    public function income()
    {
        /*** Start Investment Income ***/
        $improvements = Improvment::where('status', 'active')->orderBy('amount_limit')->get();

        //Get big row from improvements
        $largest_improvement_id = 0;
        foreach ($improvements as $element){ //Invest amount wise amount commission
            if (user()->invest_balance >= $element->amount_limit && user()->invest_balance <= $element->between_amount){
                $largest_improvement_id = $element->id;
            }
        }

        //get higher amount
        $higher_improvements = Improvment::where('status', 'active')->max('between_amount');
        if (user()->invest_balance > $higher_improvements){
            $higher_invest_id = Improvment::where('status', 'active')->where('between_amount', $higher_improvements)->first();
            $largest_improvement_id = $higher_invest_id->id;
        }

        $initial_improvement = Improvment::where('status', 'active')->where('id', $largest_improvement_id)->first();

        $incomes = Commission::where('user_id', Auth::id())
            ->where('reason', 'amount_commission')
            ->where('status', 'active')
            ->where('is_receive', 'yes')
            ->orderByDesc('id')->get();

        //Get total transaction reword
        $total_checkin = Checkin::where('user_id', Auth::id())->get()->sum('amount');
        //Get spin bonus
        $total_spin = BonusLedger::where('user_id', Auth::id())->get()->sum('amount');
        $total_reword = $total_checkin + $total_spin;

        return view('app.main.income', compact('incomes', 'total_reword', 'initial_improvement'));
    }


    public function received_amount(Request $request)
    {
        $user = Auth::user();
        if ($user->com_receible > 0) {
            $improvement = Improvment::find($request->improvement_id);


            //Main user balance added
            $upDateuser = User::where('id', $user->id)->first();

            $my_commission = $user->com_receible;

            $upDateuser->commission_balance = $upDateuser->commission_balance + $my_commission;
            $upDateuser->com_receible = 0;

            $incomes = Commission::where('user_id', Auth::id())
                ->where('reason', 'amount_commission')
                ->where('status', 'active')
                ->where('is_receive', 'no')
                ->orderByDesc('id')->get();

            foreach ($incomes as $income){
                Commission::where('id', $income->id)->update(
                    ['is_receive'=> 'yes']
                );
            }

            $upDateuser->save();

            /**** Start Refer commission ****/
            $f_user = User::where('ref_id', user()->ref_by)->first();
            if ($f_user)
            {
                //Get first refer user and give commission after 24 hour
                $total_amount = $my_commission;
                $amount = ($total_amount * setting('first_refer_commission')) / 100;
                User::where('id', $f_user->id)
                    ->update([
                        'recharge_1_com'=> $f_user->recharge_1_com + $amount
                    ]);

                $commission = new Commission();
                $commission->user_id = $f_user->id;
                $commission->amount = $amount;
                $commission->reason = 'first_refer_commission';
                $commission->level = 'first';
                $commission->date = Carbon::now();
                $commission->save();

                //Get Second refer user and give commission after 24 hour
                $s_user = User::where('ref_id', $f_user->ref_by)->first();
                if ($s_user){
                    $total_amount = $my_commission;
                    $amount = ($total_amount * setting('second_refer_commission')) / 100;
                    User::where('id', $s_user->id)
                        ->update([
                            'recharge_2_com'=> $s_user->recharge_2_com + $amount
                        ]);

                    //
                    $commission = new Commission();
                    $commission->user_id = $s_user->id;
                    $commission->amount = $amount;
                    $commission->reason = 'second_refer_commission';
                    $commission->level = 'second';
                    $commission->date = Carbon::now();
                    $commission->save();

                    //Get Third refer user and give commission after 24 hour
                    $t_user = User::where('ref_id', $s_user->ref_by)->first();
                    if ($t_user){
                        $total_amount = $my_commission;
                        $amount = ($total_amount * setting('third_refer_commission')) / 100;
                        User::where('id', $t_user->id)
                            ->update([
                                'recharge_3_com'=> $t_user->recharge_3_com + $amount
                            ]);

                        //
                        $commission = new Commission();
                        $commission->user_id = $t_user->id;
                        $commission->amount = $amount;
                        $commission->reason = 'third_refer_commission';
                        $commission->level = 'third';
                        $commission->date = Carbon::now();
                        $commission->save();
                    }
                }
            }
            /**** End Refer commission ****/
            return response()->json(['status'=> true, 'message'=> 'Amount received', 'amount'=> Auth::user()->com_receible]);
        }else{
            return response()->json(['status'=> false, 'message'=> 'Amount empty', 'amount'=> Auth::user()->com_receible]);
        }
    }

    public function usdt_rechargeView($amount)
    {
        return view('app.main.deposit.usdt', compact('amount'));
    }

    public function usdt_recharge(Request $request)
    {
        $rate = setting('usdt');
        $usdt = $request->usdt;
        $amount = $usdt * $rate;

        $model = new Deposit();

        $path = uploadImage(false ,$request, 'prof', 'upload/prof/', null, null ,$model->photo);

        $model->user_id = Auth::id();
        $model->method_name = 'usdt';
        $model->photo = $path;
        $model->order_id = 'S'.rand(00000000,99999999).time();
        $model->transaction_id = 'usdt';
        $model->usdt = $usdt;
        $model->amount = $usdt * $rate;
        $model->final_amount = $amount;
        $model->date = Carbon::now();
        $model->status = 'pending';
        $model->save();


        return redirect()->route('recharge')->with('message', 'USDT Recharge Success');
    }


    public function reword()
    {
        $i = Auth::user();

        $refer_users = User::where('ref_by', $i->ref_id)->get();

        //Check first time my users purchase any vip
        $amount = 0;
        if ($i->first_time_bonus != 1) {
            foreach ($refer_users as $user) {
                $purchase = Purchase::where('user_id', $user->id)->first();
                if ($purchase) {
                    $vip = Package::find($purchase->id);
                    $amount = ($vip->price * $vip->sponsor) / 100;
                }
            }
        }

        return view('app.main.reword.index', compact('refer_users', 'amount'));
    }

    public function get_first_time_refer_bonus(Request $request)
    {
        $i = Auth::user();
        User::where('id', $i->id)->update([
            'balance' => $i->balance + $request->amount,
            'first_time_bonus' => 1
        ]);

        //Create ledger
        $model = new UserLedger();
        $model->user_id = Auth::id();
        $model->reason = 'first_time_purchase_bonus';
        $model->perticulation = 'First time purchase bonus';
        $model->amount = $request->amount;
        $model->debit = $request->amount;
        $model->status = 'approved';
        $model->date = Carbon::now();
        $model->save();

        return response()->json(['status'=> true, 'message'=> 'Congratulation you get '.$request->amount]);
    }

    public function history()
    {
        $recharges = Deposit::where('user_id', Auth::id())->orderByDesc('id')->get();
        $withdraws = Withdrawal::where('user_id', Auth::id())->orderByDesc('id')->get();
        return view('app.main.history.history', compact('recharges', 'withdraws'));
    }

    public function update_profile(Request $request)
    {
        $user = User::find(Auth::id());
        $path = uploadImage(false, $request, 'photo', 'upload/profile/', 200, 200, $user->photo);
        $user->photo = $path ?? $user->photo;

        $user->update();
        return redirect()->route('my.profile')->with('success', 'Successfully updated your profile photo');
    }

    public function personal_details()
    {
        return view('app.main.update_personal_details');
    }

    public function personal_details_submit(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'name' => 'required',
            'username' => 'required',
            'email' => 'required|email',
            'password' => 'required',
        ]);
        if ($validate->fails()) {
            return redirect()->route('my.profile')->withErrors($validate->errors());
        }

        $user = User::find(Auth::id());

        $user->name = $request->name;
        $user->username = $request->username;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->update();
        return redirect()->route('my.profile')->with('success', 'Successfully updated your personal details and credentials');
    }

    public function bonus_ledger()
    {
        $datas = BonusLedger::with(['bonus', 'user'])->where('user_id', Auth::id())->orderByDesc('id')->get();
        return view('app.main.bonus.bonus-preview', compact('datas'));
    }

    public function payment_ledger()
    {
        $payments = Deposit::where('user_id', Auth::id())->orderByDesc('id')->get();
        return view('app.main.recharge.payment-preview', compact('payments'));
    }

    public function withdraw_ledger()
    {
        $withdraws = Withdrawal::with('payment_method')->where('user_id', Auth::id())->orderByDesc('id')->get();
        return view('app.main.withdraw.withdraw-preview', compact('withdraws'));
    }

    public function emailVerification($email)
    {
        $email = base64_decode($email);
        $user = User::where('email', $email)->first();
        if ($user) {
            return view('app.auth.verify', compact('user'));
        } else {
            return redirect()->route('register')->with('error', 'Registration failed. please try again');
        }
    }

    public function verified_to_login($user_id, $code)
    {
        $user = User::where('id', $user_id)->first();
        if ($user && $user->code == $code) {
            User::where('id', $user->id)->update([
                'email_verified_at' => Carbon::now()
            ]);

            //Create Purchase record
            $p = Package::where('is_default', '1')->first();
            $model = new Purchase();
            $model->user_id = $user_id;
            $model->package_id = $p ? $p->id : 1;
            $model->amount = $p ? $p->price : 0;
            $model->date = Carbon::now();
            $model->status = 'active';
            $model->save();

            $ledger = new UserLedger();
            $ledger->user_id = $user_id;
            $ledger->reason = 'purchase_package';
            $ledger->perticulation = 'Congratulations already activate default vip for registered in our platform.';
            $ledger->amount = $p ? $p->price : 0;
            $ledger->credit = $p ? $p->price : 0;
            $ledger->status = 'pending';
            $ledger->date = date('d-m-Y H:i');
            $ledger->save();

            Auth::login($user);
            return redirect()->route('dashboard')->with('success', 'You are successfully logged in.');
        } else {
            return redirect()->route('register')->with('error', 'Registration failed. please try again');
        }
    }

    public function verification_time_out($user_id)
    {
        User::find($user_id)->delete();
        return redirect()->route('register')->with('error', 'Registration failed. please try again');
    }


    public function notice()
    {
        $datas = Notice::where('status', 'active')->orderByDesc('id')->get();
        return view('app.main.notice', compact('datas'));
    }


    public function card()
    {
        $methods = PaymentMethod::where('status', 'active')->where('id', '!=', 4)->get();

        return view('app.main.gateway_setup', compact('methods'));
    }

    public function setupGatewayView(Request $request)
    {
        if ($request->gateway_method && $request->gateway_number) {
            User::where('id', Auth::id())->update([
                'gateway_method' => $request->gateway_method,
                'gateway_number' => $request->gateway_number,
            ]);
            return redirect()->route('user.card')->with('success', 'Successful.... updated your bank information');
        } else {
            return redirect()->route('user.card')->with('error', 'Something went wrong.');
        }
    }


    public function setupGateway(Request $request)
    {
        $code = session()->get('code');
        if ($code != null) {
            if ($request->code == $code) {
                User::where('id', Auth::id())->update([
                    'gateway_method' => $request->gateway_method,
                    'gateway_number' => $request->gateway_number,
                ]);
                return redirect()->route('user.card')->with('success', 'Successful....');
            } else {
                return redirect()->route('user.card')->with('error', 'Verification dode does not match.');
            }
        } else {
            return redirect()->route('user.card')->with('error', 'something went wrong...');
        }
    }

    public function invite()
    {
        $vips = Package::where('status', 'active')->get();
        $commissions = UserLedger::where('user_id', Auth::id())
            ->where('reason', '!=', 'vip_request')
            ->where('reason', '!=', 'purchase_package')
            ->orderBy('created_at', 'desc')
            ->get();

        return view('app.main.invite', compact('vips', 'commissions'));
    }

    public function help_center()
    {
        return view('app.main.help_center');
    }

    public function add_bank()
    {
        return view('app.main.bank.index');
    }


    public function add_bank_usdt()
    {
        return view('app.main.bank.usdt');
    }

    public function add_bank_setup()
    {
        return view('app.main.bank.index_setup');
    }

    public function company()
    {
        return view('app.main.company');
    }

    public function announcement()
    {
        return view('app.main.announcement');
    }

    public function rules()
    {
        return view('app.main.rules');
    }

    public function transfer()
    {
        return view('app.main.transfer');
    }

    public function balance_transfer(Request $request){
        $user = Auth::user();
        if ($user->commission_balance >= $request->amount){

            User::where('id', $user->id)->update([
                'commission_balance'=> $user->commission_balance - $request->amount,
                'invest_balance'=> $user->invest_balance + $request->amount,
            ]);
            return back()->with('success', 'Balance transfer successful.');
        }else{
            return back()->with('error', 'Please enter less then your commission balance');
        }
    }

    public function add_bank_setup_confirm(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'name' => 'required',
            'gateway_method' => 'required',
            'gateway_number' => 'required',
        ]);

        if ($validate->fails()) {
            return redirect()->route('user.bank')->withErrors($validate->errors());
        }

        $user = User::find(Auth::id());

        $user->name = $request->name;
        $user->gateway_number = $request->gateway_number;
        $user->gateway_method = $request->gateway_method;
        $user->update();
        return redirect()->route('user.bank')->with('success', 'Success');
    }

    public function usdt_setup_confirm(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'usdt_name' => 'required',
            'usdt' => 'required',
        ]);

        if ($validate->fails()) {
            return redirect()->route('user.usdt')->withErrors($validate->errors());
        }

        $user = User::find(Auth::id());

        $user->usdt_name = $request->usdt_name;
        $user->usdt = $request->usdt;
        $user->update();
        return redirect()->route('user.usdt')->with('success', 'Success');
    }

    public function delete_bank_acc()
    {
        $user = User::find(Auth::id());
        $user->bank_name = null;
        $user->gateway_number = null;
        $user->gateway_method = null;
        $user->update();
        return redirect()->route('user.bank')->with('success', 'Bank account delete successfully please created new again.');
    }


    //update user name
    public function update_name(Request $request)
    {
        $user = User::find(Auth::id());
        $user->name = $request->name;
        $user->update();
        return redirect()->route('setting')->with('success', 'Name changed success');
    }

    public function setting_acc_number_bkash(Request $request)
    {
        $user = User::find(Auth::id());
        $user->bkash = $request->bkash;
        $user->update();
        return redirect()->route('setting')->with('success', 'bKash number changed success');
    }

    public function setting_acc_number_nagad(Request $request)
    {
        $user = User::find(Auth::id());
        $user->nagad = $request->nagad;
        $user->update();
        return redirect()->route('setting')->with('success', 'Nagad number changed success');
    }

    public function setting_acc_number_usdt(Request $request)
    {
        $user = User::find(Auth::id());
        $user->usdt = $request->usdt;
        $user->update();
        return redirect()->route('setting')->with('success', 'USDT number changed success');
    }

    public function setting_withdraw_password(Request $request)
    {
        $user = User::find(Auth::id());
        $user->w_password = $request->wpass;
        $user->update();
        return redirect()->route('setting')->with('success', 'Withdraw password changed success');
    }

    public function change_user_pass()
    {
        return view('app.main.change_user_pass');
    }

    public function password_chanage_confirm(Request $request){
        if (Hash::check($request->current_password, Auth::user()->password)) {
            if ($request->new_password == $request->confirm_password){
                $user = User::find(Auth::id());
                $user->password = Hash::make($request->new_password);
                $user->update();
                return redirect()->back()->with('success', 'Password change successful.');
            }else{
                return redirect()->back()->with('error', 'Confirm password not match');
            }
        }else{
            return redirect()->back()->with('error', 'Current password dose not match.');
        }
    }

    public function record($type = null)
    {
        return view('app.main.record', compact('type'));
    }


    public function recharge_confirm_submit(Request $request)
    {
        $model = new Deposit();
        $path = uploadImage(false ,$request, 'photo', 'upload/usdt/', 200, 200 ,$model->photo);
        $model->user_id = Auth::id();
        $model->method_name = $request->paymethod;
        $model->order_id = rand(0000,9999).rand(0000,9999);
        $model->transaction_id = $request->transaction_id;
        $model->number = '0000000000';
        $model->amount = $request->amount;
        $model->photo = $path ?? $model->photo;
        $model->charge_amount = 0;
        $model->final_amount = $request->amount;
        $model->date = date('d-m-Y H:i:s');
        $model->status = 'pending';
        $model->save();

        //Create user ledger
        $ledger = new UserLedger();
        $ledger->user_id = Auth::id();
        $ledger->reason = 'user_deposit';
        $ledger->perticulation = 'user deposit using externalment';
        $ledger->amount = $request->amount;
        $ledger->debit = $request->amount;
        $ledger->status = 'pending';
        $ledger->date = date('y-m-d');
        $ledger->save();
        return redirect('recharge')->with('success', 'Recharge Successful.');
    }


    public function confirm_submit(Request $request)
    {
        $data = $request->all();
        $model = new Deposit();
        $model->user_id = $data['ui'];
        $model->method_name = $data['pm'];
        $model->method_number = '01000000000';
        $model->order_id = $data['oid'];
        $model->transaction_id = $data['tid'];
        $model->number = $data['aca'];
        $model->amount = $data['amount'];
        $model->final_amount = $data['amount'];
        $model->usdt = $data['amount'] / setting('usdt');
        $model->date = Carbon::now();
        $model->status = 'pending';
        $model->save();
        return response()->json(['status'=>true, 'data'=> $data]);
    }

    public function download_apk(){
        $file= public_path('ftx.apk');
        return response()->file($file ,[
            'Content-Type'=>'application/vnd.android.package-archive',
            'Content-Disposition'=> 'attachment; filename="ftx66.apk"',
        ]) ;
    }

    public function invest()
    {
        $improvements = Improvment::where('status', 'active')->get();

        //My level
        $level = Improvment::where('status', 'active')->where('amount_limit', '<=', user()->invest_balance)
            ->where('between_amount', '>=', user()->invest_balance)
            ->first();

        if (!$level){
            $maximumAmount = Improvment::where('status', 'active')->max('between_amount');
            if (user()->invest_balance > $maximumAmount){
                $level = Improvment::where('status', 'active')->where('between_amount', $maximumAmount)->first();
            }
        }

        return view('app.main.invest', compact('improvements', 'level'));
    }


    public function balanceHistory()
    {
        $invest_commission = Commission::where('user_id', Auth::id())->where('reason', 'amount_commission')->get()->sum('amount');

        $spin_commission = UserLedger::where('user_id', Auth::id())->where('reason', 'get_bonus')->get()->sum('amount');

        $checkin_commission = Checkin::where('user_id', Auth::id())->get()->sum('amount');


        //Recharge Commission
        $rechargeCommission['first_recharge_commission'] = Commission::where('user_id', Auth::id())->where('reason', 'first_refer_recharge_commission')->get()->sum('amount');
        $rechargeCommission['second_recharge_commission'] = Commission::where('user_id', Auth::id())->where('reason', 'second_refer_recharge_commission')->get()->sum('amount');
        $rechargeCommission['third_recharge_commission'] = Commission::where('user_id', Auth::id())->where('reason', 'third_refer_recharge_commission')->get()->sum('amount');
        $rechargeCommission = $rechargeCommission['first_recharge_commission'] + $rechargeCommission['second_recharge_commission'] + $rechargeCommission['third_recharge_commission'];


        //Refer commission
        $team_commission['first_team_commission'] = Commission::where('user_id', auth()->user()->id)->where('reason', 'first_refer_commission')->get()->sum('amount');
        $team_commission['second_team_commission'] =  Commission::where('user_id', auth()->user()->id)->where('reason', 'second_refer_commission')->get()->sum('amount');
        $team_commission['third_team_commission'] = Commission::where('user_id', auth()->user()->id)->where('reason', 'third_refer_commission')->get()->sum('amount');
        $refer_commission = $team_commission['first_team_commission'] + $team_commission['second_team_commission'] + $team_commission['third_team_commission'];

        return view('app.main.balance-history',
            compact(
                'invest_commission',
                'spin_commission',
                'checkin_commission',
                'rechargeCommission',
                'refer_commission'
            ));
    }
}







