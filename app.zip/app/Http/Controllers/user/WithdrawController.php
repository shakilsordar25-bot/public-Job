<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\PaymentMethod;
use App\Models\User;
use App\Models\UserLedger;
use App\Models\Withdrawal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\Deposit;
use App\Models\Purchase;
use Carbon\Carbon;

class WithdrawController extends Controller
{
    //
    public function withdraw()
    {
        return view('app.main.withdraw.index');
    }

    public function withdrawRequest(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'amount' => 'required|numeric',
        ]);

        $user = Auth::user();

        if ($user->gateway_number == null || $user->gateway_method == null ){
            return response()->json(['status' => false, 'message' => "Please setup your bank."]);
        }

        //Check USDT address set or not
//        if ($request->has('usdt')){
//            if (!$user->usdt){
//                return response()->json(['status' => false, 'message' => "First setup USDT bank."]);
//            }
//        }
        if (true) {
            if ($validate->fails()) {
                return redirect()->back()->withErrors('errors', $validate->errors());
            }

            //Check user payment or not
//            $payments = Deposit::where('user_id', $user->id)->where('status', 'approved')->get();
//            if ($payments->count() < 1) {
//                return response()->json(['status' => false, 'message' => "You can't withdraw before deposit"]);
//            }
            if ($request->amount <= $user->commission_balance) {
                if ($request->amount >= setting('minimum_withdraw')) {
                    if ($request->amount <= setting('maximum_withdraw')) {
                        $charge = 0;
                        if ($request->has('usdt')){
                            if (setting('usdt_withdraw_charge') > 0) {
                                $charge = 1;
                            }
                        }else{
                            if (setting('withdraw_charge') > 0) {
                                $charge = ($request->amount * setting('withdraw_charge')) / 100;
                            }
                        }

                        //Update User Balance
                        $balance = $user->balance - $request->amount;
                        User::where('id', $user->id)->update([
                            'commission_balance' => $user->commission_balance - $request->amount,
                        ]);

                        $currency = $request->has('usdt') ? 'USDT' : 'BDT';

                        //Withdraw
                        $withdrawal = new Withdrawal();
                        $withdrawal->user_id = $user->id;
                        $withdrawal->method_name = $user->gateway_method;
                        $withdrawal->number = $user->gateway_number;
                        $withdrawal->amount = $request->amount;
                        $withdrawal->currency = $currency;
                        $withdrawal->charge = $charge;
                        $withdrawal->final_amount = $request->amount - $charge;
                        $withdrawal->status = 'pending';

                        //User Ledger
                        if ($withdrawal->save()) {
                            $ledger = new UserLedger();
                            $ledger->user_id = $user->id;
                            $ledger->reason = 'withdraw_request';
                            $ledger->perticulation = 'Your withdraw request status is pending please wait for admin approval or communication with us.';
                            $ledger->amount = $request->amount;
                            $ledger->debit = $request->amount - $charge;
                            $ledger->status = 'pending';
                            $ledger->date = date('d-m-Y H:i');
                            $ledger->save();
                        }

                        return response()->json(['status' => true, 'message' => "Withdraw successfully."]);
                    } else {
                        return response()->json(['status' => false, 'message' => 'success', 'Amount less then ' . setting('maximum_withdraw')]);
                    }
                } else {
                    return response()->json(['status' => false, 'message' => 'Amount greater then ' . setting('minimum_withdraw')]);
                }
            } else {
                return response()->json(['status' => false, 'message' => 'Only Commission low.']);
            }
        } else {
            return response()->json(['status' => false, 'message' => "Withdraw time 10AM to 5PM"]);
        }
    }

    public function withdrawPreview()
    {
        $withdraws = Withdrawal::with('payment_method')->where('user_id', Auth::id())->orderByDesc('id')->get();
        return view('app.main.withdraw.withdraw-preview', compact('withdraws'));
    }

    public function usdt_withdraw()
    {
        return view('app.main.withdraw.usdt');
    }
}
