<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\Mining;
use App\Models\Package;
use App\Models\Purchase;
use App\Models\User;
use App\Models\UserLedger;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PurchaseController extends Controller
{
    public function purchaseConfirmation($id)
    {
        $package = Package::find($id);
        $user = Auth::user();

        //Check status
        if ($package->status != 'active')
        {
            return back()->with('error', "This vip is not activate.");
        }

        //Check default package
        if ($package){
            //Check user balance
            if ($package->price <= $user->balance){
                //User Balance Update with purchase confirmation
                User::where('id', $user->id)->update([
                    'balance'=> $user->balance - $package->price,
                ]);

                //Purchase Table Create
                $purchase = new Purchase();
                $purchase->user_id = Auth::id();
                $purchase->package_id = $package->id;
                $purchase->amount = $package->price;
                $purchase->hours = $package->hours;
                $purchase->date = date('d-m-Y H:i');
                $purchase->status = 'active';
                $purchase->save();

                //Create Ledger
                $ledger = new UserLedger();
                $ledger->user_id = $user->id;
                $ledger->reason = 'vip_request';
                $ledger->perticulation = 'Your vip purchase request sent successfully please with for admin approval and after approval start your mining button. thank you';
                $ledger->amount = $package->price;
                $ledger->credit = $package->price;
                $ledger->status = 'approved';
                $ledger->date = date('d-m-Y H:i');
                $ledger->save();

                //Create mining info
                $mining = new Mining();
                $mining->user_id = $user->id;
                $mining->package_id = $package->id;
                $mining->purchase_id = $purchase->id;
                $mining->running_start_date = Carbon::now();
                $mining->running_end_date = Carbon::now()->addDays($package->validity);
                $mining->total_time = $package->validity * 24; // total hour
                $mining->continue_date_time = Carbon::now();
                $mining->amount_24_hour = $package->commission_with_avg_amount != 0 ? $package->commission_with_avg_amount / $package->validity : 0;
                $mining->counter_24_hour = $package->validity;
                $mining->running_status = 'start';
                $mining->amount_status = 'false';
                $mining->save();

                //refer income
                /**** Start ___Refer income ****/
                $f_user = User::where('ref_id', Auth::user()->ref_by)->first();
                if ($f_user)
                {
                    //Get first refer user and give commission after 24 hour
                    $total_amount = $package->price;
                    $amount = ($total_amount * $package->first_refer_purchase_commission) / 100;
                    User::where('id', $f_user->id)
                        ->update(['balance' => $f_user->balance + $amount]);

                    $f_ledger = new UserLedger();
                    $f_ledger->user_id = $f_user->id;
                    $f_ledger->reason = 'refer_income';
                    $f_ledger->perticulation = 'purchase_commission';
                    $f_ledger->amount = $amount;
                    $f_ledger->debit = $amount;
                    $f_ledger->status = 'approved';
                    $f_ledger->step = 'first';
                    $f_ledger->date = date('d-m-Y H:i');
                    $f_ledger->save();

                    //Get Second refer user and give commission after 24 hour
                    $s_user = User::where('ref_id', $f_user->ref_by)->first();
                    if ($s_user){
                        $total_amount = $package->price;
                        $amount = ($total_amount * $package->second_refer_purchase_commission) / 100;
                        User::where('id', $s_user->id)
                            ->update(['balance' => $s_user->balance + $amount]);

                        $s_ledger = new UserLedger();
                        $s_ledger->user_id = $s_user->id;
                        $s_ledger->reason = 'refer_income';
                        $s_ledger->perticulation = 'purchase_commission';
                        $s_ledger->amount = $amount;
                        $s_ledger->debit = $amount;
                        $s_ledger->status = 'approved';
                        $s_ledger->step = 'second';
                        $s_ledger->date = date('d-m-Y H:i');
                        $s_ledger->save();

                        //Get Third refer user and give commission after 24 hour
                        $t_user = User::where('ref_id', $s_user->ref_by)->first();
                        if ($t_user){
                            $total_amount = $package->price;
                            $amount = ($total_amount * $package->third_refer_purchase_commission) / 100;
                            User::where('id', $t_user->id)
                                ->update(['balance' => $t_user->balance + $amount]);

                            $t_ledger = new UserLedger();
                            $t_ledger->user_id = $t_user->id;
                            $t_ledger->reason = 'refer_income';
                            $t_ledger->perticulation = 'purchase_commission';
                            $t_ledger->amount = $amount;
                            $t_ledger->debit = $amount;
                            $t_ledger->status = 'approved';
                            $t_ledger->step = 'third';
                            $t_ledger->date = date('d-m-Y H:i');
                            $t_ledger->save();
                        }
                    }
                }
                /**** End ___Refer income ****/

                return redirect()->route('dashboard')->with('success', "Congratulations ".Auth::user()->name ?? Auth::user()->username .". VIP purchase successful.");
            }else{
                return back()->with('error', "Your sufficient balance is low.");
            }
        }else{
            return back()->with('error', "This is default vip.");
        }
    }

    protected function ref_user($ref_by)
    {
        return User::where('ref_id', $ref_by)->first();
    }
}
