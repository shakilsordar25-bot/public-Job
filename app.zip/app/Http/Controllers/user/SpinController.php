<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\Bonus;
use App\Models\BonusLedger;
use App\Models\Spin;
use App\Models\User;
use App\Models\UserLedger;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class SpinController extends Controller
{
    public function spin()
    {
        return view('app.main.spin.index');
    }

    public function submitspin(Request $request)
    {
        Validator::make($request->all(), [
            'bonus_code' => 'required'
        ]);

        $code = $request->bonus_code;
        $bonus = Bonus::where('status', 'active')->first();
        $user = Auth::user();
        if ($bonus) {
            if ($code == $bonus->code) {
                //Check this bonus use this user.
                $checkBonusUses = BonusLedger::where('bonus_id',$bonus->id )->where('user_id', $user->id)->first();
                if ($checkBonusUses){
                    return response()->json(['status' => false, 'message' => 'Already use.']);
                }
                if ($bonus->counter < $bonus->set_service_counter) {
                    return response()->json(['status' => true, 'message' => 'Congratulations. Start Spin' ]);
                } else {
                    return response()->json(['status' => false, 'message' => 'Our targeted member fulfil.']);
                }
            } else {
                return response()->json(['status' => false, 'message' => 'Code invalid.']);
            }
        } else {
            return response()->json(['status' => false, 'message' => 'Not available.']);
        }
    }



    public function submitspinamount(Request $request)
    {
        $spin = $request->spin;
        $user = Auth::user();

        if ($spin == 'again'){
            return response()->json(['status' => 'spin_fail', 'message' => 'Please try again']);
        }

        $result = '';
        $reason = '';

        $updateUser = User::where('id', $user->id)->first();
        if ($spin == '5'){
            $result = '+5';
            $updateUser->commission_balance = $updateUser->commission_balance + 5;
            $reason = 'WOW Get Amount '.price(5);

        }elseif ($spin == 'loss'){
            $result = 'loss -10';
            $updateUser->commission_balance = $updateUser->commission_balance - 10;
            $reason = 'OPPs Loss Amount '.price(10);

        }elseif ($spin == '-10'){
            $result = 'loss -10';
            $updateUser->commission_balance = $updateUser->commission_balance - 10;
            $reason = 'OPPs Loss Amount '.price(10);

        }elseif ($spin == 'thankyou'){
            $result = 'thankyou';
            $reason = 'Thank you';

        }elseif ($spin == '10+'){
            $result = '+10';
            $updateUser->commission_balance = $updateUser->commission_balance + 10;
            $reason = 'WOW Get Amount '.price(10);

        }elseif ($spin == 'star'){
            $result = 'star user';
            $reason = 'You are star member';

        }elseif ($spin == '-3'){
            $result = '-3';
            $updateUser->commission_balance = $updateUser->commission_balance - 3;
            $reason = 'OPPs Loss Amount '.price(3);

        }elseif ($spin == 'winner'){
            $result = 'winner +10';
            $updateUser->commission_balance = $updateUser->commission_balance + 10;
            $reason = 'WOW Get Amount '.price(10);
        }
        $updateUser->save();

        //Now create spin history
        $model = new Spin();
        $model->user_id = $user->id;
        $model->result =  $result;
        $model->reason =  $reason;
        $model->status = 'active';
        $model->save();
        return response()->json(['status' => true, 'message' => $reason]);
    }

    public function spin_result()
    {
        $spins = Spin::where('user_id', Auth::id())->orderByDesc('id')->get();
        return view('app.main.spin.ledger', compact('spins'));
    }
}
