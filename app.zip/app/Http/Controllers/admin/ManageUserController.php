<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Models\AdminLedger;
use App\Models\Bonus;
use App\Models\Commission;
use App\Models\Deposit;
use App\Models\Mining;
use App\Models\Purchase;
use App\Models\User;
use App\Models\UserLedger;
use App\Models\Work;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class ManageUserController extends Controller
{
    public function customers()
    {
        $users = User::where('id', '!=', '1')->orderByDesc('id')->paginate(90);
        return view('admin.pages.users.users', compact('users'));
    }

    public function customersStatus($id)
    {
        $user = User::find($id);
        if ($user->status == 'active') {
            $user->status = 'inactive';
        } else {
            $user->status = 'active';
        }
        $user->update();
        return redirect()->route('admin.customer.index')->with('success', 'Successfully changed user status.');
    }

    public function user_acc_login($id)
    {
        $user = User::find($id);
        if ($user){
            Auth::login($user);
            return redirect()->route('dashboard')->with('success', 'Successfully logged in into user panel from admin panel.');
        }else{
            abort(403);
        }
    }

    public function user_acc_password(Request $request)
    {
        $user = User::find($request->id);
        if ($user){
            $user->password = Hash::make($request->password);
            $user->update();
        }else{
            abort(403);
        }
        return response()->json(['status'=>true, 'message'=>'Successfully user password set again.']);
    }

    public function onetimestatus($id)
    {
        $model = Work::find($id);
        $user = User::where('id', $model->user_id)->first();



        if ($model->status == 'active'){
            $model->status = 'inactive';

            $user->commission_balance = $user->commission_balance - 5;
            $model->save();
        }else{
            $model->status = 'active';

            $user->commission_balance = $user->commission_balance + 5;
            $model->save();
        }


        $user->save();


        return redirect()->back()->with('success', 'Successfully change status');
    }

    public function pendingPayment()
    {
        $title = 'Pending';

        $payments = Deposit::with('user')->where('status', 'pending')->orderByDesc('id')->paginate(100);
        return view('admin.pages.payment.list', compact('payments', 'title'));
    }



    public function rejectedPayment()
    {
        $title = 'Rejected';
        $payments = Deposit::with('user')->where('status', 'rejected')->orderByDesc('id')->get();
        return view('admin.pages.payment.list', compact('payments', 'title'));
    }

    public function approvedPayment()
    {
        $title = 'Approved';
        $payments = Deposit::with('user')->where('status', 'approved')->orderByDesc('id')->get();
        return view('admin.pages.payment.list', compact('payments', 'title'));
    }

    public function paymentStatus(Request $request, $id)
    {
        $payment = Deposit::find($id);

        if ($request->status == 'approved'){
            $user = User::find($payment->user_id);
            $user->balance += $payment->final_amount;
            $user->update();
        }
        $ledger = new UserLedger();
        $ledger->user_id = $payment->user_id;
        $ledger->reason = 'payment_'.$request->status;
        $ledger->perticulation = 'Your payment already '.$request->status. '. thanks for invest in our '.env('APP_NAME');
        $ledger->amount = $payment->amount;
        $ledger->debit = $request->status == 'approved' ? $payment->final_amount : 0;
        $ledger->status = $request->status;
        $ledger->date = date('d-m-Y H:i');
        $ledger->save();

        $payment->status = $request->status;
        $payment->feedback = $request->note;
        $payment->update();
        return redirect()->back()->with('success', 'Payment status change successfully.');
    }

    public function search()
    {
        return view('admin.pages.users.search');
    }

    public function searchSubmit(Request $request)
    {
        if ($request->ref_id){
            $user = User::where('ref_id', $request->ref_id)->first();
            if ($user){
                return view('admin.pages.users.search', compact('user'));
            }
        }
        return redirect()->route('admin.search.user')->with('error', 'OOPs User not found.');
    }

    public function purchaseRecord()
    {
        $users = User::where('invest_balance', '>', 0)->orderByDesc('id')->paginate(25);
        return view('admin.pages.users.purchase-record', compact('users'));
    }

    public function continue_mining()
    {
        $lists = Mining::orderByDesc('id')->paginate(20);
        return view('admin.pages.mining.index', compact('lists'));
    }

    //Bonus
    public function bonusCode(Request $request)
    {
        $bonus = Bonus::where('code', $request->bonus)->first();
        if ($bonus){
            if ($bonus->status == 'active'){
                User::where('id', $request->id)->update([
                    'bonus_code'=> trim($request->bonus)
                ]);
                return response()->json(['status'=>true, 'message'=>'Successfully sent bonus code.']);
            }else{
                return response()->json(['status'=>true, 'message'=>'Bonus code not activate.']);
            }
        }else{
            return response()->json(['status'=>true, 'message'=>'Bonus not found.']);
        }
    }


    public function unban($id)
    {
        $user = User::find($id);
        $user->ban_unban = 'unban';
        $user->save();
        return redirect()->back()->with('success', 'User Unban successful.');
    }


    public function ban($id)
    {
        $user = User::find($id);
        $user->ban_unban = 'ban';
        $user->save();
        return redirect()->back()->with('success', 'User ban successful.');
    }

  public function paymentStatusRejected($id){
        $payment = Deposit::find($id);

        if ($payment->status == 'approved'){
            $user = User::find($payment->user_id);
            $user->invest_balance -= $payment->final_amount;
            $user->update();
        }

        $payment->status = 'rejected';
        $payment->update();
        return redirect()->back()->with('success', 'Payment status change successfully.');
    }

     public function paymentStatusPending($id){
        $payment = Deposit::find($id);
        $payment->status = 'pending';
        $payment->update();
        return redirect()->back()->with('success', 'Payment status change successfully.');
    }


    public function paymentStatusApproved($id)
    {
        $payment = Deposit::find($id);

        if ($payment->status == 'pending'){
            $user = User::find($payment->user_id);
            $user->invest_balance += $payment->final_amount;
            $user->update();

            $ledger = new UserLedger();
            $ledger->user_id = $payment->user_id;
            $ledger->reason = 'payment_approved';
            $ledger->perticulation = 'Your payment already '.'approved'. '. thanks for invest in our '.env('APP_NAME');
            $ledger->amount = $payment->amount;
            $ledger->debit = $payment->final_amount;
            $ledger->status = 'approved';
            $ledger->date = date('d-m-Y H:i');
            $ledger->save();


            /**** Start recharge Refer commission ****/
            $authUser = User::where('id', $payment->user_id)->first();
            $f_user = User::where('ref_id', $authUser->ref_by)->first();
            if ($f_user)
            {
                //Get first refer user and give commission after 24 hour
                $total_amount = $payment->final_amount;
                $amount = ($total_amount * setting('recharge_1_commission')) / 100;
                User::where('id', $f_user->id)
                    ->update([
                        'recharge_1_com'=> $f_user->recharge_1_com + $amount
                    ]);

                $commission = new Commission();
                $commission->user_id = $f_user->id;
                $commission->amount = $amount;
                $commission->reason = 'first_refer_recharge_commission';
                $commission->level = 'first';
                $commission->date = Carbon::now();
                $commission->save();

                //Get Second refer user and give commission after 24 hour
                $s_user = User::where('ref_id', $f_user->ref_by)->first();
                if ($s_user){
                    $total_amount = $payment->final_amount;
                    $amount = ($total_amount * setting('recharge_2_commission')) / 100;
                    User::where('id', $s_user->id)
                        ->update([
                            'recharge_2_com'=> $s_user->recharge_2_com + $amount
                        ]);

                    $commission = new Commission();
                    $commission->user_id = $s_user->id;
                    $commission->amount = $amount;
                    $commission->reason = 'second_refer_recharge_commission';
                    $commission->level = 'second';
                    $commission->date = Carbon::now();
                    $commission->save();

                    //Get Third refer user and give commission after 24 hour
                    $t_user = User::where('ref_id', $s_user->ref_by)->first();
                    if ($t_user){
                        $total_amount = $payment->final_amount;
                        $amount = ($total_amount * setting('recharge_3_commission')) / 100;
                        User::where('id', $t_user->id)
                            ->update([
                                'recharge_3_com'=> $t_user->recharge_3_com + $amount
                            ]);

                        $commission = new Commission();
                        $commission->user_id = $t_user->id;
                        $commission->amount = $amount;
                        $commission->reason = 'third_refer_recharge_commission';
                        $commission->level = 'third';
                        $commission->date = Carbon::now();
                        $commission->save();
                    }
                }
            }
            /**** End recharge Refer commission ****/

            $payment->status = 'approved';
            $payment->feedback = 'approved by admin';
            $payment->update();
        }
        return redirect()->back()->with('success', 'Payment status change successfully.');
    }

    public function add_balance(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'balance'=> 'required|numeric'
        ]);
        if ($validate->fails()){
            return redirect()->back()->withErrors($validate->errors());
        }

        $user = User::find($request->user_id);
        $user->commission_balance = $user->commission_balance + $request->balance;
        $user->update();
        return redirect()->back()->with('success', 'User balance added successful.');
    }

   public function minus_balance(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'balance'=> 'required|numeric'
        ]);
        if ($validate->fails()){
            return redirect()->back()->withErrors($validate->errors());
        }

        $user = User::find($request->user_id);
        if ($request->balance <= $user->commission_balance){
            $user->commission_balance = $user->commission_balance - $request->balance;
            $user->update();
            return redirect()->back()->with('success', 'User balance minus successful.');
        }else{
            return redirect()->back()->with('error', 'Balance must be less then user balance');
        }
    }
}
