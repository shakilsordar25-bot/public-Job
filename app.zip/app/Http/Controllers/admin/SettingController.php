<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class SettingController extends Controller
{
    public $route = 'admin.setting';
    public function index()
    {
        $data = Setting::find(1);
        return view('admin.pages.setting.index', compact('data'));
    }

    public function insert_or_update(Request $request)
    {
        $this->validate($request,[
            'site_name'=> 'required',
            'site_title'=> 'required',
        ]);
        $model = Setting::findOrFail(1);

        $path = uploadImage(false ,$request, 'logo', 'upload/setting/', null, null ,$model->logo);
        $path1 = uploadImage(false ,$request, 'login_image', 'upload/setting/', null, null ,$model->login_image);
        $path2 = uploadImage(false ,$request, 'regi_image', 'upload/setting/', null, null ,$model->regi_image);
        $model->logo = $path ?? $model->logo;
        $model->login_image = $path1 ?? $model->login_image;
        $model->regi_image = $path2 ?? $model->regi_image;

        $model->site_name = $request->site_name;
        // $model->usdt = $request->rate;
        $model->site_title = $request->site_title;
        $model->checkin_bonus = $request->checkin_bonus;
        $model->withdraw_charge = $request->withdraw_charge;
        $model->minimum_withdraw = $request->minimum_withdraw;
        $model->maximum_withdraw = $request->maximum_withdraw;
        $model->telegram_channel = $request->telegram_channel;
        $model->telegram_group = $request->telegram_group;
        $model->telegram = $request->telegram;
        $model->withdraw_notes = $request->withdraw_notes;
        $model->marque = $request->marque;
        $model->home_slider = $request->home_slider;

        $model->recharge_1_commission = $request->recharge_1_commission;
        $model->recharge_2_commission = $request->recharge_2_commission;
        $model->recharge_3_commission = $request->recharge_3_commission;

        $model->first_refer_commission = $request->first_refer_commission;
        $model->second_refer_commission = $request->second_refer_commission;
        $model->third_refer_commission = $request->third_refer_commission;

        $model->update();
        return redirect()->route($this->route.'.index')->with('success', 'Settings Updated Successfully.');
    }
}
