<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Models\BonusLedger;
use App\Models\Checkin;
use App\Models\Commission;
use App\Models\Improvment;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AdminController extends Controller
{
    public function login()
    {
        if (Auth::guard('admin')->check()) {
            return redirect()->route('admin.dashboard');
        }
        return view('admin.auth.login');
    }

    public function login_submit(Request $request)
    {
        $credentials = $request->only('email', 'password');
        if (Auth::guard('admin')->attempt($credentials)) {
            $admin = Auth::guard('admin')->user();
            if ($admin->type == 'admin') {
                return redirect()->route('admin.dashboard')->with('success', 'Logged In Successful.');
            } else {
                return error_redirect('admin.login', 'error', 'Admin Credentials Very Secured Please Don"t try Again.');
            }
        } else {
            return error_redirect('admin.login', 'error', 'Admin Credentials Does Not Match.');
        }
    }

    public function logout()
    {
        if (Auth::guard('admin')->check()) {
            Auth::guard('admin')->logout();
            return redirect()->route('admin.login')->with('success', 'Logged out successful.');
        } else {
            return error_redirect('admin.login', 'error', 'You are already logged out.');
        }
    }

    public function dashboard()
    {
        return view('admin.dashboard');
    }

    public function profile()
    {
        return view('admin.profile.index');
    }

    public function profile_update()
    {
        $admin = Admin::first();
        return view('admin.profile.update-details', compact('admin'));
    }

    public function profile_update_submit(Request $request)
    {
        $admin = Admin::find(1);
        $path = uploadImage(false, $request, 'photo', 'admin/assets/images/profile/', $admin->photo);
        $admin->photo = $path ?? $admin->photo;
        $admin->name = $request->name;
        $admin->email = $request->email;
        $admin->phone = $request->phone;
        $admin->address = $request->address;
        $admin->update();
        return redirect()->route('admin.profile.update')->with('success', 'Admin profile updated.');
    }

    public function change_password()
    {
        $admin = admin()->user();
        return view('admin.profile.change-password', compact('admin'));
    }

    public function check_password(Request $request)
    {
        $admin = admin()->user();
        $password = $request->password;
        if (Hash::check($password, $admin->password)) {
            return response()->json(['message' => 'Password matched.', 'status' => true]);
        } else {
            return response()->json(['message' => 'Password dose not match.', 'status' => false]);
        }
    }

    public function change_password_submit(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'old_password' => 'required',
            'new_password' => 'required',
            'confirm_password' => 'required'
        ]);
        if ($validate->fails()) {
            session()->put('errors', true);
            return redirect()->route('admin.changepassword')->withErrors($validate->errors());
        }

        $admin = admin()->user();
        $password = $request->old_password;
        if (Hash::check($password, $admin->password)) {
            if (strlen($request->new_password) > 5 && strlen($request->confirm_password) > 5){
                if ($request->new_password === $request->confirm_password) {
                    $admin->password = Hash::make($request->new_password);
                    $admin->update();
                    return redirect()->route('admin.changepassword')->with('success', 'Password changed successfully');
                } else {
                    return error_redirect('admin.changepassword', 'error', 'New password and confirm password dose not match');
                }
            }else{
                return error_redirect('admin.changepassword', 'error',  'Password must be greater then 6 or equal.');
            }
        } else {
            return error_redirect('admin.changepassword', 'error',  'Password dose not match');
        }
    }



    public function interest_commission(){

        $getInvesterAmount = Improvment::min('amount_limit');

        $searchUsersByMinimumInvest = User::where('invest_balance', '>=', $getInvesterAmount)->get();

        foreach ($searchUsersByMinimumInvest as $uuuu){
            /*** Start Investment Income ***/
            $improvements = Improvment::where('status', 'active')->orderBy('amount_limit')->get();
            //Get big row from improvements
            $largest_improvement_id = 0;
            foreach ($improvements as $element){ //Invest amount wise amount commission
                if ($uuuu->invest_balance >= $element->amount_limit && $uuuu->invest_balance <= $element->between_amount){
                    $largest_improvement_id = $element->id;
                }
            }

            //get higher amount
            $higher_improvements = Improvment::where('status', 'active')->max('between_amount');
            if ($uuuu->invest_balance > $higher_improvements){
                $higher_invest_id = Improvment::where('status', 'active')->where('between_amount', $higher_improvements)->first();
                $largest_improvement_id = $higher_invest_id->id;
            }

            $initial_improvement = Improvment::where('status', 'active')->where('id', $largest_improvement_id)->first();

            //Now finally commission start
            if ($initial_improvement)
            {
                $commission_balance = 0;
                //Generate commission //First time insert
                $my_commission = ($uuuu->invest_balance * $initial_improvement->commission) / 100;
                if ($my_commission > 0){
                    $commission_balance = $commission_balance + $my_commission;

                    $commission = new Commission();
                    $commission->user_id = $uuuu->id;
                    $commission->amount = $my_commission;
                    $commission->reason = 'amount_commission';
                    $commission->level = 'self';
                    $commission->is_receive = 'no';
                    $commission->date = Carbon::now()->subDays(1);
                    $commission->save();
                }

                $updateUserComBalance = User::where('id', $uuuu->id)->first();
                $updateUserComBalance->com_receible = $uuuu->com_receible + $commission_balance;
                $updateUserComBalance->save();
            }
        }
    }
}
