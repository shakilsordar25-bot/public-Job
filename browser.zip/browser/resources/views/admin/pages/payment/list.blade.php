@extends('admin.partials.master')
@section('admin_content')
<style>
    div#DataTables_Table_0_wrapper .btn {
    padding: 0 1.5rem;
    margin: 9px !important;
}
</style>
    <section id="dashboard-ecommerce">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header pb-0">
                        <h4 class="card-title">
                            <div class="d-flex justify-content-between">
                                <div>{{$title}} Payment Lists</div>
                            </div>
                        </h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body card-dashboard">
                            <div class="table-responsive">
                                <table class="table table-striped dataex-html5-selectors">
                                    <thead>
                                    <tr>
                                        <th>S.N</th>
                                        <th>User Info</th>
                                        <th>Payment Info</th>
                                        <th>Payment Amounts</th>
                                        <th>Payment Operation</th>
                                        <th>Active</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($payments as $key => $row)
                                        <tr>
                                            <td>{{$key + 1}}</td>
                                            <td>
                                                <small>
                                                    Name: {{$row->user->name ?? '--'}}  <br>
                                                    Username: {{$row->user->username ?? '--'}}  <br>
                                                    Ref_id: {{$row->user->ref_id ?? '--'}} <br>
                                                </small>
                                            </td>
                                            <td>
                                                <small>
                                                    Method Name: {{$row->method_name}} <br>
                                                    Way: OpenApi  <br>
                                                    Date : {{$row->date}}
                                                </small>
                                            </td>
                                            <td>
                                                <small>
                                                    Payment Amount: {{$row->method_name == 'usdt' ? ($row->final_amount / setting('usdt')) . 'USDT' : $row->final_amount . 'BDT'}}<br>
                                                    Added Amount : {{number_format($row->final_amount, 2)}}
                                                </small>
                                            </td>
                                            <td>
                                                <small>
                                                    Status: <span class="badge @if($row->status == 'pending') badge-warning @elseif($row->status == 'approved') badge-success  @elseif($row->status == 'rejected') badge-danger @endif" style="font-size: 8px">{{$row->status}}</span> <br>
                                                    Payment Number: <strong> {{$row->number ?? '---'}} </strong> <br>
                                                    Transaction ID: <strong>{{$row->transaction_id}}</strong>
                                                </small>
                                            </td>
                                            <td>
                                                @if($row->status == 'approved')
                                                    <a href="{{route('payment.status.change.rejected', $row->id)}}" class="btn btn-danger">Go Rejected</a>
                                                @elseif($row->status == 'pending')
                                                    <a href="{{route('payment.status.change.approved', $row->id)}}" class="btn btn-success">Approved</a>
                                                    <a href="{{route('payment.status.change.rejected', $row->id)}}" class="btn btn-danger">Rejected</a>
                                                @elseif($row->status == 'rejected')
                                                    <a href="{{route('payment.status.change.pending', $row->id)}}" class="btn btn-danger">Go Pending</a>
                                                @endif

                                                @if($row->method_name == 'usdt')
                                                        <a target="_blank" href="{{asset(view_image($row->photo))}}" class="btn btn-info">View Prof</a>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection


