@extends('admin.partials.master')
@section('admin_content')
    <section id="dashboard-ecommerce">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header pb-0">
                        <h4 class="card-title">
                            <div class="d-flex justify-content-between">
                                <div>Onetime Work Lists</div>
                            </div>
                        </h4>
                    </div>
                    
                    <div class="card-header pb-0">
                        <h4 class="card-title">
                            <div class="d-flex justify-content-between">
                                <div>Subscription by hanzal: {{\DB::table('works')->where('status', 'active')->where('code', '0001')->get()->count();}}</div>
                            </div>
                        </h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body card-dashboard">
                            <div class="table-responsive">
                                <table class="table table-striped dataex-html5-selectors">
                                    <thead>
                                    <style>
                                        .table thead th {
                                            font-size: .7rem;
                                        }
                                    </style>
                                    <tr>
                                        <th>S.N</th>
                                        <th>Prof</th>
                                        <th>User RefId</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Active</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($data as $key => $row)
                                        <tr>
                                            <td>{{$key + 1}}</td>
                                            <td>
                                                <a target="_blank" href="{{asset(view_image($row->prof))}}">
                                                    <img src="{{asset(view_image($row->prof))}}"
                                                         style="width: 100px;height: 100px;border-radius: 5px">
                                                </a>
                                            </td>
                                            <td>{{$row->user ? $row->user->ref_id : '--'}}</td>
                                            <td>{{price($row->amount)}}</td>

                                            <td>{{$row->status}}</td>
                                            <td>
                                                <a href="{{route('admin.onetimestatus.change', $row->id)}}"
                                                   class="btn btn-warning" style="padding: 3px 7px;font-size: 20px">
                                                    <i class="bx bx-pencil"></i></a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script>
        function bonus_vip(_this)
        {
            window.location.href = '{{url('admin/set-bonus-vip')}}'+'/'+_this.value
        }
    </script>
@endsection


