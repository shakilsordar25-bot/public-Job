@extends('admin.partials.master')
@section('admin_content')
    <section id="dashboard-ecommerce">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header pb-0">
                        <h4 class="card-title">
                            <div class="d-flex justify-content-between">
                                <div>{{$title}} Withdraw Lists</div>
                            </div>
                        </h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body card-dashboard">
                            <div class="table-responsive">
                                <table class="table table-striped dataex-html5-selectors">
                                    <thead>
                                    <tr>
                                        <th>S.N</th>
                                        <th>User Info</th>
                                        <th>Withdraw Info</th>
                                        <th>Amount Amounts</th>
                                        <th>Withdraw Operation</th>
                                        <th>Active</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($withdraws as $key => $row)
                                        <tr>
                                            <td>{{$key + 1}}</td>
                                            <td>
                                                <small>
                                                    Username: {{$row->user->username ?? '--'}}  <br>
                                                    Ref id: {{$row->user->ref_id ?? '--'}} <br>
                                                </small>
                                            </td>
                                            <td>
                                                @if($row->currency == 'USDT')
                                                    <small>
                                                        USDT Bank: {{$row->user ? $row->user->usdt_name : '---'}} <br>
                                                        USDT Address: {{$row->user ? $row->user->usdt : '---'}} <br>
                                                        Date : {{$row->created_at}}
                                                    </small>
                                                @else
                                                <small>
                                                    Withdraw Method: {{$row->method_name}} <br>
                                                    Withdraw Address: {{$row->number}} <br>
                                                    Date : {{$row->created_at}}
                                                </small>
                                                    @endif
                                            </td>
                                            <td>
                                                @if($row->currency == 'USDT')
                                                    <small>
                                                        Withdraw Amount: {{$row->amount / setting('usdt')}} USDT <br>
                                                        Withdraw Charge: {{setting('usdt_withdraw_charge')}} USDT<br>
                                                        Return Amount : {{$row->final_amount / setting('usdt')}} USDT<br>
                                                        BDT Amount : {{$row->final_amount}}
                                                    </small>
                                                @else
                                                <small>
                                                    Withdraw Amount: {{price($row->amount)}} <br>
                                                    Withdraw Charge: {{price($row->charge)}} <br>
                                                    Return Amount : {{price($row->final_amount)}}
                                                </small>
                                                @endif
                                            </td>
                                            <td>
                                                <small>
                                                    Status: <span class="badge @if($row->status == 'pending') badge-warning @elseif($row->status == 'approved') badge-success  @elseif($row->status == 'rejected') badge-danger @endif" style="font-size: 8px">{{$row->status}}</span> <br>

                                                    @if($row->currency == 'USDT')
                                                        Amount Rate: <strong> {{setting('usdt_withdraw_charge')}}USDT </strong> <br>
                                                    @else
                                                        Amount Rate: <strong> {{price(setting('rate'))}} </strong> <br>
                                                    @endif
                                                </small>
                                            </td>
                                            <td>
                                                @if($row->status == 'pending')
                                                    <a href="javascript:void(0)" data-toggle="modal" data-target="#myModal{{$row->id}}" class="btn btn-success">Action</a>
                                                    <form action="{{route('withdraw.status.change', $row->id)}}" method="POST">@csrf
                                                        <div class="modal fade" id="myModal{{$row->id}}">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">

                                                                    <!-- Modal Header -->
                                                                    <div class="modal-header">
                                                                        <h4 class="modal-title">Action for withdraw</h4>
                                                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                    </div>

                                                                    <!-- Modal body -->
                                                                    <div class="modal-body">
                                                                        <div class="form-group">
                                                                            <label for="status">Status <small class="text-info"> You can change withdraw status link approved, rejected, pending is default </small> </label>
                                                                            <select name="status" required id="status" class="form-control">
                                                                                <option value="approved" @if($row->status == 'approved') selected @endif>Approved</option>
                                                                                <option value="rejected" @if($row->status == 'rejected') selected @endif>Rejected</option>
                                                                                <option value="pending" @if($row->status == 'pending') selected @endif>Pending</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <input name="trx" id="trx" type="hidden" value="--" class="form-control is-valid" placeholder="Enter send money trx id">
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="note">Feedback Note <small class="text-success">(Optional)</small> </label>
                                                                            <textarea name="note" id="note" cols="30"
                                                                                      rows="4" class="form-control is-valid"></textarea>
                                                                        </div>
                                                                    </div>

                                                                    <!-- Modal footer -->
                                                                    <div class="modal-footer">
                                                                        <input type="submit" value="Submit" class="btn btn-primary">
                                                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                @else
                                                    <div class="text-info">Already push a action</div>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection


