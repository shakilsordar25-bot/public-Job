@extends('admin.partials.master')
@section('admin_content')
    <style>
        label {
            text-transform: unset;
        }
    </style>
    <section id="dashboard-ecommerce">
        <div class="row">
            <div class="col-12">
                <form action="{{route('admin.setting.insert')}}" method="POST" enctype="multipart/form-data">@csrf
                    <input type="hidden" name="id" value="{{$data ? $data->id : ''}}">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">
                                <div class="d-flex justify-content-between">
                                    <div>{{$data ? 'Update' : 'Create New'}} Settings</div>
                                </div>
                            </h4>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-12 mt-2">
                                        <div class="row">
                                            <div class="col-sm-12 mt-2">
                                                <div class="row">
                                                    <div class="col-12 col-sm-6">
                                                        <fieldset class="form-group">
                                                            <label for="basicInputFile">Upload Logo <small>{Suggestion:
                                                                    size 80X80(px)}</small> </label>
                                                            <div class="custom-file">
                                                                <input type="file" name="logo"
                                                                       class="custom-file-input is-valid"
                                                                       id="inputGroupFile01"
                                                                       @if(!$data) required
                                                                       @else @endif onchange="showPreview(event)">
                                                                <label class="custom-file-label" for="inputGroupFile01">Choose
                                                                    file</label>
                                                                <div class="valid-feedback">
                                                                    <i class="bx bx-radio-circle"></i>
                                                                    Note: Logo image mandatory
                                                                </div>
                                                            </div>
                                                        </fieldset>
                                                    </div>
                                                    <div class="col-12 col-sm-6">
                                                        <div class="image_preview">
                                                            <img
                                                                src="{{$data ? asset(view_image($data->logo)) :  asset(not_found_img())}}"
                                                                id="file-ip-1-preview" class="rounded"
                                                                alt="Preview Image"
                                                                style="width: 100px;height: 100px">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 mt-2">
                                        <div class="row">
                                            <div class="col-sm-12 mt-2">
                                                <div class="row">
                                                    <div class="col-12 col-sm-6">
                                                        <fieldset class="form-group">
                                                            <label for="basicInputFile">Upload Login Image</label>
                                                            <div class="custom-file">
                                                                <input type="file" name="login_image"
                                                                       class="custom-file-input is-valid"
                                                                       id="inputGroupFile01"
                                                                       @if(!$data) required
                                                                       @else @endif onchange="showPreviewFavicon(event)">
                                                                <label class="custom-file-label" for="inputGroupFile01">Choose
                                                                    file</label>
                                                                <div class="valid-feedback">
                                                                    <i class="bx bx-radio-circle"></i>
                                                                    Note: login image mandatory
                                                                </div>
                                                            </div>
                                                        </fieldset>
                                                    </div>
                                                    <div class="col-12 col-sm-6">
                                                        <div class="image_preview">
                                                            <img
                                                                src="{{$data ? asset(view_image($data->login_image)) :  asset(not_found_img())}}"
                                                                id="login_image" class="rounded" alt="Preview Image"
                                                                style="width: 100px;height: 100px">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-sm-12 mt-2">
                                                <div class="row">
                                                    <div class="col-12 col-sm-6">
                                                        <fieldset class="form-group">
                                                            <label for="basicInputFile">Upload Registration
                                                                Image</label>
                                                            <div class="custom-file">
                                                                <input type="file" name="regi_image"
                                                                       class="custom-file-input is-valid"
                                                                       id="inputGroupFile01"
                                                                       @if(!$data) required
                                                                       @else @endif onchange="showPreviewregi_image(event)">
                                                                <label class="custom-file-label" for="inputGroupFile01">Choose
                                                                    file</label>
                                                                <div class="valid-feedback">
                                                                    <i class="bx bx-radio-circle"></i>
                                                                    Note: Registration image mandatory
                                                                </div>
                                                            </div>
                                                        </fieldset>
                                                    </div>
                                                    <div class="col-12 col-sm-6">
                                                        <div class="image_preview">
                                                            <img
                                                                src="{{$data ? asset(view_image($data->regi_image)) :  asset(not_found_img())}}"
                                                                id="regi_image" class="rounded" alt="Preview Image"
                                                                style="width: 100px;height: 100px">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-sm-6">
                                                <label for="checkin_bonus">Check in bonus for every day(Amount)</label>
                                                <input type="text" class="form-control is-valid"
                                                       name="checkin_bonus" id="checkin_bonus"
                                                       placeholder="Checkin bonus"
                                                       value="{{$data ? $data->checkin_bonus : old('checkin_bonus')}}">
                                                <div class="valid-feedback">
                                                    <i class="bx bx-radio-circle"></i>
                                                    Note: This is filed is optional
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <label for="withdraw_notes">Withdraw charge%</label>
                                                <input type="number" class="form-control is-valid"
                                                       name="withdraw_charge" id="withdraw_charge"
                                                       placeholder="Withdraw charge"
                                                       value="{{$data ? $data->withdraw_charge : old('withdraw_charge')}}">
                                                <div class="valid-feedback">
                                                    <i class="bx bx-radio-circle"></i>
                                                    Note: This is filed is optional
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <label for="minimum_withdraw">Minimum Withdraw</label>
                                                <input type="number" class="form-control is-valid"
                                                       name="minimum_withdraw" id="minimum_withdraw"
                                                       placeholder="Minimum Withdraw"
                                                       value="{{$data ? $data->minimum_withdraw : old('minimum_withdraw')}}">
                                                <div class="valid-feedback">
                                                    <i class="bx bx-radio-circle"></i>
                                                    Note: This is filed is optional
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <label for="maximum_withdraw">Maximum Withdraw</label>
                                                <input type="number" class="form-control is-valid"
                                                       name="maximum_withdraw" id="maximum_withdraw"
                                                       placeholder="Maximum Withdraw"
                                                       value="{{$data ? $data->maximum_withdraw : old('maximum_withdraw')}}">
                                                <div class="valid-feedback">
                                                    <i class="bx bx-radio-circle"></i>
                                                    Note: This is filed is optional
                                                </div>
                                            </div>

                                            <div class="col-sm-12">
                                                <label for="withdraw_notes">Withdraw Notice</label>
                                                <input type="text" class="form-control is-valid"
                                                       name="withdraw_notes" id="withdraw_notes"
                                                       placeholder="Withdraw Notice"
                                                       value="{{$data ? $data->withdraw_notes : old('withdraw_notes')}}">
                                                <div class="valid-feedback">
                                                    <i class="bx bx-radio-circle"></i>
                                                    Note: This is filed is optional
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <label for="marque">Home page marque</label>
                                                <input type="text" class="form-control is-valid"
                                                       name="marque" id="marque"
                                                       placeholder="marque"
                                                       value="{{$data ? $data->marque : old('marque')}}">
                                                <div class="valid-feedback">
                                                    <i class="bx bx-radio-circle"></i>
                                                    Note: This is filed is optional
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <label for="site_name">Site Name</label>
                                        <input type="text" class="form-control is-valid"
                                               name="site_name" id="site_name"
                                               placeholder="Site name" value="{{$data ? $data->site_name : ''}}"
                                               required>
                                        <div class="valid-feedback">
                                            <i class="bx bx-radio-circle"></i>
                                            Note: This is filed is required
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <label for="site_title">Site Title</label>
                                        <input type="text" class="form-control is-valid"
                                               name="site_title" id="site_title"
                                               placeholder="Site title" value="{{$data ? $data->site_title : ''}}"
                                               required>
                                        <div class="valid-feedback">
                                            <i class="bx bx-radio-circle"></i>
                                            Note: This is filed is required
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <label for="telegram">Telegram Link</label>
                                        <input type="text" class="form-control is-valid"
                                               name="telegram" id="telegram"
                                               placeholder="Telegram Link"
                                               value="{{$data ? $data->telegram : old('telegram')}}">
                                        <div class="valid-feedback">
                                            <i class="bx bx-radio-circle"></i>
                                            Note: This is filed is optional
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <label for="telegram_channel">Telegram Channel</label>
                                        <input type="text" class="form-control is-valid"
                                               name="telegram_channel" id="telegram_channel"
                                               placeholder="Telegram Channel"
                                               value="{{$data ? $data->telegram_channel : old('telegram_channel')}}">
                                        <div class="valid-feedback">
                                            <i class="bx bx-radio-circle"></i>
                                            Note: This is filed is optional
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <label for="telegram_group">Telegram Group</label>
                                        <input type="text" class="form-control is-valid"
                                               name="telegram_group" id="telegram_group"
                                               placeholder="Telegram Group"
                                               value="{{$data ? $data->telegram_group : old('telegram_group')}}">
                                        <div class="valid-feedback">
                                            <i class="bx bx-radio-circle"></i>
                                            Note: This is filed is optional
                                        </div>
                                    </div>


                                    <div class="col-sm-12">
                                        <label for="home_slider">Home POP Slider</label>
                                        <textarea name="home_slider" class="form-control is-valid" id="home_slider"
                                                  cols="30" rows="4"
                                                  placeholder="Home slider">{{$data ? $data->home_slider : old('home_slider')}}</textarea>
                                        <div class="valid-feedback">
                                            <i class="bx bx-radio-circle"></i>
                                            Note: This is filed is optional
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h6 class="card-title">
                                <h5>Received Amount Refer commission</h5>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label for="first_refer_commission">First refer commission(%)</label>
                                        <input type="text" class="form-control is-valid"
                                               name="first_refer_commission" id="first_refer_commission"
                                               placeholder="Ex: 10"
                                               value="{{$data ? $data->first_refer_commission : old('first_refer_commission')}}">
                                        <div class="valid-feedback">
                                            <i class="bx bx-radio-circle"></i>
                                            Note: This is filed is required
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <label for="second_refer_commission">Second refer commission(%)</label>
                                        <input type="text" class="form-control is-valid"
                                               name="second_refer_commission" id="second_refer_commission"
                                               placeholder="Ex: 5"
                                               value="{{$data ? $data->second_refer_commission : old('second_refer_commission')}}">
                                        <div class="valid-feedback">
                                            <i class="bx bx-radio-circle"></i>
                                            Note: This is filed is required
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <label for="third_refer_commission">Third Refer Commission(%)</label>
                                        <input type="text" class="form-control is-valid"
                                               name="third_refer_commission" id="third_refer_commission"
                                               placeholder="Ex: 3"
                                               value="{{$data ? $data->third_refer_commission : old('third_refer_commission')}}">
                                        <div class="valid-feedback">
                                            <i class="bx bx-radio-circle"></i>
                                            Note: This is filed is required
                                        </div>
                                    </div>
                                </div>
                            </h6>
                        </div>
                    </div>


                    <div class="card">
                        <div class="card-header">
                            <h6 class="card-title">
                                <h5>Recharge to refer commission</h5>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label for="recharge_1_commission">First Refer Recharge Commission(%)</label>
                                        <input type="text" class="form-control is-valid"
                                               name="recharge_1_commission" id="recharge_1_commission"
                                               placeholder="Ex: 10"
                                               value="{{$data ? $data->recharge_1_commission : old('recharge_1_commission')}}">
                                        <div class="valid-feedback">
                                            <i class="bx bx-radio-circle"></i>
                                            Note: This is filed is required
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <label for="recharge_2_commission">Second Refer Recharge Commission(%)</label>
                                        <input type="text" class="form-control is-valid"
                                               name="recharge_2_commission" id="recharge_1_commission"
                                               placeholder="Ex: 5"
                                               value="{{$data ? $data->recharge_2_commission : old('recharge_2_commission')}}">
                                        <div class="valid-feedback">
                                            <i class="bx bx-radio-circle"></i>
                                            Note: This is filed is required
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <label for="recharge_3_commission">Third Refer Recharge Commission(%)</label>
                                        <input type="text" class="form-control is-valid"
                                               name="recharge_3_commission" id="recharge_3_commission"
                                               placeholder="Ex: 3"
                                               value="{{$data ? $data->recharge_3_commission : old('recharge_3_commission')}}">
                                        <div class="valid-feedback">
                                            <i class="bx bx-radio-circle"></i>
                                            Note: This is filed is required
                                        </div>
                                    </div>
                                </div>
                            </h6>
                        </div>
                    </div>

                    <!-- Form Submit Button -->
                    <div class="card">
                        <div class="card-header">
                            <h6 class="card-title">
                                <div class="d-flex justify-content-between">
                                    <div style="margin-top: .7rem !important">
                                        Submit Your Setting Information
                                    </div>
                                    <div>
                                        <div class="form-group mb-0">
                                            <button type="submit" class="btn btn-success"><i
                                                    class="bx bx-plus"></i>{{$data ? 'Update' : 'Submit'}} </button>
                                        </div>
                                    </div>
                                </div>
                            </h6>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <script>
        function showPreview(event) {
            if (event.target.files.length > 0) {
                var src = URL.createObjectURL(event.target.files[0]);
                var preview = document.getElementById("file-ip-1-preview");
                preview.src = src;
                preview.style.display = "block";
            }
        }

        function showPreviewFavicon(event) {
            if (event.target.files.length > 0) {
                var src = URL.createObjectURL(event.target.files[0]);
                var preview = document.getElementById("login_image");
                preview.src = src;
                preview.style.display = "block";
            }
        }

        function showPreviewregi_image(event) {
            if (event.target.files.length > 0) {
                var src = URL.createObjectURL(event.target.files[0]);
                var preview = document.getElementById("regi_image");
                preview.src = src;
                preview.style.display = "block";
            }
        }
    </script>
@endsection
