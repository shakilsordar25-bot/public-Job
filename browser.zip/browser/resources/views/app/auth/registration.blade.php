<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
    <!-- === Google Fonts === -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('public/update')}}/assets/css/creadential.css">
    <title>{{env('APP_NAME')}}-Registration</title>
    <link rel="stylesheet" href="{{asset('public/bg.css')}}">

</head>
<body class="bg1">
<style>
    span.l_text {
        position: absolute;
        left: 21px;
        top: 81px;
    }
    .auth_title p::after {
        background: transparent;
    }
    form {
        margin-top: 0;
    }
    input.custom_input {
        padding-left: 64px;
    }
</style>
<style>
    span {
        color: #000;
    }
    .licon {
        color: #000;
    }
    .custom_form_box button {
        color: #000;
    }
    input.custom_input {
        border: none;
    }
    input.custom_input:focus-visible {
        outline: none;
    }
    .custom_form_box button {
        color: #000;
        border: none;
    }
</style>
<link rel="stylesheet" href="{{asset('public/app/css/loading.css')}}">
<div class="loader_boss" style="display: none">
    <svg class="spinner">
        <img style="width: 100%;
    position: absolute;
    top: -50px;
    left: 0px;" src="{{asset('public/l1.gif')}}">
    </svg>

    <div>
        <span class="l_text">Loading...</span>
    </div>
</div>
<div class="auth_title">
    <div>
        <img style="width: 100%;height:180px;" src="{{view_image(setting('regi_image'))}}">
    </div>
    <p>Registration</p>
</div>

<form action="" method="">
    <div class="custom_form_box">
        <input type="text" class="custom_input" name="phone" placeholder="Enter your phone number">
        <span style="left: 15px !important;width: 30px">+880</span>
    </div>

    <div class="custom_form_box">
        <i class="licon fa fa-users"></i>
        <input type="text" class="custom_input" name="ref_by" placeholder="Enter your invitation code" value="{{isset($ref_by) && !empty($ref_by) && $ref_by != null ? $ref_by : rand(0,99999)}}">
    </div>

    <div class="custom_form_box">
        <i class="licon fa fa-key"></i>
        <input type="password" class="custom_input" name="password" placeholder="Create your password">
        <span onclick="showPassword()"><i class="fa fa-eye"></i></span>
    </div>

    <div class="custom_form_box">
        <i class="licon fa fa-key"></i>
        <input type="password" class="custom_input" name="c_password" placeholder="Confirm your password">
        <span onclick="showPasswordConfirm()"><i class="fa fa-eye"></i></span>
    </div>

    <div class="custom_form_box">
        <button type="button" onclick="submitForRegistration()">Continue</button>
    </div>

    <div class="custom_form_box">
        <p>Have an account ? <a href="{{route('login')}}"> Login now</a></p>
    </div>
</form>
@include('alert-message')
<meta name="csrf-token" content="{{ csrf_token() }}" />
<script>
    function showPassword(){
        let element = document.querySelector('input[name="password"]');
        if (element.type==='password'){
            element.type = 'text';
        }else {
            element.type = 'password';
        }
    }

    function showPasswordConfirm()
    {
        let element = document.querySelector('input[name="c_password"]');
        if (element.type==='password'){
            element.type = 'text';
        }else {
            element.type = 'password';
        }
    }

    function submitForRegistration()
    {
        var phone = document.querySelector('input[name="phone"]').value;
        var password = document.querySelector('input[name="password"]').value;
        var c_password = document.querySelector('input[name="c_password"]').value;
        var ref_by = document.querySelector('input[name="ref_by"]').value;

        document.querySelector('.loader_boss').style.display='block';

        if (ref_by != ''){
            if (phone != ''){
                if (password != ''){
                    if (c_password != ''){
                        if (password == c_password){
                            var data = {
                                phone: phone,
                                password: password,
                                c_password: c_password,
                                ref_by: ref_by,
                            }
                            fetch('{{url('register')}}',
                                {
                                    method:"POST",
                                    body:JSON.stringify(data),
                                    headers: {'Content-type': 'application/json; charset=UTF-8', 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')}})
                                .then(response => response.json())
                                .then(data => {
                                    if (data.status == true){
                                        message(data.message)
                                        window.location.href = data.url
                                    }
                                    if (data.status == false){
                                        message(data.message)
                                        document.querySelector('.loader_boss').style.display='none';
                                    }
                                }).catch();
                        }else {
                            document.querySelector('.loader_boss').style.display='none';
                            message('password not match')
                        }
                    }else{
                        document.querySelector('.loader_boss').style.display='none';
                        message('Enter confirm password');
                    }
                }else {
                    document.querySelector('.loader_boss').style.display='none';
                    message('Enter password');
                }
            }else{
                document.querySelector('.loader_boss').style.display='none';
                message('Enter phone number');
            }
        }else {
            document.querySelector('.loader_boss').style.display='none';
            message('Enter refer id');
        }
    }
</script>
</body>
</html>





