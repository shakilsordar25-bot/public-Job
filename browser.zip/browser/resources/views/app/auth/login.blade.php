<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport"/>
    <style> body{touch-action: manipulation;}</style>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <!-- === Google Fonts === -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <title>{{env('APP_NAME')}}-Login</title>
    <link rel="stylesheet" href="{{asset('public/update')}}/assets/css/creadential.css">
    <link rel="stylesheet" href="{{asset('public/bg.css')}}">
</head>
<body class="bg1">
<style>
    span {
        color: #000;
    }
    .licon {
        color: #000;
    }
    .custom_form_box button {
        color: #000;
    }
    .auth_title p::after {
        background: transparent;
    }
    input.custom_input {
        padding-left: 64px;
    }
    a.apk {
    text-align: center;
    display: block;
    background: #f2f2f2;
    color: #000;
    text-decoration: none;
    padding: 13px 0;
    border-radius: 50px;
}
.custom_form_box button {
    padding: 12px 0;
    border: none;
}
    input.custom_input {
        border: none;
    }
    input.custom_input:focus-visible {
        outline: none;
    }
</style>

<div class="auth_title">
    <div>
        <img style="width: 100%;height:170px;" src="{{view_image(setting('login_image'))}}">
    </div>
    <p>Login</p>
</div>

<form action="javascript:void(0)" method="post" style="margin-top:10px;">
    @csrf
    <div class="custom_form_box">
        <input type="text" class="custom_input" name="phone" placeholder="Enter your phone number">
        <span style="left: 15px !important;width: 30px">+880</span>
    </div>

    <div class="custom_form_box">
        <i class="licon fa fa-key"></i>
        <input type="password" class="custom_input" name="password" placeholder="Enter your password">
        <span onclick="showPassword()"><i class="fa fa-eye"></i></span>
    </div>

    <div class="custom_form_box">
        <button  type="button" onclick="submitForLogin()">Continue</button>
    </div>

    <div class="custom_form_box">
        <p style="margin-top:10px;">
            <a class="apk" href="{{route('user.download.apk')}}"> App Install</a>
        </p>

        <p>No Account ? <a href="{{route('register')}}"> Register now</a></p>

    </div>
</form>
@include('alert-message')
<meta name="csrf-token" content="{{ csrf_token() }}" />
<script>
    function showPassword(){
        let element = document.querySelector('input[name="password"]');
        if (element.type==='password'){
            element.type = 'text';
        }else {
            element.type = 'password';
        }
    }
    function submitForLogin()
    {
        var phone = document.querySelector('input[name="phone"]').value;
        var password = document.querySelector('input[name="password"]').value;

        if (phone != ''){
            if (password != ''){
                var data = {
                    phone: phone,
                    password: password
                }
                fetch('{{route('login.submit')}}',
                    {
                        method:"POST",
                        body:JSON.stringify(data),
                        headers: {'Content-type': 'application/json; charset=UTF-8', 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')}})
                    .then(response => response.json())
                    .then(data => {
                        message(data.message)
                        if (data.status == true){
                            window.location.href = data.url
                        }
                    }).catch();
            }else {
                message('Enter password');
            }
        }else{
            message('Enter phone number');
        }
    }
</script>
</body>
</html>





