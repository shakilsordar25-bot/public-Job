<style>
    .menu-name{
        color: #000000;
    }
    .menu-area {
        background: #F0F0F0  !important;
    }
</style>
<div class="menu-area">
    <ul class="menu">
        <li class="menu-item ">
            <a href="{{route('dashboard')}}">
                    <span class="menu-content">
                        <span class="menu-icon">
                            <img src="{{asset('public')}}/home.png" alt="">
                            <img src="{{asset('public')}}/home.png" alt="" class="image-active">
                        </span>
                        <span class="menu-name">Home</span>
                    </span>
            </a>
        </li>
        <li class="menu-item">
            <a href="{{route('income')}}">
                    <span class="menu-content">
                        <span class="menu-icon">
                            <img src="{{asset('public')}}/income.png" alt="">
                            <img src="{{asset('public')}}/income.png" alt="" class="image-active">
                        </span>
                        <span class="menu-name">income</span>
                    </span>
            </a>
        </li>
        <li class="menu-item">
            <a href="{{route('invest')}}">
                    <span class="menu-content">
                        <span class="menu-icon">
                            <img src="{{asset('public')}}/investment2.png" alt="">
                            <img src="{{asset('public')}}/investment2.png" alt="" class="image-active">
                        </span>
                        <span class="menu-name">Invest</span>
                    </span>
            </a>
        </li>
        <li class="menu-item">
            <a href="{{url('team')}}">
                    <span class="menu-content">
                        <span class="menu-icon">
                            <img src="{{asset('public')}}/link.png" alt="">
                            <img src="{{asset('public')}}/link.png" alt="" class="image-active">
                        </span>
                        <span class="menu-name">team</span>
                    </span>
            </a>
        </li>
        <li class="menu-item">
            <a href="{{route('mine')}}">
                    <span class="menu-content">
                        <span class="menu-icon">
                            <img src="{{asset('public')}}/user.png" alt="">
                            <img src="{{asset('public')}}/user.png" alt="" class="image-active">
                        </span>
                        <span class="menu-name">profile</span>
                    </span>
            </a>
        </li>
    </ul>
</div>
