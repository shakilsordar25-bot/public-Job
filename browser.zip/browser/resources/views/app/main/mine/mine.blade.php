<!DOCTYPE html>
<html lang="en">
<head>
    @include('app.layout.css')
    <link rel="stylesheet" href="{{asset('public/update')}}/assets/css/style.css">
</head>
<body>
@include('app.layout.loading')
<style>
    body{
        background: #fff;
    }
    .profile-page .cont-list .list {
        padding: 3vw 0 3vw 0;
    }
    .wrapper.team-page, .wrapper.profile-page {
        background: url("{{asset('public/bg.jpg')}}");
    }
    .profile-page .cont-list {
        background: #ffffffd4;
    }
    .a_card {
        background: #fff;
        margin: 17px;
        margin-top: 25px;
    }
    .profile-page .cont-list .list {
        padding: 5vw 0 3vw 0;
    }
</style>

<div class="wrapper profile-page" style="padding: 10px 0">
    <!-- nav -->
    <div class="nav-top container" style="display: flex;justify-content: space-between">
        <div style="display: flex;justify-content: space-between">
            <div>
                <img class="avtar" style="border-radius:50%;width:50px;height:50px" src="{{asset(view_image(setting('logo')))}}">
            </div>
            <div>
                <?php
                    $stars = \App\Models\Spin::where('user_id', auth()->user()->id)->where('result', 'star user')->get();
                ?>
                <h3 class="avtar_text">
                    <span style="font-weight: 600;font-size: 19px;color: #fff !important;">UID:</span>
                    <span style="font-weight: 300;font-size: 15px;color: #fff !important;display: inline-block;margin-right: 10px;">{{auth()->user()->ref_id}}</span>
                    <span>
                        @if($stars->count() > 0)
                            <img style="width: 25px;" src="{{asset('public')}}/star.png">
                        @endif
                        </span>
                </h3>
                <p style="color: #fff;">{{substr(auth()->user()->phone, 0, 3)}}******{{substr(strrev(auth()->user()->phone), 0, 2)}}</p>
            </div>
        </div>
        <div>
            <img style="display: block;width: 20px;margin: auto" src="{{asset('public/update')}}/assets/image/serve.png">
            <span style="font-size: 18px">Group</span>
        </div>
    </div>


    <div class="">
        <div class="a_card" style="padding: 13px 6px">
            <div style="display: flex;justify-content: space-between">
                <div>
                    <p style="font-size: 13px">Commission Balance</p>
                    <h4 style="font-size: 15px;margin-top:10px;font-weight: normal">{{price(auth()->user()->commission_balance)}}</h4>
                </div>
                <div>
                    <p style="font-size: 13px">Invest Balance</p>
                    <h4 style="font-size: 15px;margin-top:10px;font-weight: normal">{{price(auth()->user()->invest_balance)}}</h4>
                </div>
                <div>
                    <p style="font-size: 13px">Total Balance</p>
                    <h4 style="font-size: 15px;margin-top:10px;font-weight: normal">{{price(auth()->user()->commission_balance + auth()->user()->invest_balance)}}</h4>
                </div>
            </div>
            <div style="display: flex;justify-content: space-between;margin-top: 15px">
                <button class="a_btn"
                        style="background-color: #060606;color: #fff;"
                        onclick="window.location.href='{{route('recharge.way')}}'"
                >Recharge</button>
                <button class="a_btn"
                        onclick="window.location.href='{{route('user.withdraw')}}'">Withdraw</button>
                <button class="a_btn" onclick="window.location.href='{{route('span')}}'">Lucky Drow</button>
            </div>
        </div>
    </div>

    <!-- cont list -->
    <div class="cont-list">
        <div class="list" onclick="window.location.href='{{route('transfer')}}'">
            <div class="list-ti">
                <img src="{{asset('public/icon')}}/icons8-transfer-50.png">
                <p>Balance Transfer</p>
            </div>
            <img src="{{asset('public/update')}}/assets/image/me/next.png" class="next">
        </div>
        <div class="list" onclick="window.location.href='{{route('user.bank')}}'">
            <div class="list-ti">
                <img src="{{asset('public/icon')}}/icons8-bank-30.png">
                <p>Bank Setup</p>
            </div>
            <img src="{{asset('public/update')}}/assets/image/me/next.png" class="next">
        </div>

{{--        <div class="list" onclick="window.location.href='{{route('user.usdt')}}'">--}}
{{--            <div class="list-ti">--}}
{{--                <img src="{{asset('public/icon')}}/icons8-bank-30.png">--}}
{{--                <p>USDT Bank</p>--}}
{{--            </div>--}}
{{--            <img src="{{asset('public/update')}}/assets/image/me/next.png" class="next">--}}
{{--        </div>--}}

{{--        <div class="list" onclick="window.location.href='{{route('user.download.apk')}}'">--}}
        <div class="list" onclick="window.location.href=''">
            <div class="list-ti">
                <img src="{{asset('public/icon')}}/icons8-playstore-24.png">
                <p>App Download</p>
            </div>
            <img src="{{asset('public/update')}}/assets/image/me/next.png" alt="" class="next">
        </div>

        <div class="list" onclick="window.location.href='{{route('user.invite')}}'">
            <div class="list-ti">
                <img src="{{asset('public/icon')}}/icons8-share-50.png" alt="">
                <p>Share</p>
            </div>
            <img src="{{asset('public/update')}}/assets/image/me/next.png" alt="" class="next">
        </div>
        <div class="list last" onclick="window.location.href='{{route('change_user_pass')}}'">
            <div class="list-ti">
                <img src="{{asset('public/icon')}}/icons8-password-30.png" alt="">
                <p>Change password</p>
            </div>
            <img src="{{asset('public/update')}}/assets/image/me/next.png" alt="" class="next">
        </div>
        <div class="list last" onclick="window.location.href='{{route('logout')}}'">
            <div class="list-ti">
                <img src="{{asset('public/icon')}}/icons8-logout-30.png" alt="">
                <p>Logout</p>
            </div>
            <img src="{{asset('public/update')}}/assets/image/me/next.png" alt="" class="next">
        </div>
    </div>
</div>


@include('app.layout.manu')
@include('app.layout.js')
</body>
</html>
