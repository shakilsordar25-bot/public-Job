<!DOCTYPE html>
<html lang="en">

<head>
    @include('app.layout.css')
    <link rel="stylesheet" href="{{asset('public/update')}}/assets/css/style.css">
</head>
<script src="{{asset('public/team')}}/assets/js/toast.js"></script>
<body>
@include('app.layout.loading')
@include('alert-message')
<style>
    body {
        background-color: #fff;
    }
</style>

<section class="team_banner" style="height: 45px;">
    <div class="team_header container" style="padding: 12px 0;">
        <div><i class="fa fa-chevron-left"></i></div>
        <div style="font-weight: bold">Team member</div>
        <div style="font-size: 14px"></div>
    </div>
</section>

<section class="team_banner" style="height: 250px;">
    <div class="rebate">
        <img style="width: 100%" src="{{asset('public/update')}}/assets/image/bg.e862c997.png">

        <div class="rebate_text" style="height: 50px">
            <h3 style="font-style: italic">High rebate: 1.8%</h3>
        </div>

        <div
            class="rebate_box"
            style="height: 320px;
                background-image: url('{{asset('public/update')}}/assets/image/horse.6d4ccf46.png'), linear-gradient(rgba(22, 203, 133, .8), rgba(22, 203, 133, .8))"
        >
            <div class="mar" style="position: relative;">
                <marquee>
                    Welcome to {{env('APP_NAME')}}. You can unlimited earn money using this platform. just you can invest minmum balance.
                </marquee>
                <img class="notices" src="{{asset('public/update')}}/assets/image/notice2.png">
            </div>

            <div class="three_box">
                <div class="" style="display: flex;justify-content: space-between">
                    <div>
                        <div style="color: #fff;text-align: center;margin-top: 25px;">0.000TRX</div>
                        <div style="color: #fff;text-align: center">0.0000USDT</div>
                        <div style="margin-top: 10px;color: #fff;text-align: center">
                            Cumulative <br> rebate
                        </div>
                        <div class="lv2Box">
                            <div class="lv2Box_shadhow"></div>
                            <div><img src="{{asset('public/update')}}/assets/image/l2.png"></div>
                            <div><a href="">Level 2</a></div>
                        </div>
                    </div>

                    <div>
                        <div style="color: #fff;text-align: center">0.000TRX</div>
                        <div style="color: #fff;text-align: center">0.0000USDT</div>
                        <div style="margin-top: 10px;color: #fff;text-align: center">
                            Cumulative rebate
                        </div>
                        <div class="lv1Box" style="text-align: center">
                            <div class="lv1Box_shadhow"></div>
                            <div><img src="{{asset('public/update')}}/assets/image/l1.png"></div>
                            <div><a href="">Level 1</a></div>
                        </div>
                    </div>

                    <div>
                        <div style="color: #fff;text-align: center;margin-top: 25px;">0.000TRX</div>
                        <div style="color: #fff;text-align: center">0.0000USDT</div>
                        <div style="margin-top: 10px;color: #fff;text-align: center">
                            Cumulative <br> rebate
                        </div>
                        <div class="lv3Box">
                            <div class="lv2Box_shadhow"></div>
                            <div><img src="{{asset('public/update')}}/assets/image/l3.png"></div>
                            <div><a href="">Level 3</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section style="margin-top: 210px" class="resgvgsv">
    <div style="overflow: hidden">
        <div style="width: 30%;text-align: center;float: left">
            <strong>Grade</strong>
            <div>Lv1 (1.0%)</div>
        </div>
        <div style="width: 40%;text-align: center;float: left">
            <strong>Rebate amount</strong>
            <div>0.0000TRX</div>
        </div>
        <div style="width: 30%;text-align: center;float: left">
            <div><button>Receive</button></div>
        </div>
    </div>

    <div style="overflow: hidden; margin: 20px 0;">
        <div style="width: 30%;text-align: center;float: left">
            <strong>Grade</strong>
            <div>Lv1 (0.5.0%)</div>
        </div>
        <div style="width: 40%;text-align: center;float: left">
            <strong>Rebate amount</strong>
            <div>0.0000TRX</div>
        </div>
        <div style="width: 30%;text-align: center;float: left">
            <div><button>Receive</button></div>
        </div>
    </div>

    <div style="overflow: hidden">
        <div style="width: 30%;text-align: center;float: left">
            <strong>Grade</strong>
            <div>Lv1 (0.3%)</div>
        </div>
        <div style="width: 40%;text-align: center;float: left">
            <strong>Rebate amount</strong>
            <div>0.0000TRX</div>
        </div>
        <div style="width: 30%;text-align: center;float: left">
            <div><button>Receive</button></div>
        </div>
    </div>
</section>

<section class="rebate_rules">
    <h6>Rebate rules</h6>
    <p>1. After the friend registers, each real transaction can earn a corresponding proportion of commission.</p>
    <p>2. The highest rebate ratio is 1.8%, settled in USDT, rebate after transaction, can be withdrawn to your trading account at any time.</p>
    <p>3. If abnormal behaviors such as malicious promotion or self-promotion are found, the platform has the right to freeze the promotion account or cancel the promotion qualification.</p>
</section>

<div class="subcription_bonus">
    <a href="{{route('youtube')}}">Get One Time Bonus</a>
</div>

<div style="height: 140px"></div>

@include('app.layout.manu')
@include('app.layout.js')
</body>
</html>
