<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FFI</title>
    <!-- favicon icon -->
    <link rel="icon" href="{{asset('public/footbal')}}/assets/image/favicon.ico">
    <!-- === Font awesome === -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- === Css Area Start === -->
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/global.css">
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/style.css">
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/setting.css">
</head>
<body>
@include('alert-message')
<div class="loader">
    <img class="loading_img" src="{{asset('public/footbal')}}/assets/image/loding.jpg" style="position: fixed;z-index: 999;width: 100px;top: 50%;left: 50%;transform: translate(-50%, -50%);">
</div>
<div class="setting_container">
    <div class="setting_banner" style="background: url('{{asset('public/footbal')}}/assets/image/bill-bg.png');padding: 50px 0">
        <h2>
            <span style="top: 54px" onclick="window.location.href = '{{route('setting')}}'"><i class="fa fa-chevron-left"></i></span>
            Transaction Password
        </h2>

        <p style="padding-left: 15px;padding-right: 15px;">Set your transaction password to maximize the protection of your account assets</p>
    </div>

    <div class="setting_body" style="top: 170px;">
        <form action="">
            <div class="custom_input input-group" style="margin-top: 0">
                <label for="old_password">New transaction password</label>
                <input type="text" placeholder="Enter a new transaction password" id="old_password">
            </div>

            <div class="custom_input input-group">
                <label for="new_password">Confirm the transaction password</label>
                <input type="text" placeholder="Confirm the transaction password" id="new_password">
            </div>

            <div class="custom_input input-group">
                <label for="confirm_password">Login password</label>
                <input type="text" placeholder="Enter login password" id="confirm_password">
            </div>

            <div class="custom_input input-group" style="margin-top: 50px">
                <button class="btn download-btn"
                        style="border: none;text-align: center;display: unset;font-size: 24px;height: 55px;border-radius: 50px"
                >Revise</button>
            </div>
        </form>
    </div>
</div>
<script src="{{asset('public/footbal')}}/assets/js/jquery-3.7.0.min.js"></script>
<script src="{{asset('public/footbal')}}/assets/js/script.js"></script>
</body>
</html>
