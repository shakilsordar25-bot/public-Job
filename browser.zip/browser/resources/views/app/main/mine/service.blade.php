<!DOCTYPE html>
<html lang="en">
<head>
    @include('app.layout.css')
    <style>
        .service-page {
    background: #000;
}
    </style>
</head>

<body>
<div class="service-page">
    <!-- header area -->
    <header class="header-section">
        <div class="container">
            <div class="header-area">
                <div class="back-icon-area" onclick="window.location.href = '{{route('mine')}}'">
                    <img src="{{asset('public/footbal')}}/assets/image/back-w.png" alt="">
                </div>
                <div class="title-area">
                    <h2>Service</h2>
                </div>
            </div>
        </div>
    </header>
    <!-- Service-Banner -->
    <section class="service-banner-section">
        <div class="container">
            <div class="banner-area">
                <h2>Customer service Welcomes you!</h2>
                <p>Welcome to the customer service center,we will serve you wholeheartedly.</p>
                <a href="javascript:void(0)" class="serve-btn">
                    consult below
                </a>
            </div>
        </div>
    </section>
    <!-- service info -->
    <section class="service-info-section">
        <div class="container">
            <div class="service-info-area">
                <div class="single-service-info">
                    <div class="service-name">
                        <img src="{{asset('public/footbal')}}/assets/image/telegram.png" alt="">
                        <p>
                            <span>{{env('APP_NAME')}} Channel ></span>
                            <span></span>
                        </p>
                    </div>
                    <div class="connect-btn"><a href="{{setting('telegram_channel')}}" class="serve-btn">Connect</a></div>
                </div>

                <div class="single-service-info">
                    <div class="service-name">
                        <img src="{{asset('public/footbal')}}/assets/image/telegram.png" alt="">
                        <p>
                            <span>{{env('APP_NAME')}} group ></span>
                            <span></span>
                        </p>
                    </div>
                    <div class="connect-btn"><a href="{{setting('telegram')}}" class="serve-btn">Connect</a></div>
                </div>

                <div class="single-service-info">
                    <div class="service-name">
                        <img src="{{asset('public/footbal')}}/assets/image/telegram.png" alt="">
                        <p>
                            <span>Customer Service ></span>
                            <span></span>
                        </p>
                    </div>
                    <div class="connect-btn"><a href="{{setting('telegram_group')}}" class="serve-btn">Connect</a></div>
                </div>
            </div>
        </div>
    </section>
</div>


<!-- menu area -->
@include('app.layout.manu')

<!-- === Script Area === -->
@include('app.layout.js')

</body>
</html>
