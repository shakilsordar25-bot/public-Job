<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{env('APP_NAME')}}</title>
    <!-- favicon icon -->
    <link rel="icon" href="assets/image/favicon.ico">
    <!-- === Font awesome === -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- === Css Area Start === -->
    <link rel="stylesheet" href="assets/css/global.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/setting.css">
    <style>
        body {
            background: url('{{asset('public/footbal')}}/assets/image/guide.jpg');
            background-attachment:fixed;
            background-position: center center;
            background-repeat: no-repeat;
            background-size: cover;
            height: 100%;
        }
        .flex_  {
            position: relative;
        }
        .flex_ h4 {
            color: #fff;
            font-size: 20px;
            text-align: center;
            margin-top: 42px;
        }
        .flex_ i {
            color: #fff;
            font-size: 19px;
            position: absolute;
            left: 25px;
            top: 0;
        }
        p {
            color: #fff;
            font-size: 16px;
        }
    </style>
</head>
<body>
@include('alert-message')
<div class="loader">
    <img class="loading_img" src="{{asset('public/footbal')}}/assets/image/loding.jpg" style="position: fixed;z-index: 999;width: 100px;top: 50%;left: 50%;transform: translate(-50%, -50%);">
</div>
<div class="guide">
    <div class="flex_">
        <h4>Novice guide</h4>
        <span onclick="window.location.href = '{{route('mine')}}'">
            <i class="fa fa-chevron-left"></i>
        </span>
    </div>
</div>

<div class="container">
    <div class="row" style="margin-top: 25px;">
        <div class="col-12">
            <p><p><strong>Welcome to "FFI", investing in football fields is a field full of opportunities and potential.</strong></p><p><br></p><p><strong><em>If you don't know how to make money, please carefully read the methods below to make money, which will be of great help to you.</em></strong></p><p><br></p><p><strong>Beginners earn money Raiders:</strong></p><p><br></p><p>1. New users can receive the product "Altford Stadium" for free after registration, and they can get <strong>Tk.187.80</strong> within 3 days. Hourly income of Tk.2.61 is automatically added to the balance.</p><p>Example: You get the product at 10:00am, you will get Tk.2.61 at 11:00am. Revenue will stop after the product expires.</p><p>This is a benefit for new users, and learn how to obtain investment income through this product.</p><p><br></p><p>2. How to get more investment income?</p><p>Recharge to buy other products, the higher the amount of products purchased, the higher the income. Earn income every hour after purchase.</p><p><br></p><p>3. How to invest in preferential products?</p><p>Enter the limited-time rush area, the platform will update the number of products at 0:00 every day, and there will be corresponding discounts. The limited number is first-come-first-served.</p><p><br></p><p><strong><em>You can make money without recharging:</em></strong></p><p>1. Become an agent of the platform and grow your own team. Just share your promotional link with your friends or on social platforms.</p><p><br></p><p>2. Invite new users to register to get Tk.10, up to Tk.300</p><p><br></p><p>3. When the number of invited users reaches 50, you can also get products with a price of Tk.1500 for free, daily income can get Tk.125, and total income can get Tk.45625</p><p><br></p><p>4. The users you invite are all level 1 users, and you can get a 10% rebate after the level 1 users purchase products for the first time.</p><p><br></p><p>For example: you have 1 level 1 user who purchased a product worth Tk.10000, your rebate is: Tk.10000 × 10% = Tk.1000</p><p><br></p><p>For example: you have 10 level 1 users, each of whom purchased a product worth Tk.10000, your income is:</p><p>Tk.10000 × 10% × 10 = Tk.10000</p><p><br></p><p>Rebate earnings are added directly to your balance.</p><p><br></p><p>Rebate Description:</p><p>Invite invest price Tk.2000 product, you can get Tk.200</p><p>Invite invest price Tk.3600 product, you can get Tk.360</p><p>Invite invest price Tk.5500 product, you can get Tk.550</p><p>Invite invest price Tk.7500 product, you can get Tk.750</p><p>Invite invest price Tk.15000 product, you can get Tk.1500</p><p>Invite invest price Tk.20000 product, you can get Tk.2000</p><p>Invite invest price Tk.30000 product, you can get Tk.3000</p><p>Invite invest price Tk.40000 product, you can get Tk.4000</p><p>Invite invest price Tk.50000 product, you can get Tk.5000</p><p>Invite invest price Tk.70000 product, you can get Tk.7000</p><p>Invite invest price Tk.100000 product, you can get Tk.10000</p><p>Invite invest price Tk.120000 product, you can get Tk.12000</p><p>Invite invest price Tk.150000 product, you can get Tk.15000</p><p>Invite invest price Tk.200000 product, you can get Tk.20000</p><p>Invite invest price Tk.250000 product, you can get Tk.25000</p><p><br></p><p>5. Plus, you get team commissions when your team members earn hourly.</p><p>Team level 1, level 2, level 3 commission (4%, 2%, 1%)</p><p>If you invest in non-experience football stadiums, the commission can be upgraded to (8%, 4%, 2%)</p><p><br></p><p>You invite 10 level 1 members to join. Teach your level 1 members to do the same things as you. If they each invite 10 people to join, you get 100 level 2 membeTk. Teach your level 2 members to do the same as you. If they each invite 10 people to join, you get 1000 level 3 membeTk.</p><p><br></p><p>If you invest and upgrade the commission rate (8%, 4%, 2%)</p><p><br></p><p>And when the team members have purchased the stadium for Tk.10000</p><p><br></p><p>The formula for calculating your daily commission income is:</p><p><br></p><p>Level 1 member commission: 666×10×8% = Tk.532.8</p><p>Level 2 member commission: 666×100×4% = Tk.2664</p><p>Level 3 member commission: 666×1000×2% = Tk.13320</p><p><br></p><p>By calculating you can get daily:</p><p>Tk.532.8+2664+13320 = Tk.16516.8 commission income</p><p><br></p><p>Thank you for reading this money-making strategy so patiently. In fact, it is very simple, and hard work will definitely pay off. If you still have questions, you can contact our customer service to help you one-on-one.</p><p><br></p></p>
        </div>
    </div>
</div>
<script src="{{asset('public/footbal')}}/assets/js/jquery-3.7.0.min.js"></script>
<script src="{{asset('public/footbal')}}/assets/js/script.js"></script>

</body>
</html>
