<!DOCTYPE html>
<html lang="en">
<head>
    @include('app.layout.css')
</head>
<style>
    .card {
        padding: 12px;
        box-shadow: 0px 5px 10px #00000026;
        border-radius: 5px;
        margin: 10px 0;
    }
</style>
<body>
<div class="wrapper profile-page" style="padding-top: 0">
    <div style="display: flex;justify-content: space-between;background: #060606;color: #fff;padding: 12px 16px;">
        <div onclick="window.location.href='{{route('mine')}}'"><i class="fa fa-chevron-left"></i></div>
        <div>Change Password</div>
        <div></div>
    </div>

    <style>
        .card {
            padding: 12px;
            box-shadow: 0px -4px 0px #060606;
            border-radius: 5px;
            margin: 10px 0;
        }
        input {
            width: 100%;
            padding: 15px 8px;
            margin: 5px 0;
            border-radius: 5px;
            border: 1px solid #060606;
        }
        input:focus-visible{
            outline: none;
            border: 1px solid #060606;
        }
        button.btn.download-btn {
            background: #060606;
            padding: 10px 50px;
            font-size: 18px;
            color: #fff;
        }
    </style>

    @include('alert-message')
    <div class="card">
        <div class="card-header">
            <h2 style="margin: 0;font-size: 15px;border-bottom: 1px dashed #0000004d;padding-bottom: 15px;text-align: center">You can update your password</h2>
        </div>
        <div class="card-body" style="padding-top: 0;">
            <form action="{{route('setting.change.password')}}" method="post">@csrf
                <div class="custom_input input-group" style="margin-top: 0">
                    <label for="old_password">Current password</label>
                    <input type="password" name="old_password" placeholder="Please enter phone number" id="old_password" required>
                </div>

                <div class="custom_input input-group" style="margin: 10px 0">
                    <label for="new_password">New password</label>
                    <input type="password" name="new_password" placeholder="Please enter a new password" id="new_password" required>
                </div>

                <div class="custom_input input-group">
                    <label for="confirm_password">Confirm new password</label>
                    <input type="password" name="confirm_password" placeholder="Enter the new password again" id="confirm_password" required>
                </div>

                <div class="custom_input input-group" style="margin-top: 30px;text-align: center">
                    <button class="btn download-btn"
                            style="border: none;text-align: center;display: unset;border-radius: 50px"
                    >Update Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- menu area -->
@include('app.layout.manu')

<!-- === Script Area === -->
@include('app.layout.js')

</body>
</html>
