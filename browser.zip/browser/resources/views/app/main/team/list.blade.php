<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <!-- === Google Fonts === -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <title>{{env('APP_NAME')}}-Refer list</title>
    <style>
        body{
            background: url('{{asset('public/update')}}/assets/image/auth-bg.png');
            background-size: cover;
        }
        .member-card {
            background: #fff;
            padding: 9px 0;
            margin: 8px 0;
            border-radius: 7px;
        }
    </style>

</head>
<body>

<div style="display: flex;justify-content: space-between;padding: 10px 15px;">
    <div style="color: #fff;" onclick="window.location.href='{{url('team')}}'"><i class="fa fa-chevron-left"></i></div>
    <div style="color: #fff">Member List</div>
    <div></div>
</div>

@if($users->count() > 0)
@foreach($users as $user)
    <div class="member-card">
        <div style="display: flex;justify-content: space-between;padding: 2px 15px;">
            <div style="color: #000"><i class="fa fa-phone"></i> {{substr($user->phone, 0, 3)}}******{{substr(strrev($user->phone), 0, 2)}}</div>
            <div style="color: #000">Invest Amount</div>
        </div>
        <div style="display: flex;justify-content: space-between;padding: 2px 15px;">
            <div style="color: #000"><i class="fa fa-clock"></i> {{ \Carbon\Carbon::parse($user->created_at)->format('d-m-Y H:i:s')}}</div>
            <div style="color: #000">{{price($user->invest_balance)}}</div>
        </div>
    </div>
@endforeach
@else
    <h2 style="    color: #fff;
    text-align: center;
    font-size: 37px;
    margin-top: 100px;
    text-shadow: 0px 2px #2cec00;
    box-shadow: 0px 5px 10px;
    padding: 14px 0;">Member empty</h2>
@endif
</body>
</html>

