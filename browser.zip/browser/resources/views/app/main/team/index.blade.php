<!DOCTYPE html>
<html lang="en">

<head>
    @include('app.layout.css')
    <link rel="stylesheet" href="{{asset('public/update')}}/assets/css/style.css">
</head>
<script src="{{asset('public/team')}}/assets/js/toast.js"></script>
<body>
@include('app.layout.loading')
@include('alert-message')
<style>
    body {
        background-color: #fff;
    }
    .lv1Box {
        padding-bottom: 25px;
    }
    .lv2Box {
        padding: 8px 0;
    }
    .lv3Box {
        padding: 8px 0;
    }
    body {
        padding: 0;
    }
    .resgvgsv strong {
        color: #fff;
    }
    .resgvgsv div {
        color: #fff;
    }
    .lv1Box {
        background: #000;
    }
    .lv1Box_shadhow {
        border-bottom: 16px solid #000;
    }
    .lv2Box_shadhow {
        border-bottom: 16px solid #000;
    }

    .lv3Box {
        background: #000;
    }
    .lv2Box {
        background: #000;
    }
    .mar marquee {
        background: linear-gradient(0deg,#484848,#000000);
    }
    img.notices {
        display: none;
    }
    .team_banner {
        background: linear-gradient(90deg,#404743,#312b2b);
    }
    .rebate_text {
        top: 8px;
        font-size: 20px;
    }
</style>

<section class="team_banner" style="height: 45px;">
    <div class="team_header container" style="padding: 12px 0;">
        <div><i class="fa fa-chevron-left"></i></div>
        <div style="font-weight: bold">Team member</div>
        <div style="font-size: 14px"></div>
    </div>
</section>

<section class="team_banner" style="height: 250px;">
    <div class="rebate">
        <div class="rebate_text" style="height: 50px">
            <h3 style="font-style: italic">High rebate: unlimited%</h3>
        </div>

        <div
            class="rebate_box"
            style="height: 320px;
                background-image: url('{{asset('public/update')}}/assets/image/horse.6d4ccf46.png'), linear-gradient(rgb(0 0 0 / 80%), rgb(0 0 0 / 80%))"
        >
            <div class="mar" style="position: relative;">
                <marquee>
                    Welcome to {{env('APP_NAME')}}. You can unlimited earn money using this platform. just you can invest minimum balance.
                </marquee>
                <img class="notices" src="{{asset('public/update')}}/assets/image/notice2.png">
            </div>

            <div class="three_box">
                <div class="" style="display: flex;justify-content: space-between">
                    <div>
                        <div style="color: #fff;text-align: center;margin-top: 25px;">{{price(auth()->user()->received_balance2)}}</div>
                        <div style="margin-top: 10px;color: #fff;text-align: center">
                            Cumulative <br> rebate
                        </div>
                        <div class="lv2Box">
                            <div class="lv2Box_shadhow"></div>
                            <div><img src="{{asset('public/update')}}/assets/image/l2.png"></div>
                            <div><a href="{{route('team.list', json_encode($second_level_users->pluck('id')))}}">Level 2</a></div>
                            <div style="color:#fff;">{{$second_level_users->count()}}</div>
                        </div>
                    </div>

                    <div>
                        <div style="color: #fff;text-align: center">{{price(auth()->user()->received_balance1)}}</div>
                        <div style="margin-top: 10px;color: #fff;text-align: center">
                            Cumulative rebate
                        </div>
                        <div class="lv1Box" style="text-align: center">
                            <div class="lv1Box_shadhow"></div>
                            <div><img src="{{asset('public/update')}}/assets/image/l1.png"></div>
                            <div><a href="{{route('team.list', json_encode($first_level_users->pluck('id')))}}">Level 1</a></div>
                            <div style="color:#fff;">{{$first_level_users->count()}}</div>
                        </div>
                    </div>

                    <div>
                        <div style="color: #fff;text-align: center;margin-top: 25px;">{{price(auth()->user()->received_balance3)}}</div>
                        <div style="margin-top: 10px;color: #fff;text-align: center">
                            Cumulative <br> rebate
                        </div>
                        <div class="lv3Box">
                            <div class="lv2Box_shadhow"></div>
                            <div><img src="{{asset('public/update')}}/assets/image/l3.png"></div>
                            <div><a href="{{route('team.list', json_encode($third_level_users->pluck('id')))}}">Level 3</a></div>
                            <div style="color:#fff;">{{$third_level_users->count()}}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section style="margin-top: 210px" class="resgvgsv">
    <div style="overflow: hidden">
        <div style="width: 30%;text-align: center;float: left">
            <strong>Grade</strong>
            <div>Lv1 (8.0%)</div>
        </div>
        <div style="width: 40%;text-align: center;float: left">
            <strong>Rebate amount</strong>
            <div>{{price(auth()->user()->recharge_1_com)}}</div>
        </div>
        <div style="width: 30%;text-align: center;float: left">
            <div><button
                    style="@if(auth()->user()->recharge_1_com > 0) @else color:#b5c0bc; @endif"
                    @if(auth()->user()->recharge_1_com > 0) onclick="window.location.href='{{route('get_recharge_amount', 'com1')}}'" @endif
                >Receive</button></div>
        </div>
    </div>

    <div style="overflow: hidden; margin: 20px 0;">
        <div style="width: 30%;text-align: center;float: left">
            <strong>Grade</strong>
            <div>Lv2 (3.0%)</div>
        </div>
        <div style="width: 40%;text-align: center;float: left">
            <strong>Rebate amount</strong>
            <div>{{price(auth()->user()->recharge_2_com)}}</div>
        </div>
        <div style="width: 30%;text-align: center;float: left">
            <div><button
                    style="@if(auth()->user()->recharge_2_com > 0) @else color:#b5c0bc; @endif"
                    @if(auth()->user()->recharge_2_com > 0) onclick="window.location.href='{{route('get_recharge_amount', 'com2')}}'" @endif
                >Receive</button></div>
        </div>
    </div>

    <div style="overflow: hidden">
        <div style="width: 30%;text-align: center;float: left">
            <strong>Grade</strong>
            <div>Lv3 (1%)</div>
        </div>
        <div style="width: 40%;text-align: center;float: left">
            <strong>Rebate amount</strong>
            <div>{{price(auth()->user()->recharge_3_com)}}</div>
        </div>
        <div style="width: 30%;text-align: center;float: left">
            <div><button
                    style="@if(auth()->user()->recharge_3_com > 0) @else color:#b5c0bc; @endif"
                    @if(auth()->user()->recharge_3_com > 0) onclick="window.location.href='{{route('get_recharge_amount', 'com3')}}'" @endif
                >Receive</button></div>
        </div>
    </div>
</section>

<style>
    table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
        text-align: center;
        padding: 4px 0;
        font-weight: 700;
    }
</style>

<section class="rebate_rules" style="margin-top: 15px !important;background: #fff;">
    <h6>VIP Commission(%)</h6>
    <table style="width:100%">
        <tr>
            <th>Grade</th>
            <th>Illustrate</th>
            <th>Ratio</th>
        </tr>
        <tr>
            <td>Lv1</td>
            <td>Directly invited users</td>
            <td>8%</td>
        </tr>
        <tr>
            <td>Lv2</td>
            <td>Users invited by L1 users</td>
            <td>3%</td>
        </tr>
        <tr>
            <td>Lv3</td>
            <td>Users invited by L2 users</td>
            <td>1%</td>
        </tr>
    </table>
</section>

<section class="rebate_rules" style="margin-top: 8px !important;background: #fff;">
    <h6>Recharge Commission(%)</h6>
    <table style="width:100%">
        <tr>
            <th>1st(%)</th>
            <th>2nd(%)</th>
            <th>3trd(%)</th>
        </tr>
        <tr>
            <td>{{setting('recharge_1_commission')}}%</td>
            <td>{{setting('recharge_2_commission')}}%</td>
            <td>{{setting('recharge_3_commission')}}%</td>
        </tr>
    </table>
</section>


{{--<section class="rebate_rules">--}}
{{--    <h6>Rebate rules</h6>--}}
{{--    <p>1. After the friend registers, each real transaction can earn a corresponding proportion of commission.</p>--}}
{{--    <p>2. The highest rebate ratio is 10%, settled in Tk, rebate after transaction, can be withdrawn to your trading account at any time.</p>--}}
{{--    <p>3. If abnormal behaviors such as malicious promotion or self-promotion are found, the platform has the right to freeze the promotion account or cancel the promotion qualification.</p>--}}
{{--</section>--}}



<div style="height: 140px"></div>

@include('app.layout.manu')
@include('app.layout.js')
</body>
</html>
