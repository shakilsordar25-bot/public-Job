<!DOCTYPE html>
<html lang="en">

<head>
    @include('app.layout.css')
</head>
<script src="{{asset('public/team')}}/assets/js/toast.js"></script>
<body>
@include('app.layout.loading')
@include('alert-message')
<!-- <div class="wrapper profile-page">

</div> -->
<div class="team-uis">
    <div class="nav-top">
        <div class="info-cont flex">
            <p class="info-name">Team</p>
            <div class="right-deposit"  >
                <p onclick="window.location.href='{{route('recharge')}}'">Recharge</p>
            </div>
        </div>
        <div class="img-link"  >
            <div class="link-top flex"  >
                <div class="left"  >
                    <img src="{{asset('public/footbal')}}/assets/image/team/team-world.png"/>
                    <p  >My invitation code</p>
                </div>
                <button class="copy" onclick="copy_code('{{auth()->user()->ref_id}}')" >Copy</button>
            </div>
            <p class="cont-link codes"  >{{auth()->user()->ref_id}}</p>
            <div class="link-top flex"  >
                <div class="left"  >
                    <img src="{{asset('public/footbal')}}/assets/image/team/team-world.png" alt=""   />
                    <p  >My invite link</p>
                </div>
                <button class="copy" onclick="copy_code('{{url('register').'?invite='.auth()->user()->ref_id.'&invite_type=user&repitation='.rand(000000, 999999).'&lang=en'}}')">Copy</button>
            </div>
            <p class="cont-link">
                {{url('register').'?invite='.auth()->user()->ref_id.'&invite_type=user&repitation='.rand(000000, 999999).'&lang=en'}}
            </p>
        </div>
        <div class="total-income"  >
            <div class="left"  >
                <p class="onenumber">Commission Balance</p>
                <p class="twonumber">{{price( auth()->user()->commission_balance )}}</p>
{{--                <p class="twonumber">{{price(  $team_commission['first_team_commission'] + $team_commission['second_team_commission'] + $team_commission['third_team_commission'] + auth()->user()->received_balance1 + auth()->user()->received_balance2 + auth()->user()->received_balance3   )}}</p>--}}
                <p class="people"  >
                    People <span  >{{$first_level_users->count() + $second_level_users->count() + $third_level_users->count()}}</span>
                </p>
            </div>
            <img class="img-right" src="{{asset('public/footbal')}}/assets/image/team/team-money-bag.png" alt=""   />
        </div>
    </div>
    <div class="cont-tier flex"  >
        <div class="left-info"  >
            <div class="topui"  >
                <img class="img1" src="{{asset('public/footbal')}}/assets/image/team/team-man.png" alt=""   />
                <p  >Team information</p>
            </div>
            <img class="img2" src="{{asset('public/footbal')}}/assets/image/team/team-arrow.png" alt=""   />
        </div>
        <div class="right-level">
            <div class="level">
                <div class="top-tier flex">
                    <p>
                        Tier 1 Team <span>({{$commission['first_commission']}}% rebate)</span>
                    </p>
                    <div class="morei">
                        <p>View more</p>
                        <img src="{{asset('public/footbal')}}/assets/image/me/next.png" class="team-next" alt="">
                    </div>
                </div>
                <div class="amount">
                    <div class="rebate">
                        <p class="top">{{$first_level_users->count()}}</p>
                        <span>People</span>
                    </div>
                    <div class="commis"  >
                        <p  >{{price($team_commission['first_team_commission'])}}</p>
                        <span  >Commissions</span>
                    </div>
                    <div class="rebate"  >
                        <p class="top"  >{{price($today_commission['first_team_today_commission'])}}</p>
                        <div class="bottomday"  >
                            <p class="todyi"  >Today's</p>
                            <p class="todyi"  >Commission</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="level"  >
                <div class="top-tier flex"  >
                    <p  >
                        Tier 2 Team <span  >({{$commission['second_commission']}}% rebate)</span>
                    </p>
                    <div class="morei"  >
                        <p  >View more</p>
                        <img src="{{asset('public/footbal')}}/assets/image/me/next.png" class="team-next" alt="">
                    </div>
                </div>
                <div class="amount"  >
                    <div class="rebate"  >
                        <p class="top"  >{{$second_level_users->count()}}</p>
                        <span  >People</span>
                    </div>
                    <div class="commis"  >
                        <p  >{{price($team_commission['second_team_commission'])}}</p>
                        <span  >Commissions</span>
                    </div>
                    <div class="rebate"  >
                        <p class="top"  >{{price($today_commission['second_team_today_commission'])}}</p>
                        <div class="bottomday"  >
                            <p class="todyi"  >Today's</p>
                            <p class="todyi"  >Commission</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="level"  >
                <div class="top-tier flex"  >
                    <p  >
                        Tier 3 Team <span  >({{$commission['three_commission']}}% rebate)</span>
                    </p>
                    <div class="morei"  >
                        <p  >View more</p>
                        <img src="{{asset('public/footbal')}}/assets/image/me/next.png" class="team-next" alt="">
                    </div>
                </div>
                <div class="amount"  >
                    <div class="rebate"  >
                        <p class="top"  >{{$third_level_users->count()}}</p>
                        <span  >People</span>
                    </div>
                    <div class="commis"  >
                        <p  >{{price($team_commission['third_team_commission'])}}</p>
                        <span  >Commissions</span>
                    </div>
                    <div class="rebate"  >
                        <p class="top"  >{{price($today_commission['third_team_today_commission'])}}</p>
                        <div class="bottomday"  >
                            <p class="todyi"  >Today's</p>
                            <p class="todyi"  >Commission</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div style="margin-top: 20px">
        <div class="loass">
            <div class="wastage flex">
                <div class="invita-top twouis">
                    <img src="{{asset('public/footbal')}}/assets/image/team/team-gift.png" />
                    <p  >Invite tier 1 team to recharge bonus {{setting('recharge_1_commission')}}%</p>
                </div>
            </div>
            <div class="cont-loss flex">
                <div class="yesterday flex">
                    <div class="availa">
                        <span>{{price(auth()->user()->received_balance1)}}</span>
                        <p>Received</p>
                    </div>
                    <div class="availa twoi">
                        <span class="made">{{price(auth()->user()->recharge_1_com)}}</span>
                        <p>Available to received</p>
                    </div>
                </div>
                <button class="receiveti"
                        style="@if(auth()->user()->recharge_1_com > 0) opacity:1; @else opacity:.4; @endif"
                        @if(auth()->user()->recharge_1_com > 0) onclick="window.location.href='{{route('get_recharge_amount', 'com1')}}'" @endif
                >Received</button>
            </div>
        </div>

        <div class="loass">
            <div class="wastage flex">
                <div class="invita-top twouis">
                    <img src="{{asset('public/footbal')}}/assets/image/team/team-gift.png" />
                    <p  >Invite tier 2 team to recharge bonus {{setting('recharge_2_commission')}}%</p>
                </div>
            </div>
            <div class="cont-loss flex">
                <div class="yesterday flex">
                    <div class="availa">
                        <span>{{price(auth()->user()->received_balance2)}}</span>
                        <p>Received</p>
                    </div>
                    <div class="availa twoi">
                        <span class="made">{{price(auth()->user()->recharge_2_com)}}</span>
                        <p>Available to received</p>
                    </div>
                </div>
                <button class="receiveti"
                        style="@if(auth()->user()->recharge_2_com > 0) opacity:1; @else opacity:.4; @endif"
                        @if(auth()->user()->recharge_2_com > 0) onclick="window.location.href='{{route('get_recharge_amount', 'com2')}}'" @endif
                >Received</button>
            </div>
        </div>

        <div class="loass">
            <div class="wastage flex">
                <div class="invita-top twouis">
                    <img src="{{asset('public/footbal')}}/assets/image/team/team-gift.png" />
                    <p  >Invite tier 3 team to recharge bonus {{setting('recharge_3_commission')}}%</p>
                </div>
            </div>
            <div class="cont-loss flex">
                <div class="yesterday flex">
                    <div class="availa">
                        <span>{{price(auth()->user()->received_balance3)}}</span>
                        <p>Received</p>
                    </div>
                    <div class="availa twoi">
                        <span class="made">{{price(auth()->user()->recharge_3_com)}}</span>
                        <p>Available to received</p>
                    </div>
                </div>
                <button class="receiveti"
                        style="@if(auth()->user()->recharge_3_com > 0) opacity:1; @else opacity:.4; @endif"
                        @if(auth()->user()->recharge_3_com > 0) onclick="window.location.href='{{route('get_recharge_amount', 'com3')}}'" @endif
                >Received</button>
            </div>
        </div>
    </div>
    <p class="textui"  >
        1.Every user of Tier1,2 and 3 teams can get discount while recharging.<br /><br />

        Profit Margin: <br>
        Tier 1 team 6% <br>
        Tier 2 Team 3%<br>
        Tier 3 Team 1%<br><br>
        For example: <br><br>
        Tier 1 team user you are invited to recharge Rs 10000, you can get Tk 600. <br>
        Tier 2 team users invited by Tier 1 team recharge 10000, you can get 300.<br>
        Tier 3 team users 10000 recharge invited by Tier 2 team, you can get Tk.100.<br>
        2. You can earn invited members and a profit, they can get income.<br /><br />
        Tier 1 Team 10% <br>
        Tier 2 Team 4%<br>
        Tier 3 Team 1%<br><br>

        For example: <br><br>
        When your member of the system makes a profit, you can get the appropriate profit controlled by the system. This is the profit from the daily earnings of your members.
        <br>
        <br>
        3. If you want to get more benefits, please contact our marketing team i.e. join Telegram discussion group.
    </p>

    <script>
        function copy_code(text)
        {
            const body = document.body;
            const input = document.createElement("input");
            body.append(input);
            input.style.opacity = 0;
            input.value = text.replaceAll(' ', '');
            input.select();
            input.setSelectionRange(0, input.value.length);
            document.execCommand("Copy");
            input.blur();
            input.remove();
            message('Copy successfully')
        }
    </script>
    <!-- menu area -->
@include('app.layout.manu')

<!-- === Script Area === -->
@include('app.layout.js')

</body>

</html>
