<!DOCTYPE html>
<html lang="en">

<head>
    @include('app.layout.css')
    <link rel="stylesheet" href="{{asset('public/update')}}/assets/css/style.css">
</head>
<script src="{{asset('public/team')}}/assets/js/toast.js"></script>
<body>
@include('app.layout.loading')
@include('alert-message')


<section class="team_banner" style="height: 45px;">
    <div class="team_header container" style="padding: 12px 0;">
        <div onclick="window.location.href='{{route('onetime')}}'"><i class="fa fa-chevron-left"></i></div>
        <div style="font-weight: bold;color:#fff">One Time Bonus</div>
        <div style="font-size: 14px"></div>
    </div>
</section>

<style>
    label.proff_box {
        border: 1px dashed #ffffff;
    }
    button.you_submitter {
        color: #000;
        background: #fff;
    }
</style>
<section>
    <div class="imaged">
        <a href="https://www.youtube.com/channel/UCMzzTgo3FaOLruwVecgH0_A">
            <img style="width: 100%" src="{{asset('public/update')}}/assets/image/youtube-5702765_1280.png">
        </a>
    </div>
    <div class="youtube_title">
        <h3 style="text-align: left;margin-left: 15px;color:#fff">1. You can get 5tk <span> <i class="fa fa-hand-point-up"></i> Click youtube </span> </h3>
        <p style="color:#fff"> 2. Go to this youtube channel and subscribe and open all notification this channel. then take a screenshot.</p>
        <p style="color:#fff">3. Finally, submit this prof...</p>
    </div>

    <div class="submit_boxt" style="margin: 0 15px">
        <form action="{{route('work.submit', '0001')}}" method="post" style="margin-top: 10px" enctype="multipart/form-data">
            @csrf
            <label for="proff" class="proff_box">
                <img src="{{asset('public/update')}}/assets/image/upload.png">
                <div><button type="button">Upload subscribe image</button></div>
            </label>
            <input type="file" name="prof" id="proff" style="display: none" required>

            <div style="text-align: center;margin-top: 15px">
                <button type="submit" class="you_submitter">Submit</button>
            </div>
        </form>
    </div>
</section>

<section style="margin: 10px 15px">
    <h4 style="color: #fff">Notice:------</h4>
    <p style="color: #fff">1. When you purchase our Big VIP. you can get a change for free upload you channel address in this section for a month</p>
</section>

<div style="height: 100px"></div>



@include('app.layout.manu')
@include('app.layout.js')
</body>
</html>
