<!doctype html>
<html lang="en">
<head>
    @include('app.layout.css')
    <title>{{env('APP_NAME')}}-VIPs</title>
    <style>
        .fa-check-img {
            position: absolute;
            right: 22px;
            top: 60px;
        }

        .vip_item {
            height: 150px;
        }

        .overlay {
            position: absolute;
            width: 100%;
            background: #ffffff00;
            height: 96px;
            z-index: 9;
            top: 5px;
            left: 0;
            border-radius: 5px;
        }

        .lock {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            width: 70px;
            height: 70px;
            text-align: center;
            line-height: 80px;
            background: #ffffff87;
            border-radius: 50px;
        }

        .lock i {
            color: #fff;
            font-size: 30px;
        }

        body {
            background: url("{{asset('public/bg.jpg')}}") !important;
        }
        .overlay {
            height: 128px;
        }
        .text_layer {
            width: 80%;
            float: left;
            margin-top: 11px;
        }
    </style>
</head>
<body style="padding: 0 15px">
@include('app.layout.loading')
<div class="header" style="margin-bottom: 5px;margin-top: 5px">
    <div class="trade" onclick="tradeOrder('trade')">Trade</div>
    <div class="order" style="background: transparent" onclick="tradeOrder('order')">Coming soon</div>
</div>

{{--https://codepen.io/david-vighi/pen/XLBMzv     Timer with progress bar--}}

<div class="vip">
    @foreach($improvements as $improvement)
        <div class="vip_container" style="height: 132px;position: relative;overflow: hidden;margin-top: 8px;">
            @if($level && $level->id == $improvement->id)
            @else
                <div class="overlay">
                    <div class="lock"><i class="fa fa-lock"></i></div>
                </div>
            @endif

            <div class="vip_item"
                 style="background: url('{{asset('public/update')}}/assets/image/paylist.399769ed.png');background-size: cover;background-repeat: no-repeat;background-position: center">
                <div class="text_layer" style="position:relative;">
                    <div style="display: flex;justify-content: space-between" class="vip_flexer">
                        @if($level && $level->id == $improvement->id)
                            <div class="fa-check-img"><img style="width: 35px" src="">
                            </div>
                        @endif
                        <p style="font-size: 16px">{{price($improvement->amount_limit)}}
                            -{{price($improvement->between_amount)}}</p>
                        <h4>
                            <div>{{$improvement->level}}</div>
                        </h4>
                    </div>

                    <div class="vip_lecture">
                        <p>Smart commission selection</p>
                        <h4>Daily commission: {{$improvement->commission}}%<br>
                            Amount Receive everyday
                        </h4>
                    </div>
                </div>
                <div class="text-right-image">
                    <img src="{{asset(view_image($improvement->robot))}}" alt="">
                </div>
            </div>
        </div>
    @endforeach
</div>

<div class="ordered" style="display: none">

    <?php
    $levels = \App\Models\Improvment::where('status', 'inactive')->get();
    ?>
    @if($levels->count())

        <div class="vip">
            <div>
                <img style="width: 100%" src="{{asset('public/coming-soon-background-illustration-template-design-free-vector.jpg')}}">
            </div>
            @foreach($levels as $level)
                <div class="vip_container" style="height: 112px !important;overflow: hidden !important;margin-bottom: 15px !important;">
                    <div class="vip_item"
                         style="background: url('{{asset('public/update')}}/assets/image/paylist.399769ed.png');background-size: cover;background-repeat: no-repeat;background-position: center">
                        <div class="text_layer" style="position:relative;">
                            <div style="display: flex;justify-content: space-between" class="vip_flexer">
                                <div class="fa-check-img"><img style="width: 35px" src=""></div>
                                <p style="font-size: 14px">{{'Tk.'.$level->amount_limit}}
                                    -{{'Tk.'.$level->between_amount}}</p>
                                <h4 style="font-weight: normal">
                                    <div>Upcoming</div>
                                </h4>
                            </div>

                            <div class="vip_lecture">
                                <p style="margin-top: 6px;">Smart commission selection</p>
                                <h4 style="margin-top: 15px">Daily commission: {{$level->commission}}%<br></h4>

                            </div>
                        </div>
                        <div class="text-right-image">
                            <img src="{{asset(view_image($level->robot))}}" alt="">
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

    @endif
</div>

<div style="height: 100px"></div>

@include('app.layout.manu')

<script>
    function order_process(text) {
        var act = document.querySelector('.in_process');
        var oact = document.querySelector('.over');
        if (!act.classList.contains('p_active')) {
            act.classList.add('p_active');
        }
        if (oact.classList.contains('over_active')) {
            oact.classList.remove('over_active');
        }

        document.querySelector('.inproccess_container').style.display = 'block';
        document.querySelector('.over_container').style.display = 'none';
    }

    function over(text) {
        var act = document.querySelector('.in_process');
        var oact = document.querySelector('.over');

        if (!oact.classList.contains('over_active')) {
            oact.classList.add('over_active');
        }
        if (act.classList.contains('p_active')) {
            act.classList.remove('p_active');
        }

        document.querySelector('.inproccess_container').style.display = 'none';
        document.querySelector('.over_container').style.display = 'block';
    }


    function tradeOrder(item) {
        if (item === 'trade') {
            document.querySelector('.ordered').style.display = 'none';
            document.querySelector('.vip').style.display = 'block';

            document.querySelector('.order').style.background = 'transparent';
            document.querySelector('.trade').style.background = 'linear-gradient(3deg,#296df2,#296df2)';
        }

        if (item === 'order') {
            document.querySelector('.ordered').style.display = 'block';
            document.querySelector('.vip').style.display = 'none';

            document.querySelector('.trade').style.background = 'transparent';
            document.querySelector('.order').style.background = 'linear-gradient(3deg,#296df2,#296df2)';
        }
    }
</script>
</body>
</html>
