<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{env('APP_NAME')}}</title>
    <!-- favicon icon -->
    <link rel="icon" href="{{asset('public/footbal')}}/assets/image/favicon.ico">
    <!-- === Font awesome === -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
          integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <!-- === Css Area Start === -->
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/global.css">
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/animate.css">
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/style.css">
</head>
<body>
@include('alert-message')
<div class="loader">
    <img class="loading_img" src="{{asset('public/footbal')}}/assets/image/loding.jpg" style="position: fixed;z-index: 999;width: 100px;top: 50%;left: 50%;transform: translate(-50%, -50%);">
</div>
<div class="wrapper order-page">
    <section class="header">
        <div class="container">
            <div class="page-header">
                <h2>Order</h2>
            </div>
        </div>
    </section>
    <section class="assets-section">
        <div class="container">
            <div class="assets-area">
                <div class="single-assets">
                    <p>Number of investments</p>
                    <p>{{$purchases->count()}}</p>
                </div>
                <div class="single-assets">
                    <p>Investment income</p>
                    <p>{{price($vip_income)}} <i class="fa-solid fa-angle-right"></i></p>
                </div>
            </div>
        </div>
    </section>


    @if($purchases->count() > 0)
        <section class="product-section">
            <div class="container">
                <div class="title-section">
                    <img src="{{asset('public/footbal')}}/assets/image/content/title-icon.png" >
                    <h2>My product</h2>
                </div>
                <div class="product-area">
                    @foreach($purchases as $key => $elem)
                        <?php $element = $elem->package; ?>
                        <div class="single-product card">
                            <div class="card-info">
                                <div class="img">
                                    <img src="{{view_image($element->photo)}}">
                                </div>
                                <div class="text">
                                    <h3 class="product-name">
                                        {{$element->name}}
                                    </h3>
                                    <div class="limit">
                                        <img src="{{asset('public/footbal')}}/assets/image/card/safe.png" >
                                        <p>limit : <span>1</span>/1</p>
                                    </div>
                                    <div class="income">
                                        <div class="single-income">
                                            <p>{{price($element->commission_with_avg_amount != 0 ? $element->commission_with_avg_amount / $element->validity : $element->commission_with_avg_amount)}}</p>
                                            <span>Daily income</span>
                                        </div>
                                        <div class="single-income">
                                            <p>{{price($element->commission_with_avg_amount)}}</p>
                                            <span>Total income</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-pricing">
                                <div class="price">
                                    <p class="updated-price"> Price:
                                        <strong>{{price($element->price)}}</strong>
                                    </p>
                                </div>
                                <a href="javascript:void(0)" class="btn">Running</a>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </section>
    @else
        <section class="no-data-section">
            <img src="{{asset('public/footbal')}}/assets/image/content/no-data.png" alt="">
        </section>
    @endif
</div>
<!-- menu area -->
<div class="menu-area">
    <ul class="menu">
        <li class="menu-item">
            <a href="{{route('dashboard')}}">
                        <span class="menu-content">
                            <span class="menu-icon">
                                <img src="{{asset('public/footbal')}}/assets/image/menu/home.png" alt="">
                                <img src="{{asset('public/footbal')}}/assets/image/menu/active-home.png" alt="" class="image-active">
                            </span>
                            <span class="menu-name">home</span>
                        </span>
            </a>
        </li>
        <li class="menu-item active">
            <a href="{{route('order')}}">
                        <span class="menu-content">
                            <span class="menu-icon">
                                <img src="{{asset('public/footbal')}}/assets/image/menu/notice.png" alt="">
                                <img src="{{asset('public/footbal')}}/assets/image/menu/motic-active.png" alt="" class="image-active">
                            </span>
                            <span class="menu-name">order</span>
                        </span>
            </a>
        </li>
        <li class="menu-item ">
            <a href="{{route('fund')}}">
                        <span class="menu-content">
                            <span class="menu-icon">
                                <img src="{{asset('public/footbal')}}/assets/image/menu/stock.png" alt="">
                                <img src="{{asset('public/footbal')}}/assets/image/menu/stock-active.png" alt="" class="image-active">
                            </span>
                            <span class="menu-name">fund</span>
                        </span>
            </a>
        </li>
        <li class="menu-item">
            <a href="{{route('team')}}">
                        <span class="menu-content">
                            <span class="menu-icon">
                                <img src="{{asset('public/footbal')}}/assets/image/menu/apps.png" alt="">
                                <img src="{{asset('public/footbal')}}/assets/image/menu/apps-active.png" alt="" class="image-active">
                            </span>
                            <span class="menu-name">team</span>
                        </span>
            </a>
        </li>
        <li class="menu-item">
            <a href="{{route('mine')}}">
                        <span class="menu-content">
                            <span class="menu-icon">
                                <img src="{{asset('public/footbal')}}/assets/image/menu/profile.png" alt="">
                                <img src="{{asset('public/footbal')}}/assets/image/menu/profile-active.png" alt="" class="image-active">
                            </span>
                            <span class="menu-name">mine</span>
                        </span>
            </a>
        </li>
    </ul>
</div>
<script src="{{asset('public/footbal')}}/assets/js/jquery-3.7.0.min.js"></script>
<script src="{{asset('public/footbal')}}/assets/js/script.js"></script>
<script>
    window.onload = function(){
        document.querySelector(".loading_img").style.display = "none";
    }
</script>
</body>
</html>
