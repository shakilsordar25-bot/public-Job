<!DOCTYPE html>
<html lang="en">

<head>
    @include('app.layout.css')
    <link rel="stylesheet" href="{{asset('public/update')}}/assets/css/income.css">
</head>

<body style="background-image: url('{{asset('public/update')}}/assets/image/auth-bg.png');background-attachment:fixed">
@include('app.layout.loading')
<style>
    .actt {
        background: #385145 !important;
        color: #fff !important;
        border: none !important;
        padding: 2px 5px !important;
        font-size: 12px;
        border-radius: 2px !important;
    }
    a.vi_btn {
        color: #ffffff !important;
        border: 2px solid  !important;
    }
    .vi_card {
    border: 1px solid #ffffff;
}
    body{
        background: url("{{asset('public/log.jpeg')}}") !important;
    }
</style>

<section>
    <div class="vi_card" style="background-size: contain;overflow: hidden">
        <div style="width: 70%;float: left;">
            <div><img class="vIcon" src="{{asset('public/update')}}/assets/icons8-v-26.png">  <strong>@if($initial_improvement)
                        {{$initial_improvement->level}} @else N/A @endif</strong> &nbsp; &nbsp; &nbsp; @if($initial_improvement)
                        Running... @else N/A @endif  </div>
            <div><p style="margin: 12px 0">Current Yield</p></div>
            <div><h2 class="vi_commission">@if($initial_improvement)
                        {{$initial_improvement->commission}}% @else 0.00% @endif</h2></div>
            <div><p>Commission Added Cycle 24Hour</p></div>
        </div>
        <div style="width: 30%;float: right">
            <img style="width: 100%;
    margin-top: 10px;
    border-radius: 5px;" src="{{asset('public/running_robot.gif')}}">
        </div>
    </div>
    <div class="vi_card" style="padding: 0 !important;">
        @if($initial_improvement && user()->com_receible > 0)
        <div style="display: flex;justify-content: space-around;align-items: center;padding: 0px 0;border-bottom: 2px solid #fff;">
            <div>
                <img style="width: 35px" src="{{asset('public')}}/robot-chatbot-icon-sign-free-vector-removebg-preview.png">
            </div>
            <div>
                <h3 id="amount" style="font-size: 13px;font-weight: normal;">{{price(auth()->user()->com_receible)}}&nbsp;&nbsp;  (<span style="font-size: 11px;color: #fff;">Daily rate ({{$initial_improvement->commission}})%</span>)</h3>
            </div>
            <div style="text-align: right">
                <a class="vi_btn" href="javascript:void(0)" onclick="user_received_amount('{{$initial_improvement->id}}')">Receive</a>
            </div>
        </div>
        @endif

        @if($incomes->count() > 0)
        @foreach($incomes as $income)
                <div style="display: flex;justify-content: space-around;align-items: center;padding: 0px 0;border-bottom: none;">
                    <div>
                        <img style="width: 35px" src="{{asset('public')}}/robot-chatbot-icon-sign-free-vector-removebg-preview.png">
                    </div>
                    <div>
                        <h3 style="font-size: 13px;font-weight: normal;">{{price($income->amount)}}&nbsp;&nbsp; (<span style="font-size: 11px;color: #fff;">Daily rate ({{$initial_improvement->commission}})%</span>)</h3>
                    </div>
                    <div style="text-align: right">
                        <a class="vi_btn actt" href="javascript:void(0)">Received</a>
                    </div>
                </div>
        @endforeach
            @else
                @if($initial_improvement && user()->com_receible > 0)
                @else
                    <div style="padding: 10px 0;border-bottom: 2px solid #fff;">
                        <h4 style="text-align: center">Income added after 24 hours</h4>
                    </div>
                @endif

            @endif
    </div>
</section>

<!-- menu area -->
@include('app.layout.manu')
<!-- === Script Area === -->
@include('app.layout.js')

@include('alert-message')

<meta name="csrf-token" content="{{csrf_token()}}">
<script>
    function user_received_amount(improvement_id)
    {
        console.log("Hello")
        document.querySelector('.loader_boss').style.display = 'block';
        fetch('{{route('user.received.amount')}}', {
            method: "POST",
            body:JSON.stringify({improvement_id:improvement_id}),
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
            .then(response => response.json())
            .then(res => {
                if (res.status == true){
                    window.location.reload();
                }
                document.querySelector('.loader_boss').style.display = 'none';
                message(res.message);
            })
            .catch(err => console.log(err));
    }
</script>

</body>
</html>
