<!DOCTYPE html>
<html lang="en">
<head>
    @include('app.layout.css')
    <style>
        body {
            background: #ffffff;
            padding: 0;
        }
        input:focus-visible{
            outline: 0;
            border: 0;
        }
        input {
            margin-bottom: 0 !important;
        }
        .bank_banner {
            background: #000 !important;
        }
    </style>
</head>
<body>
<link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/bank.css">
@include('alert-message')

<div class="bank">
    <div class="bank_banner">
        <div class="manu" style="display: flex;justify-content: space-between;">
            <div style="color: #fff" onclick="window.location.href='{{route('mine')}}'"><i class="fa fa-chevron-left"></i></div>
            <div>
                <div class="bank_acc" style="color: #fff">Tron (TRC20)</div>
            </div>
            <div></div>
        </div>
    </div>
</div>

<div class="bank_form" style="top: 67px;">
    <form action="{{route('user.usdt_setup_confirm')}}" method="post">
        @csrf
        <div class="custom_input input-group" style="margin-top: 0">
            <label for="currency">Currency name</label>
            <input type="text"
                   value="@if(auth()->user()->usdt_name) {{auth()->user()->usdt_name}} @else {{old('usdt_name')}} @endif"
                   name="usdt_name"
                   placeholder="Enter Currency"
                   id="currency" required>
        </div>

        <div class="custom_input input-group" style="margin: 10px 0">
            <label for="usdt">Account address</label>
            <input type="text"
                   value="{{auth()->user()->usdt}}"
                   name="usdt"
                   id="usdt" required>
        </div>

        <div class="custom_input input-group" style="margin-top: 30px;text-align: center">
            <button class="btn download-btn"
                    style="border: none;text-align: center;display: unset;border-radius: 50px;margin-bottom: 12px;">Confirm binding
            </button>
        </div>
    </form>
</div>

@include('app.layout.js')
</body>
</html>
