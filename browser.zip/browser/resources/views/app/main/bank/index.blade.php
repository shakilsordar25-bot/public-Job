<!DOCTYPE html>
<html lang="en">
<head>
    @include('app.layout.css')
    <style>
        body {
            background: #ffffff;
            padding: 0;
        }
        input:focus-visible{
            outline: 0;
            border: 0;
        }
        input {
            margin-bottom: 0 !important;
        }
        .bank_banner {
            background: #000 !important;
        }
    </style>
</head>
<body>
<link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/bank.css">
@include('alert-message')

<div class="bank">
    <div class="bank_banner">
        <div class="manu" style="display: flex;justify-content: space-between;">
            <div style="color: #fff" onclick="window.location.href='{{route('mine')}}'"><i class="fa fa-chevron-left"></i></div>
            <div>
                <div class="bank_acc" style="color: #fff">Bank account</div>
            </div>
            <div></div>
        </div>
    </div>
</div>

<div class="bank_form" style="top: 67px;">
    <form action="{{route('user.bank_setup_confirm')}}" method="post">
        @csrf
        <div class="custom_input input-group" style="margin-top: 0">
            <label for="name">Your name</label>
            <input type="text"
                   value="@if(auth()->user()->name) {{auth()->user()->name}} @else {{old('name')}} @endif"
                   name="name"
                   placeholder="Please enter your real name"
                   id="name" required>
        </div>

        <div class="custom_input input-group" style="margin: 10px 0">
            <label for="text">Account address</label>
            <input type="text"
                   @if(auth()->user()->gateway_number)
                        placeholder=""
                   @else
                        placeholder="Please enter account address"
                   @endif
                   name="gateway_number"
                   id="number" required>
        </div>

        <div class="custom_input input-group type" style="margin: 10px 0" onclick="open_modal()">
            <label for="number">Account type</label>
            <input type="text"
                   @if(auth()->user()->gateway_method)
                   value="{{auth()->user()->gateway_method}}"
                   @else
                   value="Select one"
                   @endif
                   name="gateway_method"
                   id="number" required>
            <div class="icon">
                <i class="fa fa-chevron-right"></i>
            </div>
        </div>

        <div class="custom_input input-group" style="margin-top: 30px;text-align: center">
            <button class="btn download-btn"
                    style="border: none;text-align: center;display: unset;border-radius: 50px;margin-bottom: 12px;"
            >Confirm binding
            </button>
        </div>
    </form>
</div>

<div class="bank_item_content">
    <div class="bank_item">
        <div class="bank_item_header" style="display: flex;justify-content: space-between">
            <div>
                <a href="javascript:void(0)" onclick="cancel_modal()">Cancel</a>
            </div>
            <div>
                <a href="javascript:void(0)">Confirm</a>
            </div>
        </div>
        <div class="bank_item_body">
            <ul>
                @foreach(\App\Models\PaymentMethod::where('status', 'active')->get() as $element)
                    <li onclick="setGateway('{{$element->name}}')"><img style="width: 25px"
                                                           src="{{asset($element->photo)}}"> {{$element->name}}
                    </li>
                @endforeach
            </ul>
        </div>
    </div>
</div>

<script>
    function open_modal() {
        document.querySelector('.bank_item_content').style.zIndex = '1';
        document.querySelector('.bank_item').style.bottom = '0';
        document.querySelector('.bank_item_content').style.opacity = '1';
    }

    function cancel_modal() {
        document.querySelector('.bank_item_content').style.zIndex = '-1';
        document.querySelector('.bank_item').style.bottom = '-100%';
        document.querySelector('.bank_item_content').style.opacity = '0';
    }

    function setGateway(name) {
        document.querySelector('.type input').value = name;
        cancel_modal();
    }
</script>

@include('app.layout.js')
</body>
</html>
