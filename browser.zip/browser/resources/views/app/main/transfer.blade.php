<!DOCTYPE html>
<html lang="en">

<head>
    @include('app.layout.css')
    <link rel="stylesheet" href="{{asset('public/update')}}/assets/css/income.css">
</head>

<body style="background-image: url('{{asset('public/update')}}/assets/image/auth-bg.png');background-attachment:fixed">
@include('app.layout.loading')
<link rel="stylesheet" href="{{asset('public/update')}}/assets/css/creadential.css">
<section>
    <style>
        .licon {
            top: 33px;
            color: #000;
        }
        .custom_form_box button {
            color: #000;
        }
        input.custom_input {
            height: 45px;
        }
        .custom_form_box button {
            margin-top: 5px;
        }
    </style>
    <div style="display: flex;justify-content: space-between;margin-bottom: 10px">
        <div style="color: #fff;" onclick="window.location.href='{{route('mine')}}'"><i class="fa fa-chevron-left"></i></div>
        <div style="color: #fff;">Balance Transfer</div>
        <div></div>
    </div>
<div class="balance_transfer_banner">
    <img style="width: 100%;border-radius: 5px;" src="{{asset('public/does-a-balance-transfer-affect-my-credit-score.jpg')}}">
</div>


    <form action="{{route('balance.transfer')}}" method="post" style="margin-top: 0 !important;"> @csrf
        <div style="margin-top: 5px">
            <div style="margin-bottom:8px">
                <h3 style="color: #fff">Transfer your balance.</h3>
                <p style="color: #fff">Transfer commission balance to invest balance</p>
            </div>

            <div class="custom_form_box">
                <label for="" style="color: #fff;">Commission Balance</label>
                <i class="licon">Tk.</i>
                <input type="text" class="custom_input" name="commission_amount" value="{{auth()->user()->commission_balance}}" readonly>
            </div>

            <div class="custom_form_box">
                <label for="" style="color: #fff;">Invest Balance</label>
                <i class="licon">Tk.</i>
                <input type="text" class="custom_input" name="invest_balance" value="{{auth()->user()->invest_balance}}" readonly>
            </div>

            <div class="custom_form_box">
                <label for="" style="color: #fff;">Enter transfer amount</label>
                <i class="licon">Tk.</i>
                <input type="text" class="custom_input" name="amount" placeholder="Maximum your commission balance" required>
            </div>

            <div class="custom_form_box">
                <button type="submit">Transfer</button>
            </div>
        </div>
    </form>

</section>

<!-- menu area -->
@include('app.layout.manu')
<!-- === Script Area === -->
@include('app.layout.js')
@include('alert-message')
</body>
</html>
