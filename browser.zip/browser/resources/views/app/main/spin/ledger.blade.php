<!DOCTYPE html>
<html lang="en">
<head>
    @include('app.layout.css')
</head>
<style>
    .card {
        padding: 12px;
        box-shadow: 0px -2px 0px #060606;
        border-radius: 5px;
        margin: 10px 0;
        background: #29be00;
    }
</style>
<style>
    i.fa.fa-arrow-down {
        background: #060606;
        width: 25px;
        height: 25px;
        text-align: center;
        line-height: 25px;
        color: #fff;
        border-radius: 50px;
        margin-right: 5px;
    }
    i.fa.fa-arrow-right {
        background: #060606;
        width: 25px;
        height: 25px;
        text-align: center;
        line-height: 25px;
        color: #fff;
        border-radius: 50px;
        margin-right: 5px;
    }
    hr.hr {
        margin: 15px 0 0 0;
    }
</style>
<body>
@include('app.layout.loading')
<div class="wrapper profile-page" style="padding-top: 0">
    <div style="display: flex;justify-content: space-between;background: #060606;color: #fff;padding: 12px 16px;">
        <div onclick="window.location.href='{{route('span')}}'"><i class="fa fa-chevron-left"></i></div>
        <div>Spin History</div>
        <div></div>
    </div>

    <div class="container" id="recharge" style="display: block">
        @if($spins->count() > 0)
        @foreach($spins as $element)
                <div class="_card" style="margin-top: 6px">
                    <div style="padding: 0 15px;display: flex;justify-content: space-between;">
                        <div style="font-weight: 600;"><i class="fa fa-arrow-right"></i> Result</div>
                        <div style="font-weight: 600;color: #060606;">{{$element->result}}</div>
                    </div>
                    <div style="padding: 0 15px;display: flex;justify-content: space-between;">
                        <div style="margin-left: 32px;font-size: 14px;">{{$element->reason}}</div>
                        <div></div>
                    </div>
                </div>
                @if($loop->last)
                @else
                    <hr class="hr" style="margin: 4px 0 0 0;">
                @endif
        @endforeach
        @else
            <h4 style="color: #060606;text-align: center;margin-top: 20px">Data not found</h4>
        @endif
    </div>
</div>

<!-- menu area -->
@include('app.layout.manu')

<!-- === Script Area === -->
@include('app.layout.js')
</body>
</html>
