<!DOCTYPE html>
<html lang="en">
<head>
    @include('app.layout.css')
</head>

<body>
@include('app.layout.loading')
<link rel="stylesheet" href="{{asset('public/spin/spain.css')}}">
<style>
    #spin-container {
        text-align: center;
        background: linear-gradient(rgb(0 0 0 / 90%), rgb(0 0 0));
    }
    .activity_notice {
        border: 1px solid #fff;
        margin: 0 7px;
        text-align: unset;
        padding: 5px 12px;
        background: #ffffff30;
        margin-bottom: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px 4px #ffffff80;
        margin: 15px;
    }
    .spin_code {
        width: 92%;
        padding: 15px 15px;
        border: 1px solid #fff;
        margin: auto;
        margin-top: 12px;
        background: #ffffff29;
        border-radius: 5px;
    }
    button.spin_code_btn {
        background: #000;
        border: none;
        padding: 10px 21px;
        margin-top: 15px;
        color: #fff;
        font-size: 16px;
        border-radius: 5px;
        box-shadow: 0 0px 9px 2px #ffffff4a;
    }
    #spin_round {
        transition: transform 0.25s linear;
        width: 60px;
        height: 60px;
        border-radius: 50px;
    }

    #spinner {
        width: 330px;
        height: 330px;
    }
    /*div#spin {*/
    /*    width: 70px;*/
    /*    position: absolute;*/
    /*    z-index: 99;*/
    /*    left: 50%;*/
    /*    top: 50%;*/
    /*    transform: translate(-50%, -50%);*/
    /*    height: 70px;*/
    /*    text-align: center;*/
    /*    line-height: 70px;*/
    /*}*/
    div#spin {
        width: 70px;
        position: absolute;
        z-index: 99;
        left: 50%;
        top: 40px;
        transform: translate(-50%, -50%) rotate(180deg);
        height: 70px;
        text-align: center;
        line-height: 70px;
    }
    input.spin_input::placeholder {
        color: #8000106e;
    }
    input.spin_input {
        border-radius: 7px;
    }
</style>

<div class="spin_banner"
     style="background: linear-gradient(rgb(0 0 0 / 40%), rgb(0 0 0)), url(http://localhost/foonew/public/spin/image/s_banner.jpg) no-repeat;
      background-size: cover">
    <div class="spin_back">
        <div style="display: flex;justify-content: space-between;">
            <div onclick="window.location.href='{{route('dashboard')}}'"><i class="fa fa-chevron-left"></i></div>
            <div></div>
            <div style="margin-right: 15px" onclick="window.location.href='{{route('spin_result')}}'"><i class="fa fa-list"></i></div>
        </div>
    </div>
    <div>
        <h1 class="d_draw">Daily draw</h1>
        <h1 class="l_wheel">Lucky wheel</h1>
    </div>
</div>
<div id="spin-container">
    <div id="spinner" class="spin-to-win">
        <div>
            <img id="spinerImage" src="{{asset('public/spin')}}/spin.png" />
        </div>
        <div id="spin">
{{--            <img id="spin_round" onclick="CHECK_SPIN_CODE()" src="{{asset('public/spin/image')}}/draw-now.png">--}}
            <img id="spin_round" onclick="CHECK_SPIN_CODE()" src="{{asset('public/spin/image')}}/draw-now.png">
        </div>
    </div>
    <div class="congregate">
        <p id="congratulations_user"></p>
    </div>

    <div class="spin_code">
        <input type="text" class="spin_input" placeholder="Enter 10 amount">
        <button type="button" class="spin_code_btn" onclick="SUBMIT_SPIN_CODE()">Spin Permission</button>
    </div>

    <div class="activity_notice">
        <p>1. first find out your choosing decision for lucky drow. you can winner or get loss</p>
        <p>2. Contact Telegram {{env('APP_NAME')}} official member to get more information.</p>
    </div>
</div>
<meta name="csrf-token" content="{{ csrf_token() }}" />
@include('alert-message')
{{--<script src="{{asset('public/spin/spain.js')}}"></script>--}}

<!-- menu area -->
@include('app.layout.manu')
<!-- === Script Area === -->
@include('app.layout.js')

<script>
    setInterval(function (){
        function randomIntFromInterval(min, max) {
            return Math.floor(Math.random() * (max - min + 1) + min)
        }
        document.getElementById('congratulations_user').innerHTML = `Congratulations user${randomIntFromInterval(1,99)} ${randomIntFromInterval(100,999)}*****${randomIntFromInterval(100,999)} for get Tk.${randomIntFromInterval(11,29)}.00`
    }, 2000)
</script>

<script>
    var spinBtn = document.querySelector('#spin-btn')
    var spinArrow = document.querySelector('#spin_round')
    var spinerImage = document.getElementById('spinerImage');

    var goForSpan = '';

    let value = Math.ceil(Math.random() * 4000);

    function spinToWin() {
        spinerImage.style.transition = '5s';
        spinerImage.style.transform = 'rotate('+ value +'deg)';

        for (let i=0; i<value;i++){
            if (value >= 380){
                value = value - 360
            }
        }

        /** Start Calculate Amount Using Rotate DEG**/
        var amount = 0
        if (value >= 0 && value <= 48){
            amount = '5'
        }else if(value >= 49 && value <= 96){
            amount = 'loss'
        }else if(value >= 97 && value <= 138){
            amount = "-10"
        }else if(value >= 139 && value <= 180){
            amount = 'thankyou'
        }else if(value >= 181 && value <= 220){
            amount = '10+'
        }else if(value >= 221 && value <= 262){
            amount = "star"
        }else if(value >= 263 && value <= 308){
            amount = '-3'
        }else if(value >= 309 && value <= 358){
            amount = 'winner'
        }else if(value >= 357 && value <= 380){
            amount = 'again'
        }
        /** End Calculate Amount **/
        /** Start Ajax Amount **/
        var data = {
            spin: amount
        }
        fetch('{{route('user.spin.amount.submit')}}',
            {
                method:"POST",
                body:JSON.stringify(data),
                headers: {
                    'Content-type': 'application/json; charset=UTF-8',
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}})
            .then(response => response.json())
            .then(data => {
                spinArrow.setAttribute('onclick', 'CHECK_SPIN_CODE()')

                setTimeout(function (){
                    message(data.message);
                }, 5000);
            }).catch();
    }

    function CHECK_SPIN_CODE()
    {
        message('Get Permission')
    }

    let userBalance = '{{auth()->user()->commission_balance}}'

    function SUBMIT_SPIN_CODE()
    {
        var amount = document.querySelector('.spin_input');

        if (amount)
        goForSpan = amount.value;
        if (amount.value != '' && amount.value == 10){
            if (userBalance < amount.value){
                message('Your balance too low.')
                return true;
            }

            spinArrow.setAttribute('onclick', 'spinToWin()')
            document.querySelector('.spin_input').value = '';
        }else{
            message('Enter amount of 10')
        }
    }
</script>
</body>
</html>
