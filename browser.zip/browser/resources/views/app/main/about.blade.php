<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta name="viewport"
          content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height, target-densitydpi=device-dpi"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <!-- === Google Fonts === -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{env('APP_NAME')}}-about-us</title>
</head>
<body style="padding: 0;margin: 0">
<div style="display: flex;justify-content: space-between;background: #060606;padding: 12px 15px;">
    <div onclick="window.location.href='{{route('mine')}}'"><i class="fa fa-chevron-left" style="margin-top: 5px;color: #fff"></i></div>
    <div><h2 style="margin: 0;color: #fff">About-Us</h2></div>
    <div></div>
</div>
<div>
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0001.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0002.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0003.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0004.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0005.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0006.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0007.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0008.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0009.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0010.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0011.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0012.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0013.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0014.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0015.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0016.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0017.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0018.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0019.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0020.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0021.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0022.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0023.jpg')}}">
    <img style="width: 100%;" src="{{asset('public/pdf/Preliminary Analysis of Shortfalls at FTX Exchanges_page-0024.jpg')}}">
</div>
</body>
</html>
