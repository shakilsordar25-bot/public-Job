<!DOCTYPE html>
<html lang="en">
<head>
    @include('app.layout.css')
</head>
<style>
    .card {
        padding: 12px;
        box-shadow: 0px -2px 0px #060606;
        border-radius: 5px;
        margin: 10px 0;
        background: #29be00;
    }
    body {
        background-color: #ffffff;
        padding: 15px 15px;
    }
</style>
<body>
<div class="wrapper profile-page" style="padding-top: 0">
    <div style="display: flex;justify-content: space-between;background: #060606;color: #fff;padding: 12px 16px;">
        <div onclick="window.location.href='{{url('recharge')}}'"><i class="fa fa-chevron-left"></i></div>
        <div>Deposit History</div>
        <div></div>
    </div>

    <style>
        i.fa.fa-arrow-down {
            background: #060606;
            width: 25px;
            height: 25px;
            text-align: center;
            line-height: 25px;
            color: #fff;
            border-radius: 50px;
            margin-right: 5px;
        }
        i.fa.fa-arrow-up {
            background: #060606;
            width: 25px;
            height: 25px;
            text-align: center;
            line-height: 25px;
            color: #fff;
            border-radius: 50px;
            margin-right: 5px;
        }
        hr.hr {
            margin: 15px 0 0 0;
        }
    </style>

    <div class="container" id="recharge" style="display: block">
        <div style="margin-top: 20px">
            @foreach(\App\Models\Deposit::where('user_id', user()->id)->orderByDesc('id')->get() as $element)
                <div class="_card" style="margin-top: 12px">
                    <div style="padding: 0 15px;display: flex;justify-content: space-between;">
                        <div style="font-weight: 600;"> Recharge</div>
                        <div style="font-weight: 600;color: #000000;">+{{$element->final_amount}}</div>
                    </div>
                    <div style="padding: 0 15px;display: flex;justify-content: space-between;">
                        <div style="color: #00000073">{{$element->created_at}}</div>
                        <div>
                            @if($element->status == 'approved')
                                Success
                            @elseif($element->status == 'rejected')
                                Cancel
                            @else
                                Waiting
                            @endif
                        </div>
                    </div>
                </div>
                @if($loop->last)
                @else
                    <hr class="hr">
                @endif
            @endforeach
        </div>
    </div>
</div>

<!-- menu area -->
@include('app.layout.manu')

<!-- === Script Area === -->
@include('app.layout.js')

<script>
    function rechargeTab()
    {
        document.getElementById('recharge').style.display = 'block';
        document.getElementById('withdraw').style.display = 'none';

        document.querySelector('.card_menu_two').style.background = 'transparent';
        document.querySelector('.card_menu_two').style.padding = '10px 0';
        document.querySelector('.card_menu_two').style.fontWeight = '600';
        document.querySelector('.card_menu_two').style.color = '#000';
        document.querySelector('.card_menu_two').style.borderRadius = '50px';

        document.querySelector('.card_menu_one').style.background = '#060606';
        document.querySelector('.card_menu_one').style.padding = '10px 0';
        document.querySelector('.card_menu_one').style.fontWeight = '600';
        document.querySelector('.card_menu_one').style.color = '#fff';
        document.querySelector('.card_menu_one').style.borderRadius = '50px';
    }
    function withdrawTab()
    {
        document.getElementById('recharge').style.display = 'none';
        document.getElementById('withdraw').style.display = 'block';

        document.querySelector('.card_menu_one').style.background = 'transparent';
        document.querySelector('.card_menu_one').style.padding = '10px 0';
        document.querySelector('.card_menu_one').style.fontWeight = '600';
        document.querySelector('.card_menu_one').style.color = '#000';
        document.querySelector('.card_menu_one').style.borderRadius = '50px';

        document.querySelector('.card_menu_two').style.background = '#060606';
        document.querySelector('.card_menu_two').style.padding = '10px 0';
        document.querySelector('.card_menu_two').style.fontWeight = '600';
        document.querySelector('.card_menu_two').style.color = '#fff';
        document.querySelector('.card_menu_two').style.borderRadius = '50px';
        document.querySelector('.card_menu_two').style.marginTop = '0';
    }
</script>
</body>
</html>
