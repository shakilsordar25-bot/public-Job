<!DOCTYPE html>
<html lang="en">

<head>
    @include('app.layout.css')
    <link rel="stylesheet" href="{{asset('public/update')}}/assets/css/income.css">
</head>

<body style="background-image: url('{{asset('public/update')}}/assets/image/auth-bg.png');background-attachment:fixed">
@include('app.layout.loading')
<style>
    .actt {
        background: #385145 !important;
        color: #fff !important;
        border: none !important;
        padding: 2px 5px !important;
        font-size: 12px;
        border-radius: 2px !important;
    }
</style>
<link rel="stylesheet" href="{{asset('public/update')}}/assets/css/style.css">
<section class="team_banner" style="height: 45px;">
    <div class="team_header container" style="padding: 12px 0;">
        <div><i class="fa fa-chevron-left"></i></div>
        <div style="font-weight: bold;color:#fff">working commission</div>
        <div style="font-size: 14px" onclick="window.location.href='{{route('work.record')}}'">Record</div>
    </div>
</section>

<section style="margin-top: 20px">
    <?php
    $check1 = \App\Models\Work::where('user_id', auth()->user()->id)->where('code', '0001')->first();
    ?>
    <div
        @if(!$check1)
        onclick="window.location.href='{{route('youtube')}}'"
        @endif
        style="display: flex;justify-content: space-around;align-items: center;padding: 5px 0;border-bottom: 2px solid #ffffff2b;">
        <div>
            <h3 style="font-size: 13px;font-weight: normal;color: #fff">Youtube subscribe</h3>
        </div>
        <div style="text-align: right">
            <a class="vi_btn actt" href="javascript:void(0)">

                @if($check1)
                    Submitted
                    @else
                        Continue
                    @endif
                </a>
        </div>
    </div>
</section>

<!-- menu area -->
@include('app.layout.manu')
<!-- === Script Area === -->
@include('app.layout.js')

@include('alert-message')

</body>
</html>
