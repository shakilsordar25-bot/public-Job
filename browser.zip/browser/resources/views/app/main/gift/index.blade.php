<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{env('APP_NAME')}}</title>
    <!-- favicon icon -->
    <link rel="icon" href="{{asset('public/footbal')}}/assets/image/favicon.ico">
    <!-- === Font awesome === -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- === Css Area Start === -->
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/global.css">
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/style.css">
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/setting.css">
    <style>
        .gift_box {
            width: 60px;
            height: 60px;
            margin: auto;
            background: #e5d900;
            text-align: center;
            line-height: 60px;
            border-radius: 50px;
        }
        form.gift_box_form {
            margin: 45px 20px;
        }
        label {
            font-size: 18px;
        }
        input[type="text"] {
            width: 100%;
            padding: 14px 8px;
            font-size: 16px;
            color: #000;
            border-radius: 9px;
            margin-top: 5px;
            border: none;
            background: #00000017;
        }
        input[type="text"]::placeholder{
            color: #000;
        }
        button.gift_btn {
            background: linear-gradient(180deg,#67d830,#12773d);
            border: none;
            width: 100%;
            padding: 15px 0;
            color: #fff;
            font-size: 18px;
            border-radius: 50px;
            margin-top: 46px;
        }
        .setting_body {
            top: 164px;
        }
    </style>
</head>
<body>
@include('alert-message')
<link rel="stylesheet" href="{{asset('public/app/css/loading.css')}}">
<div class="loader_boss" style="display: none">
    <svg class="spinner">
        <circle>
            <animateTransform attributeName="transform" type="rotate" values="-90;810" keyTimes="0;1" dur="2s" repeatCount="indefinite"></animateTransform>
            <animate attributeName="stroke-dashoffset" values="0%;0%;-157.080%" calcMode="spline" keySplines="0.61, 1, 0.88, 1; 0.12, 0, 0.39, 0" keyTimes="0;0.5;1" dur="2s" repeatCount="indefinite"></animate>
            <animate attributeName="stroke-dasharray" values="0% 314.159%;157.080% 157.080%;0% 314.159%" calcMode="spline" keySplines="0.61, 1, 0.88, 1; 0.12, 0, 0.39, 0" keyTimes="0;0.5;1" dur="2s" repeatCount="indefinite"></animate>
        </circle>
    </svg>
    <div>
        <span>Loading...</span>
    </div>
</div>
<div class="loader">
    <img class="loading_img" src="{{asset('public/footbal')}}/assets/image/loding.jpg" style="position: fixed;z-index: 999;width: 100px;top: 50%;left: 50%;transform: translate(-50%, -50%);">
</div>
<div class="setting_container">
    <div class="setting_banner" style="background: url('{{asset('public/footbal')}}/assets/image/bill-bg.png')">
        <h2 style="display: flex;justify-content: space-between;margin: 0 20px">
            <div style="font-size: 15px" onclick="window.location.href = '{{route('mine')}}'"><i class="fa fa-chevron-left"></i></div>
            <div style="font-size: 18px">Gift redemption</div>
            <div style="font-size: 13px" onclick="window.location.href = '{{route('user.bonus-preview')}}'">Record</div>
        </h2>
        <p>Enter the gift redemption code you received below to service providers</p>
    </div>

    <div class="setting_body">
        <div class="gift_box" style="text-align: center">
            <img src="{{asset('public/footbal')}}/assets/image/gift.png">
        </div>
    </div>
    <form action="javascript:void(0)" method="" class="gift_box_form"> @csrf
        <label for="gift">Gift redemption code</label>
        <div>
            <input type="text" name="bonus_code" placeholder="Please enter gift redemption code">
        </div>

        <div>
            <button class="gift_btn" onclick="submitBonusRequest()">Receive</button>
        </div>
    </form>
</div>
<meta name="csrf-token" content="{{csrf_token()}}">
<script src="{{asset('public/footbal')}}/assets/js/jquery-3.7.0.min.js"></script>
<script src="{{asset('public/footbal')}}/assets/js/script.js"></script>

<script>
    function submitBonusRequest()
    {
        var csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        var code = document.querySelector('input[name="bonus_code"]').value
        if (code != ''){
            var data = {
                bonus_code: code,
            }
            fetch('{{route('user.submit-bonus')}}', {
                method: "POST",
                body: JSON.stringify(data),
                headers: {
                    "Content-type": "application/json; charset=UTF-8",
                    'X-CSRF-TOKEN': csrfToken
                }
            })
                .then(response => response.json())
                .then(res => {
                    code = ''
                    if (res.status === true)
                    {
                        message(res.message);
                        window.location = '{{route('gift')}}';
                    }else {
                        message(res.message);
                    }
                })
                .catch(err => console.log(err));
        }else {
            setTimeout(function (){
                message('OOPs. Please Enter Bonus Code!')
            }, 2000)
        }
    }
</script>
</body>
</html>
