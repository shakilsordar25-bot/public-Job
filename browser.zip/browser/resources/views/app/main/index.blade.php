<!DOCTYPE html>
<html lang="en">
<head>
    @include('app.layout.css')
    <link rel="stylesheet" href="{{asset('public/update')}}/assets/css/style.css">
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/p_slider.css">
    <link rel="stylesheet" href="{{asset('public/bg.css')}}">
</head>
<body class="bg1">
{{--@include('app.layout.loading')--}}
<style>
    .client-price p {
        color: #17cdaf !important;
    }

    .popular-section .single-popular {
        display: block;
    }

    .client-list-area .client-info .single-info, .client-list-area .client-header {
        padding: 6px 20px;
    }

    .client-list-area .client-info .single-info .client-btn {
        padding: 2px 8px;
    }

    .client-list-area .client-info .single-info .client-price p, .client-list-area .client-info .single-info .client-name h4 {
        font-size: 13px;
    }

    .header-section {
        padding-top: 0 !important;
    }

    section.pertnar {
        background: #060606;
        border-radius: 9px;
    }
    .slider-section {
        height: 195px;
    }
    .wrapper {
        background: #060606b5;
    }
    .home_slider_container {
        background: #268982;
    }
</style>
<div class="wrapper home-page">
    <style>
        .slider-area {
            height: 150px;
            overflow: hidden;
        }
    </style>
    <section class="slider-section">
        <div class="">
            <div class="slider-area">
                <div class="owl-carousel owl-theme owl-loaded">
                    @foreach($sliders as $slider)
                        <div class="single-slider">
                            <img src="{{asset(view_image($slider->photo))}}">
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>

    <section class="popular-section">
        <div onclick="window.location.href='{{route('recharge')}}'" class="single-popular"
             style="background-color: #000000;">
            <img style="display: block" src="{{asset('public/update')}}/assets/image/d1.png" alt="">
            <p style="color: #a737d5;">Deposit</p>
        </div>
        <div onclick="window.location.href='{{route('user.withdraw')}}'" class="single-popular"
             style="background-color: #000000;">
            <img style="display: block" src="{{asset('public/update')}}/assets/image/d2.png" alt="">
            <p style="color: #7b5ce0;">Withdraw</p>
        </div>
        <div class="single-popular" onclick="checkin()" style="background-color: #000000;">
            <img style="display: block" src="{{asset('public/update')}}/assets/image/d3.png" alt="">
            <p style="color: #2fac91;margin-top: 15px">Check-In</p>
        </div>
    </section>

    <section>
        <div onclick="window.location.href='{{url('invite')}}'">
            <img style="width: 100%;height: 85px" src="{{asset('public/update')}}/assets/image/benifit.png">
        </div>
    </section>

    <style>
        .tradingview-widget-copyright {
            display: none;
        }
    </style>

    <section class="client-list-section">
        <div class="">
            <div class="client-list-area">
                <div class="client-header">
                    <p>name</p>
                    <p>latest price</p>
                    <p>quote change</p>
                </div>
                <div class="client-info">
                    <div class="single-info">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_BTC.png" alt="">
                            <h4>btc / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="btcAmount">31046.9900</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" class="client-btn" id="btcPercent">+0.67%</a>
                        </div>
                    </div>
                    <div class="single-info">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_BNB.png" alt="">
                            <h4>bnb / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="bnbAmount">248.8000</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" class="client-btn" id="bnbPercent">+0.67%</a>
                        </div>
                    </div>
                    <div class="single-info">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_TRX.png" alt="">
                            <h4>trx / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="trxAmount">0.0774</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" class="client-btn" id="trxPercent">+0.67%</a>
                        </div>
                    </div>
                    <div class="single-info">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_ETH.png" alt="">
                            <h4>eth / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="ethAmount">1960.2100</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" class="client-btn" id="ethPercent">+0.67%</a>
                        </div>
                    </div>
                    <div class="single-info">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_DOGE.png" alt="">
                            <h4>doge / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="dogeAmount">0.0674</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" class="client-btn" id="dogePercent">+0.84%</a>
                        </div>
                    </div>
                    <div class="single-info">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_XRP.png" alt="">
                            <h4>xrp / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="xrpAmount">0.4818</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" class="client-btn" id="xrpPercent">+1.01%</a>
                        </div>
                    </div>
                    <div class="single-info" style="display: none;">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_SOL.png" alt="">
                            <h4>sql / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="sqlAmount" style="color: #f85963 !important;">19.1100</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" class="client-btn" id="sqlPercent">-0.53%</a>
                        </div>
                    </div>
                    <div class="single-info" style="display: none;">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_LTC.png" alt="">
                            <h4>ltc / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="ltcAmount" style="color: #f85963 !important;">108.8900</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" class="client-btn" id="ltcPercent">-3.78%</a>
                        </div>
                    </div>
                    <div class="single-info">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_ADA.png" alt="">
                            <h4>ada / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="adaAmount">0.2928</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" class="client-btn" id="adaPercent">+1.14%</a>
                        </div>
                    </div>
                    <div class="single-info" style="display: none;">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_LINK.png" alt="">
                            <h4>link / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="linkAmount">6.6070</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" class="client-btn" id="linkPercent">+2.51%</a>
                        </div>
                    </div>
                    <div class="single-info" style="display: none;">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_DOT.png" alt="">
                            <h4>dot / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="dotAmount">5.4680</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" class="client-btn" id="dotPercent">+3.38%</a>
                        </div>
                    </div>
                    <div class="single-info" style="display: none;">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_AVAX.png" alt="">
                            <h4>avax / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="avaxAmount">13.1500</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" class="client-btn" id="avaxPercent">+1.00%</a>
                        </div>
                    </div>
                    <div class="single-info" style="display: none;">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_BCH.png" alt="">
                            <h4>bch / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="bchAmount" style="color: #f85963 !important;">293.2000</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" id="bchPercent" class="client-btn">-0.70%</a>
                        </div>
                    </div>
                    <div class="single-info" style="display: none;">
                        <div class="client-name">
                            <img src="{{asset('public/crypto')}}/tether_XMR.png">
                            <h4>xmr / usdt</h4>
                        </div>
                        <div class="client-price">
                            <p id="xmrAmount">169.5000</p>
                        </div>
                        <div class="client-btn">
                            <a href="javascript:void(0)" id="xmrPercent" class="client-btn">+2.73%</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <style>
        .income_card {
            background: #161312;
            padding: 10px 18px;
            border-radius: 10px;
            margin: 3px 0;
        }
        .income_card h4 {
            color: #fff;
            margin-bottom: 2px;
        }
        .vip_lists li {
            color: #fff;
            border-bottom: 1px dashed #fff;
            padding: 4px 0;
        }
        .income_card button {
            padding: 0px 7px;
        }
        .income_card {
            height: 230px;
            overflow: hidden;
        }
    </style>

    <style>
        section.pertnar p {
            color: #fff;
            text-align: center;
            padding-top: 8px;
            padding-right: 10px;
            padding-left: 10px;
        }
    </style>
    <section class="pertnar" style="margin-bottom: 10px">
        <p>
            {{env('APP_NAME')}} technology, you can easily participate in blockchain transaction with a small amount of
            fund and obtain stable income like insurance
        </p>
        <img style="width: 100%"
             src="{{asset('public/WhatsApp Image 2023-08-10 at 23.19.44.jpg')}}">
    </section>
    <section class="pertnar">
        <img style="width: 100%" src="{{asset('public/pertnar.png')}}">
    </section>
</div>


<script src="{{asset('public/trade.js')}}"></script>


<div class="easy-access">
    <div class="online-service">
        <style>
            .easy-access .online-service img {
                width: 70px;
                height: 70px;
                
                padding: 10px 10px;
                border-radius: 50px;
            }
        </style>
        <a href="{{route('service')}}"><img src="{{asset('/public/upload/icons8-support-50.png')}}"></a>
    </div>
</div>
<style>
.home_slider_container {
    height: 500px !important;
}
.home_slider_container {
    width: 80%;
}
.home_slider_close {
    width: 175px;
}

img.closers {
    width: 26px;
    position: absolute;
    top: 10px;
    left: 12px;
}
</style>

        </div>
    </div>
</div>
<style>
    .checkin {
        left: 0;
    }

    .checkin_container {
        width: 200px;
        height: 120px;
        background: #fff;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        border-radius: 10px;
    }

    .checkin_container p {
        text-align: center;
        margin-top: 20px;
    }

    .checkin_container h4 {
        text-align: center;
        margin-top: 12px;
        font-size: 27px;
        color: #7400ff;
    }

    .close_checkin {
        width: 40px;
        height: 40px;
        background: red;
        text-align: center;
        line-height: 40px;
        font-size: 30px;
        color: #fff;
        border-radius: 50px;
        margin: auto;
        margin-top: 15px;
    }
</style>

<meta name="csrf-token" content="{{csrf_token()}}">
<script src="{{asset('public/assets/toast.js')}}"></script>
@include('alert-message')
<!-- menu area -->
@include('app.layout.manu')

<!-- === Script Area === -->
@include('app.layout.js')

<script>
    function close_home_slider() {
        document.querySelector('.home_slider').style.display = 'none'
    }

    function checkin() {
        var checkin = document.querySelector('.checkin');
        var URL = '{{route('user.checkin')}}'
        fetch(URL, {
            method: 'post',
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Requested-With": "XMLHttpRequest",
                "X-CSRF-Token": document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
        }).then(function (response) {
            return response.json();
        }).then(function (res) {
            message(res.message)
        })
            .catch(function (error) {
                console.log(error)
            });
    }

    function checkinClose() {
        var checkin = document.querySelector('.checkin');
        checkin.style.transition = '.4s';
        checkin.style.zIndex = '-1';
        checkin.style.opacity = '0';
    }
</script>
</body>
</html>
