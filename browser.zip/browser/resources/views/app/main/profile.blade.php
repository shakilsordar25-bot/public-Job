@extends('app.layout.app')
@section('header_content')
    <style>
        .search-button {
            width: unset;
        }
        header.no-background {
            background-color: #fff !important;
        }
        footer {
            margin-bottom: 0px;
        }
        .profile-section {
            background: #fff !important;
        }
        .id-area .id-info .id-acc h3, .id-area .id-info .id-acc h4 {
            color: #000 !important;
        }
        .service-area .single-service a span, .assets-area .assets-icon .single-icon a span {
            color: #000 !important;
        }
        .other-service .single-service a span {
             color: #000 !important;
         }
        .other-service .title h4 {
            color: #000 !important;
        }
        .assets-area {
            background-color: #eb9a14 !important;
        }
        .service-area .single-service a img {

    border-radius: 50%;
}

        .other-service .single-service a img {

    border-radius: 50%;
}

        .assets-area .assets-icon .single-icon img {
    width: 25px;
    border-radius: 50%;
}
    </style>
@endsection
@section('app_content')
    <?php
        $icon = \App\Models\Icon::first();
    ?>
    <link rel="stylesheet" href="{{asset('public/app')}}/css/profile.css">
    <style>
        body {
            background-color: #fff !important;
        }
    </style>
    <main class="margin mt-0">
        <section class="profile-section clearfix">
            <div class="container">
                <div class="id-area">
                    <div class="id-info">
                        <div class="id-image">
                            <img src="{{asset('public/app/assets')}}/img/profile/profile.png" alt="">
                        </div>
                        <div class="id-acc">
                            <h3>{{user()->phone}}</h3>
                            <h4>ID: {{user()->ref_id}}</h4>
                        </div>
                    </div>
                </div>
                <div class="assets-area">
                    <div class="assets-info">

                        <p style="text-align: center">{{translator('total assets')}}</p>
                        <h2 style="text-align: center">
                            <span>{{number_format(auth()->user()->balance , 1)}}<span class="usdt" style="font-size: 13px">USDT</span> </span>
                        </h2>
                    </div>
                    <!-- === Assets Area === -->
                    <div class="assets-icon">
                        <div class="single-icon">
                            <a href="'{{url('recharge')}}">
                                <img src="@if($icon->recharge) {{view_image($icon->recharge)}} @else {{asset('public/app')}}/img/content/serve-icon/crypto.png @endif" alt="">
                                <span>{{translator('Recharge')}}</span>
                            </a>
                        </div>
                        <div class="single-icon">
                            <a href="{{route('user.withdraw')}}">
                                <img src="@if($icon->withdraw) {{view_image($icon->withdraw)}} @else {{asset('public/app')}}/img/content/serve-icon/withdraw.png @endif" alt="">
                                <span>{{translator('Withdraw')}}</span>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- === Service Area === -->
                <div class="service-area">
                    <div class="single-service" style="width: 33%">
                        <a href="{{route('user.invite')}}">
                            <img src="@if($icon->profile_invite) {{view_image($icon->profile_invite)}} @else {{asset('public/app/assets')}}/img/profile/party-card.png @endif" alt="">
                            <span>{{translator('invite')}}</span>
                        </a>
                    </div>
                    <div class="single-service" style="width: 33%">
                        <a href="{{route('user.bank')}}">
                            <img src="@if($icon->profile_bank) {{view_image($icon->profile_bank)}} @else {{asset('public/app/assets')}}/img/profile/bank.png @endif" alt="">
                            <span>{{translator('Banks')}}</span>
                        </a>
                    </div>
                    <div class="single-service" style="width: 33%">
                        <a href="{{route('user.draw.ledger')}}">
                            <img src="@if($icon->profile_income) {{view_image($icon->profile_income)}} @else {{asset('public/app/assets')}}/img/profile/profits.png @endif" alt="">
                            <span>{{translator('Income')}}</span>
                        </a>
                    </div>
                    <div class="single-service" style="width: 33%">
                        <a href="{{route('user.withdraw.ledger')}}">
                            <img src="{{asset('public/app/assets')}}/img/profile/list.png" alt="">
                            <span>{{translator('Withdraw History')}}</span>
                        </a>
                    </div>
                    <div class="single-service" style="width: 33%">
                        <a href="{{route('user.payment.ledger')}}">
                            <img src="{{asset('public/app/assets')}}/img/profile/list-w.png" alt="">
                            <span>{{translator('Deposit History')}}</span>
                        </a>
                    </div>
                </div>
                <div class="other-service">
                    <div class="title">
                        <h4> {{translator('other services')}}</h4>
                    </div>
                    <div class="single-service" style="width: 33%">
                        <a href="{{route('user.draw.ledger')}}">
                            <img src="@if($icon->profile_reword) {{view_image($icon->profile_reword)}} @else {{asset('public/app/assets')}}/img/profile/other/recieved.png @endif" alt="">
                            <span>{{translator('receive rewards')}}</span>

                        </a>
                    </div>
                    <div class="single-service" style="width: 33%">
                        <a href="{{route('user.change.password')}}">
                            <img src="@if($icon->profile_password) {{view_image($icon->profile_password)}} @else {{asset('public/app/assets')}}/img/profile/other/key.png @endif" alt="">
                            <span>{{translator('Change password')}}</span>
                        </a>
                    </div>
                    <div class="single-service" style="width: 33%">
                        <a href="{{route('logout')}}">
                            <img src="@if($icon->profile_logout) {{view_image($icon->profile_logout)}} @else {{asset('public/app/assets')}}/img/profile/other/power.png @endif" alt="">
                            <span> {{translator('Account')}}<br>  {{translator('Log out')}}</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
