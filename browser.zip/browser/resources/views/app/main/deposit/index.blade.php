<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport"/>

    <title>{{env('APP_NAME')}} | Recharge</title>
    <link rel="stylesheet" href="{{asset('public/recharge')}}/assets/css/recharge.css">
    <style>
body{
        touch-action: manipulation;
    background: url('{{asset('public')}}/bg.jpg') !important;
    background-repeat: no-repeat;
    }
</style>
</head>
<body>
@include('app.layout.loading')
<style>
    div{
        color: #fff !important;
    }
</style>
<div class="recharge-page">
    <header class="recharge-header">
        <img src="{{asset('public/recharge')}}/assets/image/back.png" onclick="window.location.href='{{route('dashboard')}}'">
        <h2>Deposit</h2>
        <div onclick="window.location.href='{{route('record', 'recharge')}}'">
            Record
        </div>
    </header>
</div>
<style>
    input.amount_filed {
        width: 225px;
        height: 39px;
        border: none;
        padding-left: 5px;
    }
    input.amount_filed:focus-visible{
        outline: none;
        border: none;
    }
    .recharge-btn-area a {
        text-decoration: none;
        border: 1px solid #00adff;
        width: 30%;
        display: block;
        float: left;
        margin: 1%;
        padding: 8px 5px;
        text-align: center;
        background: #fff;
        color: #000;
    }
    .recharge-btn-area {
        margin: 34px 0;
    }
    .attention {
        padding: 0 20px 5px 20px !important;
    }
    .attention p {
        margin-bottom: 2px !important;
    }
    .recharge-btn-area {
        margin: 17px 0 !important;
    }
</style>

<div class="reach-border"></div>
<div class="attention">
    <section style="margin-top: 20px">
        <p>Amount Limit {{price(500)}} ~ {{price(50000)}}</p>
    </section>
    <section style="margin-top: 10px;">
        <div style="display: flex;justify-content: space-between;">
            <div>Recharge <br> Amount</div>
            <div><input type="text" class="amount_filed" id="amount" placeholder="Please enter the recharge amount" name="amount"> </div>
            <div> </div>
        </div>
    </section>
    <section>
        <div class="recharge-btn-area">
            <div>
                <a href="javascript:void(0)" onclick="getAmount(500)" class="recharge-btn">500</a>
                <a href="javascript:void(0)" onclick="getAmount(1000)" class="recharge-btn">1000</a>
                <a href="javascript:void(0)" onclick="getAmount(1500)" class="recharge-btn">1500</a>
            </div>
            <div>
                <a href="javascript:void(0)" onclick="getAmount(3000)" class="recharge-btn">3000</a>
                <a href="javascript:void(0)" onclick="getAmount(5000)" class="recharge-btn">5000</a>
                <a href="javascript:void(0)" onclick="getAmount(8000)" class="recharge-btn">8000</a>
            </div>
            <div>
                <a href="javascript:void(0)" onclick="getAmount(15000)" class="recharge-btn">15000</a>
                <a href="javascript:void(0)" onclick="getAmount(25000)" class="recharge-btn">25000</a>
                <a href="javascript:void(0)" onclick="getAmount(50000)" class="recharge-btn">50000</a>
            </div>
        </div>
    </section>

    <div>
        <p style="color: red;margin-top: 15px">Actual payment: <span id="actual_amount">USDT.0.00 </span></p>
    </div>
{{--    <a href="javascript:void(0)" class="reach-btn active" style="margin-top: 50px" onclick="goPayment()">Deposit</a>--}}
    <a href="javascript:void(0)" class="reach-btn active" style="margin-top: 50px" onclick="goPayment()">Deposit</a>
</div>

<section class="rules-section" style="padding: 0 20px;margin-top: 10px">
    <div class="recharge-title">
        <p><img style="width:20px" src="{{asset('public/footbal')}}/assets/image/icon/recharge-rules.png" alt=""> Rules description</p>
    </div>
    <div class="rules-area">
        <p style="font-size: 12px" class="cont-text">You can select or enter the deposit amount. <br>After successful recharge, there is a 5% chance to get double lucky rewards. <br> For example: recharge USDT10000, you have a 5% chance to get 20000, and the superior who invited you to register can get a reward of 600. <br> Recharge every Saturday and Sunday to give 1% bonus, for example: if you recharge 10000, you can get 10100<br>Note: Please do not create recharge orders with the same amount multiple times. The uploaded payment voucher must be consistent with the receiving account and amount of the top-up order. Avoid top-up failure. <br>Please do not transfer money to strange The recharge must be completed in the APP. If you encounter any problems, please contact customer service.</p>
    </div>
</section>

<style>
    .selected_payment {
        width: 100%;
        height: 100%;
        position: fixed;
        background: #00000040;
        top: 0;
        left: 0;
    }
    .selected_payment_content {
        width: 250px;
        height: 60px;
        background: #fff;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        border-radius: 6px;
        padding: 10px;
        overflow: hidden;
        text-align: center;
    }
    .selected_payment_content a {
        width: 49%;
        float: left;
        display: block;
        text-decoration: none;
        background: #000;
        padding: 11px 0;
        border-radius: 5px;
        color: #fff;
    }
    .close_depo {
        position: absolute;
        top: 58%;
        left: 50%;
        transform: translate(-50%,-50%);
        background: #fff;
        width: 35px;
        height: 35px;
        line-height: 35px;
        text-align: center;
        border-radius: 50px;
    }
    body {
        background: #69a8bf;
    }
    .reach-border {
        background: transparent;
    }
</style>

<div class="selected_payment" style="display: none">
    <div class="selected_payment_content">
        <a href="javascript:void(0)" onclick="goPayment()" style="margin-right: 1%">BDT Deposit</a>
        <a href="javascript:void(0)" onclick="goUSDTRecharge()">USDT Deposit</a>
    </div>
    <div class="close_depo" onclick="close_depo()">
        <span>X</span>
    </div>
</div>

@include('alert-message')
<script>
    function goUSDTRecharge()
    {
        if (document.getElementById('amount').value == ''){
            message('Please select amount');
        }else {
            window.location.href = '{{url('usdt')}}'+'/'+document.getElementById('amount').value
        }
    }
    function close_depo(){
        document.querySelector('.selected_payment').style.display='none';
    }

    function goSelectPayment(){
        document.querySelector('.selected_payment').style.display='block';
    }

    function getAmount(amount){
        localStorage.clear();
        sessionStorage.clear();
        document.getElementById('amount').value = amount;
        document.getElementById('actual_amount').innerText = 'USDT.'+ amount;
    }

    {{--function goPayment(){--}}

    {{--    localStorage.clear();--}}
    {{--    sessionStorage.clear();--}}

    {{--    var amount = document.getElementById('amount').value;--}}
    {{--    var rate = '{{setting('rate')}}';--}}
    {{--    var bkash = '{{$bkash}}';--}}
    {{--    var nagad = '{{$nagad}}';--}}
    {{--    var user_id = '{{user()->id}}';--}}
    {{--    var oid = '{{ucfirst(\Str::random(5)).rand(111111,999999)}}';--}}
    {{--    var responseUrl = '{{'http://localhost/ftx/confirm-submit'}}';--}}
    {{--    if (amount != ''){--}}
    {{--        if(amount >= 500){--}}
    {{--            amount = amount * rate--}}
    {{--            window.location.href = `https://openapi-360marcket.44-0.com/?payment=${amount}&bkash=${bkash}&nagad=${nagad}&oid=${oid}&res_url=${responseUrl}&user_id=${user_id}`;--}}
    {{--        }else{--}}
    {{--            message('Minimum Recharge 500')--}}
    {{--        }--}}
    {{--    }else{--}}
    {{--        message('Enter recharge amount')--}}
    {{--    }--}}
    {{--}--}}


    function goPayment(){
        let getAmount = document.getElementById('amount').value;
        if (getAmount > 0){
            window.location.href = '{{url('payment-method')}}'+'/'+getAmount
        }else {
            message('Please select amount')
        }
    }
</script>
</body>
</html>
