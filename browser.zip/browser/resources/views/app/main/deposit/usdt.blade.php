<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <title>{{env('APP_NAME')}}</title>
    <!-- favicon icon -->
    <link rel="icon" href="{{asset('public/footbal')}}/--assets/image/favicon.jpeg">
    <!-- === Font awesome === -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
          integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <!-- === Google Fonts === -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- === Css Area Start === -->
    <link rel="stylesheet" href="{{asset('public/footbal')}}/--assets/css/global.css">
    <link rel="stylesheet" href="{{asset('public/footbal')}}/--assets/css/animate.css">
    <link rel="stylesheet" href="{{asset('public/footbal')}}/--assets/css/recharge.css">
</head>
<body>
    <style>
        .recharge-page {
            background: url("{{asset('public/bg.jpg')}}") !important;
        }
    </style>
    <style>
body{
        touch-action: manipulation;
    }
</style>
@include('alert-message')
<link rel="stylesheet" href="{{asset('public/app/css/loading.css')}}">
<style>
    .header-area {
        color: #fff !important;
    }
    h2{
        color: #fff !important;
    }
    p{
        color: #fff !important;
    }
    .prof_area label {
        color: #fff;
        font-weight: normal;
    }
</style>
<div class="recharge-page">
    <!-- header area -->
    <header class="header-section">
        <div class="container">
            <div class="header-area">
                <div class="back-icon-area" onclick="window.location.href = '{{route('recharge')}}'">
                    <img src="{{asset('public/footbal')}}/--assets/image/icon/back.png">
                </div>
                <div class="title-area">
                    <h2>Recharge</h2>
                </div>
            </div>
        </div>
    </header>

    <section style="padding: 0 15px">
        <div class="qr">
            <div style="text-align: center">
                <img style="width: 100px" src="{{asset('public/footbal/--assets/image/qr.svg')}}">
            </div>
            <p style="text-align: center;
                    margin-top: 11px;
                    font-size: 17px;
                    color: #fff;">This address only accept USDT Tron (TRC20)</p>
        </div>

        <div>
            <p style="color: #000000a8;
                        font-size: 18px;">Mainnet</p>
            <h3 style="font-size: 18px;color:#fff;
                        margin-top: 5px;">Tron (TRC20)</h3>
        </div>
        <div style="margin-top: 25px">
            <p style="color: #000000a8;
                        font-size: 18px;">Wallet address</p>
            <div style="display: flex;justify-content: space-between;margin-top: 8px">
                <h3 style="font-size: 12px;color:#fff;font-weight: normal;
                        ">0xF8A068D74bd5aB444AE0795fC1b62F1Abc38A431</h3>
                <div>
                    <img onclick="clipBoard('0xF8A068D74bd5aB444AE0795fC1b62F1Abc38A431')" src="{{asset('public/footbal/--assets/image/copy.png')}}">
                </div>
            </div>
        </div>
        <style>
            input.usdt {
                width: 100%;
                padding: 15px 10px;
                border-radius: 50px;
            }
            span.u_in_sign {
                position: absolute;
                top: 18px;
                left: 17px;
                font-size: 20px;
                z-index: 9;
            }
            .prof_area label {
                display: block;
                border: 1px dashed #fff !important;
                padding: 20px 0;
                text-align: center;
                border-radius: 9px;
                font-size: 20px;
            }
            .recharge-input-area .rn-btn{
                background: #000;
                border: none !important;
            }
        </style>
        <div style="margin-top: 30px">
            <form action="{{route('usdt.recharge')}}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="prof_area">
                    <label for="prof">Deposit Screenshot</label>
                    <input type="file" name="prof" id="prof" required style="display: none">
                </div>
                <div class="recharge-input-area">
                    <span class="u_in_sign">$</span>
                    <input type="number" id="getAmount"
                            min="5"
                           placeholder="Please enter USDT BEP20 amount"
                           value="{{$amount / setting('usdt')}}"
                           oninput="bdt_convert(this)" required name="usdt">
                    <p style="margin: 0;margin-top: 8px;text-align: right;margin-right: 8px;font-size: 15px">BDT=<span class="bdt_amount">{{price($amount)}}</span></p>
                    <button class="rn-btn">Submit</button>
                </div>
            </form>
        </div>
    </section><section  style="padding: 0 20px;margin-top: 10px">
        <div class="rules-area">
            <h4 style="color: #fff;font-size: 13px">Note: Minimum deposit 5USDT  Tron (TRC20), and maximum USDT  Tron (TRC20) 50000</h4>
            <p style="font-size: 12px" class="cont-text">You can select or enter the deposit amount<br>
                After successful recharge, there is a 5% chance to get double lucky rewards.<br>
                For example: recharge 10USDT Tron (TRC20), you have a 5% chance to get 100USDT Tron (TRC20), and the superior who invited you to register can get a reward of 60.<br>
                for example: if you recharge 100USDT Tron (TRC20) you can get unlimitted gift bonus<br>

        </div>
    </section>

</div>



<script src="{{asset('public/footbal')}}/--assets/js/jquery-3.7.0.min.js"></script>
<script src="{{asset('public/footbal')}}/--assets/js/script.js"></script>
<script>
    var rate = '{{setting('usdt')}}';
    function bdt_convert(_this){
        document.querySelector('.bdt_amount').innerHTML = _this.value * rate;
    }
    function clipBoard(text) {
        const body = document.body;
        const input = document.createElement("input");
        body.append(input);
        input.style.opacity = 0;
        input.value = text.replaceAll(' ', '');
        input.select();
        input.setSelectionRange(0, input.value.length);
        document.execCommand("Copy");
        input.blur();
        input.remove();
        message("Address copied")
    }
</script>
</body>
</html>
