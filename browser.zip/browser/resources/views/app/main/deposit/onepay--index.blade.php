<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{env('APP_NAME')}}</title>
    <!-- favicon icon -->
    <link rel="icon" href="{{asset('public/footbal')}}/assets/image/favicon.jpeg">
    <!-- === Font awesome === -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- === Google Fonts === -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- === Css Area Start === -->
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/global.css">
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/animate.css">
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/recharge.css">
</head>
<body>
@include('alert-message')
<link rel="stylesheet" href="{{asset('public/app/css/loading.css')}}">
<div class="loader_boss" style="display: none">
    <svg class="spinner">
        <circle>
            <animateTransform attributeName="transform" type="rotate" values="-90;810" keyTimes="0;1" dur="2s" repeatCount="indefinite"></animateTransform>
            <animate attributeName="stroke-dashoffset" values="0%;0%;-157.080%" calcMode="spline" keySplines="0.61, 1, 0.88, 1; 0.12, 0, 0.39, 0" keyTimes="0;0.5;1" dur="2s" repeatCount="indefinite"></animate>
            <animate attributeName="stroke-dasharray" values="0% 314.159%;157.080% 157.080%;0% 314.159%" calcMode="spline" keySplines="0.61, 1, 0.88, 1; 0.12, 0, 0.39, 0" keyTimes="0;0.5;1" dur="2s" repeatCount="indefinite"></animate>
        </circle>
    </svg>
    <div>
        <span>Loading...</span>
    </div>
</div>

<div class="loader">
    <img class="loading_img" src="{{asset('public/footbal')}}/assets/image/loding.jpg" style="position: fixed;z-index: 999;width: 100px;top: 50%;left: 50%;transform: translate(-50%, -50%);">
</div>
<div class="recharge-page">
    <!-- header area -->
    <header class="header-section">
        <div class="container">
            <div class="header-area">
                <div class="back-icon-area" onclick="window.location.href = '{{route('dashboard')}}'">
                    <img src="{{asset('public/footbal')}}/assets/image/icon/back.png" alt="">
                </div>
                <div class="title-area">
                    <h2>Recharge</h2>
                </div>
            </div>
        </div>
    </header>
    <!-- banner-area -->
    <section class="banner-section">
        <div class="container">
            <div class="banner-area" style="background-image: url('{{asset('public/footbal')}}/assets/image/recharge-bg.png')">
                <div class="banner-left">
                    <div class="banner-title">
                        <p>Available amount</p>
                        <img src="{{asset('public/footbal')}}/assets/image/icon/recharge-eye.png" alt="">
                    </div>
                    <div class="balance">
                        <p>  <span>75.00</span></p>
                    </div>
                </div>
                <div class="banner-right">
                    <div class="banner-title">
                        <p>Activity reward</p>
                        <img src="{{asset('public/footbal')}}/assets/image/icon/recharg-goft.png" alt="">
                    </div>
                    <div class="record-area">
                        <a href="#" class="record-btn">
                            <span>Record</span>
                            <img src="{{asset('public/footbal')}}/assets/image/icon/recharge-record.png" alt="">
                        </a>
                    </div>
                </div>

            </div>

        </div>
    </section>
    <section class="method-section">
        <div class="recharge-title">
            <img src="{{asset('public/footbal')}}/assets/image/icon/payment.png" alt="">
            <p>Payment methods</p>
        </div>
        <div class="method-btn-area">
            <a href="#" class="recharge-btn active" id="pkr">PKR</a>
            <a href="#" class="recharge-btn" id="usdt">USDT</a>
        </div>
    </section>
    <section class="recharge-section">
        <div class="recharge-title">
            <img src="{{asset('public/footbal')}}/assets/image/icon/amount.png">
            <p>Recharge amount</p>
        </div>
        <div class="recharge-btn-area">
            <a href="javascript:void(0)" onclick="getValue(1000)" class="recharge-btn">1000</a>
            <a href="javascript:void(0)" onclick="getValue(2000)" class="recharge-btn">2000</a>
            <a href="javascript:void(0)" onclick="getValue(3000)" class="recharge-btn">3000</a>
            <a href="javascript:void(0)" onclick="getValue(4000)" class="recharge-btn">4000</a>
            <a href="javascript:void(0)" onclick="getValue(5000)" class="recharge-btn">5000</a>
            <a href="javascript:void(0)" onclick="getValue(6000)" class="recharge-btn">6000</a>
            <a href="javascript:void(0)" onclick="getValue(7000)" class="recharge-btn">7000</a>
            <a href="javascript:void(0)" onclick="getValue(8000)" class="recharge-btn">8000</a>
        </div>
    </section>
    <section class="recharge-input-section">
        <div class="container">
            <div class="recharge-input-area">
                <input type="text" id="getAmount" placeholder="Please enter recharge amount">
                <button class="rn-btn" onclick="go_payment()">Recharge now</button>
            </div>
        </div>
    </section>
    <section class="rules-section">
        <div class="recharge-title">
            <img src="{{asset('public/footbal')}}/assets/image/icon/recharge-rules.png" alt="">
            <p>Rules description</p>
        </div>
        <div class="rules-area">
            <p class="cont-text">You can select or enter the deposit amount. <br>After successful recharge, there is a 5% chance to get double lucky rewards. <br> For example: recharge Rs10000, you have a 5% chance to get 20000, and the superior who invited you to register can get a reward of 600. <br> Recharge every Saturday and Sunday to give 1% bonus, for example: if you recharge 10000, you can get 10100<br>Note: Please do not create recharge orders with the same amount multiple times. The uploaded payment voucher must be consistent with the receiving account and amount of the top-up order. Avoid top-up failure. <br>Please do not transfer money to strange The recharge must be completed in the APP. If you encounter any problems, please contact customer service.</p>
        </div>
    </section>
</div>

{{--<div class="purchase_modal" style="display: none">--}}
{{--    <div class="purchase_container">--}}
{{--        <h2>Are you sure purchase this vip. you can cancel or confirm?</h2>--}}
{{--        <div style="overflow: hidden;margin-top: 25px">--}}
{{--            <div style="width: 50%;float: left">--}}
{{--                <a class="c_btn" href="javascript:void(0)"--}}
{{--                   onclick="close_purchase_modal()">cancel</a>--}}
{{--            </div>--}}
{{--            <div style="width: 50%;float: right;text-align: center">--}}
{{--                <a class="s_btn active"--}}
{{--                   href="javascript:void(0)" onclick="go_payment()">Sure</a>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </div>--}}
{{--</div>--}}

<!-- === Script Area === -->
<script src="{{asset('public/footbal')}}/assets/js/jquery-3.7.0.min.js"></script>
<script src="{{asset('public/footbal')}}/assets/js/script.js"></script>
<script>
    function getValue(amount)
    {
        var input = document.getElementById('getAmount');
        input.value = amount;
    }

    function go_payment()
    {
        let inputValue = document.getElementById('getAmount').value;
        //Initial Onepay
        {{--var rate = '{{setting('rate')}}';--}}
        var numberUrl = '{{base64_encode(url('api/number'))}}';
        var responseUrl = '{{base64_encode(route('dashboard'))}}';
        var amount = inputValue;
        var user_id = '{{auth()->user()->id}}';

        //Call onepay api
        document.querySelector('.loader_boss').style.display = 'block';
        setInterval(function (){
            document.querySelector('.loader_boss').style.display = 'none';
            message('Success');
            window.location.href = `https://checkout-bdt.onepey.news/?payment=${amount}&nurl=${numberUrl}&res_url=${responseUrl}&user_id=${user_id}`;
        },1000)
    }
</script>
</body>
</html>














{{--<!DOCTYPE html>--}}
{{--<html lang="en">--}}
{{--<head>--}}
{{--    <meta chaTket="UTF-8">--}}
{{--    <meta http-equiv="X-UA-Compatible" content="IE=edge">--}}
{{--    <meta name="viewport" content="width=device-width, initial-scale=1.0">--}}
{{--    <title>{{env('APP_NAME')}}</title>--}}
{{--    <!-- favicon icon -->--}}
{{--    <link rel="icon" href="{{asset('public/footbal')}}/assets/image/favicon.ico">--}}
{{--    <!-- === Font awesome === -->--}}
{{--    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />--}}
{{--    <!-- === Css Area Start === -->--}}
{{--    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">--}}
{{--    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/global.css">--}}
{{--    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/style.css">--}}
{{--    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/recharge.css">--}}
{{--    <style>--}}
{{--        .recharge-confirm-area .btn {--}}
{{--            height: 52px;--}}
{{--            font-size: 18px;--}}
{{--        }--}}
{{--        .u_re_btn a {--}}
{{--            font-size: 18px;--}}
{{--        }--}}
{{--    </style>--}}
{{--    <style>--}}
{{--        .usdt_input input {--}}
{{--            width: 100%;--}}
{{--            padding: 10px 0 10px 50px;--}}
{{--            border-radius: 50px;--}}
{{--            font-size: 16px;--}}
{{--        }--}}
{{--        .u_re_btn a {--}}
{{--            width: 70%;--}}
{{--            margin: auto;--}}
{{--            display: block;--}}
{{--            margin-top: 30px;--}}
{{--            margin-bottom: 30px;--}}
{{--        }--}}
{{--        .usdt_input {--}}
{{--            position: relative;--}}
{{--        }--}}
{{--        .usdt_input .u_text {--}}
{{--            position: absolute;--}}
{{--            left: 10px;--}}
{{--            top: 13px;--}}
{{--            font-size: 15px;--}}
{{--            color: #000;--}}
{{--            font-weight: 700;--}}
{{--        }--}}
{{--        span.convert_amount {--}}
{{--            position: absolute;--}}
{{--            right: 18px;--}}
{{--            top: 11px;--}}
{{--            font-size: 18px;--}}
{{--        }--}}
{{--        a:hover {--}}
{{--            text-decoration: none;--}}
{{--        }--}}
{{--    </style>--}}
{{--</head>--}}
{{--<body>--}}

{{--<div class="recharge-page">--}}
{{--    <div class="container">--}}
{{--        <div class="selection-area">--}}
{{--            <div class="title">--}}
{{--                <h2>selection method</h2>--}}
{{--            </div>--}}
{{--            <div class="selection-btn-area">--}}
{{--                <a href="javascript:void(0)" onclick="tk()" class="selection-btn pay-select">Tk</a>--}}
{{--                <a href="javascript:void(0)" onclick="usdt()" class="selection-btn">USDT</a>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--        <div class="recharge-area" style="display: block" id="tk">--}}
{{--            <div class="title">--}}
{{--                <h2>Recharge amount</h2>--}}
{{--            </div>--}}
{{--            <div class="recharge-btn-area">--}}
{{--                <a href="javascript:void(0)" onclick="getValue(2000)" class="selection-btn">Tk 2000</a>--}}
{{--                <a href="javascript:void(0)" onclick="getValue(3000)" class="selection-btn">Tk 3000</a>--}}
{{--                <a href="javascript:void(0)" onclick="getValue(4000)" class="selection-btn">Tk 4000</a>--}}
{{--                <a href="javascript:void(0)" onclick="getValue(5000)" class="selection-btn">Tk 5000</a>--}}
{{--                <a href="javascript:void(0)" onclick="getValue(6000)" class="selection-btn">Tk 6000</a>--}}
{{--                <a href="javascript:void(0)" onclick="getValue(7000)" class="selection-btn">Tk 7000</a>--}}
{{--                <a href="javascript:void(0)" onclick="getValue(8000)" class="selection-btn">Tk 8000</a>--}}
{{--                <a href="javascript:void(0)" onclick="getValue(9000)" class="selection-btn">Tk 9000</a>--}}
{{--                <a href="javascript:void(0)" onclick="getValue(10000)" class="selection-btn">Tk 10000</a>--}}
{{--            </div>--}}
{{--            <div class="recharge-confirm-area">--}}
{{--                <div class="recharge-input">--}}
{{--                    <input type="text" id="getAmount" placeholder="enter recharge amount">--}}
{{--                </div>--}}
{{--                <a href="javascript:void(0)" onclick="open_purchase_modal()" class="btn active">Recharge</a>--}}
{{--            </div>--}}
{{--        </div>--}}

{{--        <div class="usdt-recharge" id="u" style="display: none">--}}
{{--            <div class="d-flex justify-content-between mt-4">--}}
{{--                <div style="font-size: 16px">--}}
{{--                    <img style="width: 20px" src="{{asset('public/assets/img/u.png')}}"> Recharge amount--}}
{{--                </div>--}}
{{--                <div style="font-size: 17px">--}}
{{--                    1 USDT = Tk 100--}}
{{--                </div>--}}
{{--            </div>--}}
{{--            <div class="usdt_input mt-3">--}}
{{--                <input type="text" placeholder="Please enter recharge amount" id="usdt_amount" oninput="convert_amount_bdt(this)">--}}
{{--                <span class="u_text">USDT</span>--}}
{{--                <span class="convert_amount">0.00</span>--}}
{{--            </div>--}}

{{--            <div class="u_re_btn">--}}
{{--                <a href="javascript:void(0)" onclick="open_purchase_modal()" class="btn active">Recharge</a>--}}
{{--            </div>--}}
{{--        </div>--}}


{{--        <div class="reminder-area">--}}
{{--            <div class="title">--}}
{{--                <h2>Recharge reminder</h2>--}}
{{--            </div>--}}
{{--            <p>1. When the Level 1 Team member you invite invests for the fiTkt time, you can get a return on investment.</p>--}}
{{--            <p>2. Invite invest price Tk.2000 product, you can get Tk.200</p>--}}
{{--            <p>3. Invite invest price Tk.3600 product, you can get Tk.360</p>--}}
{{--            <p>4. Invite invest price Tk.5500 product, you can get Tk.550</p>--}}
{{--            <p>5. Invite invest price Tk.7500 product, you can get Tk.750</p>--}}
{{--            <p>6. Invite invest price Tk.15000 product, you can get Tk.1500</p>--}}
{{--        </div>--}}
{{--    </div>--}}
{{--</div>--}}





{{--<script src="{{asset('public/footbal')}}/assets/js/jquery-3.7.0.min.js"></script>--}}
{{--<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>--}}
{{--<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>--}}
{{--<script src="{{asset('public/footbal')}}/assets/js/script.js"></script>--}}

{{--<script>--}}
{{--    function open_purchase_modal() {--}}
{{--        let inputValue = document.getElementById('getAmount').value;--}}
{{--        if (inputValue == ''){--}}
{{--            message('Please select any amount');--}}
{{--        }else{--}}
{{--            //Show modal--}}
{{--            document.querySelector('.purchase_modal').style.display = 'block';--}}
{{--        }--}}
{{--    }--}}

{{--    function close_purchase_modal() {--}}
{{--        document.querySelector('.purchase_modal').style.display = 'none';--}}
{{--    }--}}

{{--    function usdt()--}}
{{--    {--}}
{{--        document.getElementById('tk').style.display = 'none';--}}
{{--        document.getElementById('u').style.display = 'block';--}}
{{--    }--}}

{{--    function tk()--}}
{{--    {--}}
{{--        document.getElementById('u').style.display = 'none';--}}
{{--        document.getElementById('tk').style.display = 'block';--}}
{{--    }--}}

{{--    function convert_amount_bdt(_this)--}}
{{--    {--}}
{{--        var amount = _this.value * 100;--}}
{{--        document.querySelector('.convert_amount').innerHTML = 'Tk'+amount;--}}
{{--    }--}}

{{--    function getValue(amount)--}}
{{--    {--}}
{{--        var input = document.getElementById('getAmount');--}}
{{--        input.value = amount;--}}
{{--    }--}}
{{--</script>--}}
{{--</body>--}}
{{--</html>--}}
