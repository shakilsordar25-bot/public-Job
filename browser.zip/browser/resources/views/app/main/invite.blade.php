<!doctype html>
<html lang="en">
<head>
    @include('app.layout.css')
    <title>{{env('APP_NAME')}}-share</title>
    <link rel="stylesheet" href="{{asset('public/bg.css')}}">
    <style>
        p {
            color: #fff;
            font-size: 19px;
        }
    </style>
</head>
<body class="bg1" style="color: #fff;padding: 0">
<div style="    display: flex;
    justify-content: space-between;
    margin-bottom: 5px;
    background: transparent;
    padding: 18px;">
    <div onclick="window.location.href='{{route('mine')}}'">
        <i class="fa fa-chevron-left"></i>
    </div>
    <div>
        invitation poster
    </div>
    <div></div>
</div>
<style>
    .link_card {
        background: #00000045;
        margin: 0 15px;
        padding: 15px 10px;
        border: 1px solid #fff;
        border-radius: 5px;
    }
    .link_card h4 {
        font-weight: normal;
        margin-bottom: 20px;
    }
    .link_text {
        background: #00000063;
        padding: 15px 11px;
        text-align: center;
        font-size: 14px;
        border: 1px solid #ffffff9c;
        border-radius: 5px;
    }
    .invi_link_btn a {
        font-size: 17px;
        color: #fff;
        background: #000;
        display: block;
        margin-top: 20px;
        margin-bottom: 20px;
        padding: 11px 0;
        text-align: center;
        border-radius: 50px;
    }
    .scanner {
        background: #00000082;
        margin: 0 15px;
        padding: 50px 0;
        border-radius: 10px;
        box-shadow: 0px 5px 10px #ffffff7a;
    }
    .scanner img {
        border: 6px solid #fff;
        border-radius: 5px;
    }
    .invi_link_btn a {
        margin-top: 5px;
    }
    .scanner {
        padding: 30px 0;
    }
    .link_card h4 {
        margin-bottom: 8px;
    }
</style>
<div class="link_card">
    <h4>Invitation link:</h4>
    <div class="link_text">
        {{url('register'.'?inviteCode='.auth()->user()->ref_id)}}
    </div>
</div>

<div style="margin: 0 15px;" class="invi_link_btn">
    <a href="javascript:void(0)" onclick="clipBoard('{{url('register'.'?ref_by='.auth()->user()->ref_id)}}')">Copy Invitation Link</a>
</div>

<div style="text-align: center;" class="scanner">
    <img style="width: 150px" src="{{asset('public/update')}}/assets/image/scan.png">
</div>

<p style="text-align: center;margin-top: 20px">
    Join us and embark on a successful <br> investment journey!
</p>

<script src="{{asset('public/assets/toast.js')}}"></script>
<script>
    function clipBoard(text) {
        const body = document.body;
        const input = document.createElement("input");
        body.append(input);
        input.style.opacity = 0;
        input.value = text;
        input.select();
        input.setSelectionRange(0, input.value.length);
        document.execCommand("Copy");
        input.blur();
        input.remove();
        message("Copy success")
    }
</script>
</body>
</html>
