<!DOCTYPE html>
<html lang="en">
<head>
    @include('app.layout.css')
</head>
<style>
    .card {
        padding: 12px;
        box-shadow: 0px -2px 0px #060606;
        border-radius: 5px;
        margin: 10px 0;
        background: #29be00;
    }
    body {
        background-color: #000 !important;
        padding: 0;
        margin: 0;
    }
    .wrapper.team-page, .wrapper.profile-page {
        background: #fff;
    }
    .wrapper {
        min-height: 100vh;
        padding: 0 0;
    }
</style>
<body>
<div class="wrapper profile-page" style="margin: 0px 15px;">
    <div style="display: flex;justify-content: space-between;background: #060606;color: #fff;padding: 12px 16px;">
        <div onclick="window.location.href='{{route('onetime')}}'"><i class="fa fa-chevron-left"></i></div>
        <div>One time work History</div>
        <div></div>
    </div>
    <style>
        i.fa.fa-arrow-down {
            background: #060606;
            width: 25px;
            height: 25px;
            text-align: center;
            line-height: 25px;
            color: #fff;
            border-radius: 50px;
            margin-right: 5px;
        }
        i.fa.fa-arrow-up {
            background: #060606;
            width: 25px;
            height: 25px;
            text-align: center;
            line-height: 25px;
            color: #fff;
            border-radius: 50px;
            margin-right: 5px;
        }
        hr.hr {
            margin: 15px 0 0 0;
        }
    </style>


    <div class="container" id="withdraw" style="display: block">
        <?php
        $is = \App\Models\Work::where('user_id', \Auth::id())->orderByDesc('id')->get();
        ?>
        @foreach($is as $i)
            <div class="_card" style="margin-top: 12px">
                <div style="padding: 0 15px;display: flex;justify-content: space-between;">
                    <div style="font-weight: 600;color: #000000;">One time work</div>
                    <div style="font-weight: 600;color: #000000;">
                        {{price($i->amount)}}
                    </div>
                </div>
                <div style="padding: 0 15px;display: flex;justify-content: space-between;">
                    <div style="color: #00000073">{{$i->created_at}}</div>
                    <div>
                        @if($i->status == 'active')
                            Approved
                        @else
                            Not-Approved
                        @endif
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>

<!-- menu area -->
@include('app.layout.manu')

<!-- === Script Area === -->
@include('app.layout.js')

</body>
</html>
