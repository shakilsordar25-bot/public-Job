<!DOCTYPE html>
<html lang="en">
<head>
    @include('app.layout.css')
    <link rel="stylesheet" href="{{asset('public/footbal')}}/assets/css/recharge.css">
    <style>
        .banner-area .balance p {
            margin: 0;
        }

        .recharge-title {
            padding-bottom: 0;
        }

        .rules-area .cont-text {
            font-weight: 700;
        }
        .recharge-input-area.pass::after {
            content: 'P';
        }
        .recharge-input-area.w_btn::after {
            content: '';
        }
        .header-area {
            height: 13.333333vw;
        }
        .recharge-title {
            padding-bottom: 8px;
        }
        body {
            background-color: #ffffff;
        }
        .recharge-page {
            padding-right: 12px;
            padding-left: 12px;
        }
        .submit_withdraw_div button {
            border-radius: 5px !important;
            background:rgb(59 130 246) !important;
        }
        .recharge-page {
            background: #69a8bf;
        }
        .header-section {
            background: transparent;
        }
        .header-area .title-area h2 {
            color: #fff;
        }
        h2 {
            color: #fff !important;
        }
        .withdraw_card p {
            color: #fff !important;
        }
        p{
            color: #fff !important;
        }
        section {
            color: #fff3cd;
        }
        input.withdraw_input {
            padding: 10px 0;
            border: none;
            border-radius: 5px;
            margin-top: 5px;
        }
        .submit_withdraw_div button {
            padding: 11px 20px !important;
        }
        .submit_withdraw_div {
            position: absolute;
            right: -1px !important;
            top: 33px !important;
        }
        .w_usdt {
            position: absolute;
            right: 0px;
        }
        .w_usdt a{
            color: #fff;
        }
    </style>
</head>
<body>
@include('alert-message')
@include('app.layout.loading')
<div class="recharge-page">
    <!-- header area -->
    <header class="header-section">
        <div class="container">
            <div class="header-area">
                <div class="back-icon-area" onclick="window.location.href='{{route('user.withdraw')}}'">
                    <img style="width: 80%" src="{{asset('public/footbal')}}/assets/image/icon/back.png" alt="">
                </div>
                <div class="title-area">
                    <h2>Withdraw</h2>
                </div>
                <div class="w_usdt">
                    <a href="{{route('user.withdraw')}}">
                        BDT
                    </a>
                </div>
            </div>
        </div>
    </header>

    <style>
        .withdraw_card p {
            color: #0000007a;
            font-size: 14px;
        }
        .withdraw_card li {
            padding: 11px 0;
            border-bottom: 1px solid #0000001f;
        }
        .withdraw_card li:last-child{
            border-bottom: unset;
        }
        input.withdraw_input {
            width: 100%;
            padding: 8px 0;
            font-size: 17px;
            border: none;
        }
        input.withdraw_input:focus-visible{
            outline: none;
            border: none;
        }
        .submit_withdraw_div {
            position: absolute;
            right: 0;
            top: 40px;
        }
        .submit_withdraw_div button {
            padding: 7px 20px;
            background: rgba(59,130,246,0.5);
            border: none;
            border-radius: 0px 50px 50px;
            color: #fff;
        }
    </style>

    <section>
        <h2 style="font-weight: normal;margin-bottom: 15px">USDT Withdrawal</h2>
        <div class="withdraw_card" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 0px 6px 1px;padding: 13px">
            <ul style="margin: 0;padding: 0">
                <li>
                    <p>My Balance (USDT)</p>
                    <h2>{{price(auth()->user()->commission_balance / setting('usdt'))}}</h2>
                </li>
                <li>
                    <p>My Bank</p>
                    <h2 style="color: #0009; font-size: 16px">{{auth()->user()->usdt_name ?? '---'}}</h2>
                </li>
                <li>
                    <p>Account Number</p>
                    <h2 style="color: #0009; font-size:12px">{{auth()->user()->usdt ?? '---'}}</h2>
                </li>
                <li style="position:relative;">
                    <p>Withdraw amount (USDT)</p>
                    <div>
                        <input type="text" class="withdraw_input" oninput="getUSDTAmount(this)">
                        <div style="display: flex;justify-content: space-between">
                            <div>Amount(BDT)</div>
                            <div class="bdtbalance">0.00</div>
                        </div>
                    </div>
                    <div class="submit_withdraw_div">
                        <button type="button" onclick="withdrawNow()">Submit <i class="fa fa-chevron-right"></i> </button>
                    </div>
                </li>
            </ul>
        </div>
    </section>

    <section style="margin-top: 25px">
        <h4 style="color: #fff;font-size: 13px;">Note: Minimum withdraw 5USDT and maximum withdraw 10000USDT, and withdraw charge 1USDT BEP20</h4>
        <p style="font-size: 15px">The daily withdrawal time is from any time
            Withdrawals are tax-free on the 1st and 15nd of each month</p>
    </section>

    <section style="display: flex;justify-content: space-between;padding: 30px 20px 30px 0" onclick="window.location.href='{{route('user.withdraw.preview')}}'">
        <div><h4>Withdraw record</h4></div>
        <div><i class="fa fa-chevron-right"></i></div>
    </section>
</div>
<input type="hidden" name="amount">
<script>
    let rate = '{{setting('usdt')}}'
    function getUSDTAmount(_this){
        document.querySelector('.bdtbalance').innerHTML = "Tk."+_this.value * rate+'.00';
        document.querySelector('input[name="amount"]').value=_this.value * rate;
    }
</script>

<!-- menu area -->
@include('app.layout.manu')

<!-- === Script Area === -->
@include('app.layout.js')
<meta name="csrf-token" content="{{ csrf_token() }}">
<script>
    function withdrawNow(){
        var amount = document.querySelector('input[name="amount"]').value;
        if (amount == '')
        {
            message('Enter withdraw amount');
            return true;
        }

        var data = {
            amount: amount,
            usdt: 'usdt'
        }

        fetch('{{route('user.withdraw.request')}}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body:JSON.stringify(data),
        })
            .then((res) => res.json())
            .then((data) => {
                if (data.status===true){
                    message(data.message)
                    document.querySelector('input[name="amount"]').value = '';
                    window.location.href='{{url('withdraw-preview')}}';
                }
                if (data.status===false){
                    message(data.message)
                }
                document.querySelector('input[name="amount"]').value = '';
            })
            .catch((err) => console.log(err));
    }
</script>
</body>
</html>
