<!DOCTYPE html>
<html lang="en">
<head>
    @include('app.layout.css')
    <link rel="stylesheet" href="{{asset('public/update')}}/assets/css/income.css">
</head>

<body style="background-image: url('{{asset('public/update')}}/assets/image/auth-bg.png');background-attachment:fixed">
@include('app.layout.loading')
<link rel="stylesheet" href="{{asset('public/update')}}/assets/css/creadential.css">
<section>
    <style>
        .licon {
            top: 38px;
            color: #000;
        }
        .custom_form_box button {
            color: #000;
        }
        input.custom_input {
            height: 45px;
        }
        .licon {
            top: 33px;
        }
    </style>
    <div style="display: flex;justify-content: space-between;margin-bottom: 10px">
        <div style="color: #fff;" onclick="window.location.href='{{route('mine')}}'"><i class="fa fa-chevron-left"></i></div>
        <div style="color: #fff;">Change Password</div>
        <div></div>
    </div>

    <form action="{{route('password_chanage_confirm')}}" method="post"> @csrf
        <div style="margin-top: 30px">
            <div class="custom_form_box">
                <label for="" style="color: #fff;">Current password</label>
                <i class="licon"><img style="width: 20px" src="{{asset('public/icon/icons8-key-24.png')}}"></i>
                <input type="password" class="custom_input" name="current_password" value="">
            </div>

            <div class="custom_form_box">
                <label for="" style="color: #fff;">New password</label>
                <i class="licon"><img style="width: 20px" src="{{asset('public/icon/icons8-key-24.png')}}"></i>
                <input type="password" class="custom_input" name="new_password" value="">
            </div>

            <div class="custom_form_box">
                <label for="" style="color: #fff;">Confirm password</label>
                <i class="licon"><img style="width: 20px" src="{{asset('public/icon/icons8-key-24.png')}}"></i>
                <input type="password" class="custom_input" name="confirm_password" value="">
            </div>

            <div class="custom_form_box">
                <button type="submit">Continue</button>
            </div>
        </div>
    </form>

</section>

<!-- menu area -->
@include('app.layout.manu')
<!-- === Script Area === -->
@include('app.layout.js')
@include('alert-message')
</body>
</html>
