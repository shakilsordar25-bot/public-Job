@extends('app.layout.app')
@section('header_content')
    <link rel="stylesheet" href="{{asset('public/app/')}}/assets/select2.min.css">
    <link rel="stylesheet" href="{{asset('public/app/')}}/assets/style.css">
    <style>
        .search-button {
            width: unset;
        }
        .modal-backdrop.show {
            display: none;
        }
        .navi-menu-button {
            width: unset;
        }
        header.no-background {
            background-color: #fff !important;
        }
        footer {
            margin-bottom: 0px;
        }
    </style>
@endsection
@section('app_content')

    <!-- Page content start -->
    <main class="margin" style="margin-top: 0">
            <section class="container">
                <div>
                    <div class="alert alert-success">
                        Please check your email and enter the valid verification code
                    </div>
                </div>

                <form action="{{route('setup.gateway.submit')}}" method="post" enctype="multipart/form-data"> @csrf
                    <input type="hidden" name="gateway_method" value="{{$method}}">
                    <input type="hidden" name="gateway_number" value="{{$number}}">

                    <div class="col-12">
                        <div class="account_selector_option mt-4">
                            <label for="code" class="number">Enter verification code</label>
                            <input type="number" class="form-control" name="code" id="code" required value="">
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="account_selector_option mt-4 text-center">
                            <button type="submit" class="btn btn-success" style="background-color: var(--vip-main)"> <i class="fa fa-pencil"></i> Confirm</button>
                        </div>
                    </div>
                </form>
                <div class="form-divider"></div>
            </section>
    <footer>
    </footer>
    </main>



@endsection
